
import React, { useState } from 'react';
import { ViewType, UserRole } from './types';
import Sidebar from './components/Sidebar';
import Header from './components/Header';
import Login from './views/Login';
import StudentDashboard from './views/StudentDashboard';
import StudentAchievements from './views/StudentAchievements';
import StudentHistory from './views/StudentHistory';
import CourseList from './views/CourseList';
import CourseDetails from './views/CourseDetails';
import CourseEdit from './views/CourseEdit';
import ChapterDetail from './views/ChapterDetail';
import ChapterReader from './views/ChapterReader';
import InstructorList from './views/InstructorList';
import InstructorDetail from './views/InstructorDetail';
import DisciplineEdit from './views/DisciplineEdit';
import ContentCreation from './views/ContentCreation';
import ContentRevision from './views/ContentRevision';
import AdminConsole from './views/AdminConsole';
import AdminClassManagement from './views/AdminClassManagement';
import UserManagement from './views/UserManagement';
import SystemSettings from './views/SystemSettings';
import UserProfile from './views/UserProfile';
import AccountSettings from './views/AccountSettings';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentView, setCurrentView] = useState<ViewType>('STUDENT_DASHBOARD');
  const [userRole, setUserRole] = useState<UserRole>('STUDENT');
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  // Estado global para o Logotipo
  const [logoUrl, setLogoUrl] = useState('/assets/logo/2.png');
  
  // Pilha de histórico para navegação "Voltar" correta
  const [historyStack, setHistoryStack] = useState<ViewType[]>([]);

  const handleNavigate = (view: ViewType) => {
    setHistoryStack((prev) => [...prev, currentView]);
    setCurrentView(view);
  };

  const handleBack = () => {
    setHistoryStack((prev) => {
      const newStack = [...prev];
      const previousView = newStack.pop();
      if (previousView) {
        setCurrentView(previousView);
      }
      return newStack;
    });
  };

  const handleLogin = (role: UserRole) => {
    setUserRole(role);
    setIsAuthenticated(true);
    
    // Redireciona para a view inicial correta baseada no papel
    if (role === 'ADMIN') {
        setCurrentView('ADMIN_CONSOLE');
    } else if (role === 'INSTRUCTOR') {
        setCurrentView('INSTRUCTOR_LIST');
    } else {
        setCurrentView('STUDENT_DASHBOARD');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setHistoryStack([]);
    setCurrentView('STUDENT_DASHBOARD'); // Reset para default
  };

  const renderView = () => {
    switch (currentView) {
      case 'STUDENT_DASHBOARD': return <StudentDashboard />;
      case 'STUDENT_ACHIEVEMENTS': return <StudentAchievements />; 
      case 'STUDENT_HISTORY': return <StudentHistory />;
      case 'COURSE_LIST': return <CourseList onNavigate={handleNavigate} />;
      case 'COURSE_DETAILS': return <CourseDetails onNavigate={handleNavigate} />;
      case 'COURSE_EDIT': return <CourseEdit onNavigate={handleNavigate} />;
      case 'CHAPTER_DETAIL': return <ChapterDetail onNavigate={handleNavigate} />;
      case 'CHAPTER_READER': return <ChapterReader userRole={userRole} />;
      case 'INSTRUCTOR_LIST': return <InstructorList onNavigate={handleNavigate} />;
      case 'INSTRUCTOR_DETAIL': return <InstructorDetail onNavigate={handleNavigate} />;
      case 'DISCIPLINE_EDIT': return <DisciplineEdit onNavigate={handleNavigate} />;
      case 'CONTENT_CREATION': return <ContentCreation onNavigate={handleNavigate} />;
      case 'CONTENT_REVISION': return <ContentRevision onNavigate={handleNavigate} />;
      case 'ADMIN_CONSOLE': return <AdminConsole onNavigate={handleNavigate} />;
      case 'ADMIN_CLASSES': return <AdminClassManagement onNavigate={handleNavigate} />;
      case 'USER_MANAGEMENT': return <UserManagement />;
      case 'SYSTEM_SETTINGS': return <SystemSettings onLogoUpdate={setLogoUrl} logoUrl={logoUrl} />;
      case 'USER_PROFILE': return <UserProfile onNavigate={handleNavigate} />;
      case 'ACCOUNT_SETTINGS': return <AccountSettings onNavigate={handleNavigate} />;
      default: return <StudentDashboard />;
    }
  };

  const getPageTitle = () => {
    switch (currentView) {
      case 'STUDENT_DASHBOARD': return 'Dashboard do Aluno';
      case 'STUDENT_ACHIEVEMENTS': return 'Minhas Conquistas';
      case 'STUDENT_HISTORY': return 'Histórico de Atividades';
      case 'COURSE_LIST': return 'Meus Cursos';
      case 'COURSE_DETAILS': return 'Detalhes do Curso';
      case 'COURSE_EDIT': return 'Editor de Curso';
      case 'CHAPTER_DETAIL': return 'Visão Geral do Capítulo';
      case 'CHAPTER_READER': return 'Leitura e Prática Socrática';
      case 'INSTRUCTOR_LIST': return 'Portal do Instrutor';
      case 'INSTRUCTOR_DETAIL': return 'Gestão de Disciplina';
      case 'DISCIPLINE_EDIT': return 'Editor de Disciplina';
      case 'CONTENT_CREATION': return 'Adicionar Conteúdo';
      case 'CONTENT_REVISION': return 'Revisão de Conteúdo AI';
      case 'ADMIN_CONSOLE': return 'Console de Administração';
      case 'ADMIN_CLASSES': return 'Gestão de Turmas';
      case 'USER_MANAGEMENT': return 'Gestão de Usuários';
      case 'SYSTEM_SETTINGS': return 'Configurações do Sistema';
      case 'USER_PROFILE': return 'Meu Perfil';
      case 'ACCOUNT_SETTINGS': return 'Minha Conta';
      default: return 'Harven.ai';
    }
  };

  if (!isAuthenticated) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="flex h-screen w-full bg-harven-bg overflow-hidden">
      <Sidebar 
        currentView={currentView} 
        onNavigate={handleNavigate} 
        isOpen={sidebarOpen}
        onToggle={() => setSidebarOpen(!sidebarOpen)}
        userRole={userRole}
        logoUrl={logoUrl}
      />
      
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header 
          title={getPageTitle()} 
          onNavigate={handleNavigate}
          currentView={currentView}
          onBack={historyStack.length > 0 ? handleBack : undefined}
          logoUrl={logoUrl}
          userRole={userRole}
          onLogout={handleLogout}
        />
        
        <main className="flex-1 overflow-y-auto no-scrollbar">
          {renderView()}
        </main>
      </div>
    </div>
  );
};

export default App;
