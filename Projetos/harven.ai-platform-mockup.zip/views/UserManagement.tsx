
import React, { useState } from 'react';
import { Input } from '../components/ui/Input';
import { Select } from '../components/ui/Select';
import { Button } from '../components/ui/Button';
import { Avatar } from '../components/ui/Avatar';
import { Badge } from '../components/ui/Badge';
import { Card } from '../components/ui/Card';

const UserManagement: React.FC = () => {
  const [showModal, setShowModal] = useState(false);
  const [users, setUsers] = useState([
    { id: 1, name: 'Ana Silva', email: 'ana.silva@harven.edu', role: 'Aluno', status: 'Ativo', time: 'Hoje, 14:30' },
    { id: 2, name: 'Carlos Souza', email: 'carlos.s@harven.edu', role: 'Professor', status: 'Ativo', time: 'Ontem, 09:15' },
    { id: 3, name: 'Marcos Dias', email: 'marcos.d@harven.edu', role: 'Admin', status: 'Inativo', time: 'Há 32 dias' },
    { id: 4, name: 'Julia Lima', email: 'julia.l@harven.edu', role: 'Aluno', status: 'Ativo', time: 'Hoje, 10:00' },
    { id: 5, name: 'Pedro Alves', email: 'pedro.a@harven.edu', role: 'Professor', status: 'Ativo', time: 'Hoje, 11:45' },
  ]);

  const [formData, setFormData] = useState({
      name: '',
      email: '',
      role: 'Aluno',
      status: 'Ativo'
  });

  const handleCreateUser = (e: React.FormEvent) => {
      e.preventDefault();
      
      const newUser = {
          id: users.length + 1,
          name: formData.name,
          email: formData.email,
          role: formData.role,
          status: formData.status,
          time: 'Nunca acessou',
      };

      setUsers([newUser, ...users]);
      setShowModal(false);
      setFormData({ name: '', email: '', role: 'Aluno', status: 'Ativo' });
  };

  const getStatusVariant = (status: string) => {
      switch(status) {
          case 'Ativo': return 'success';
          case 'Inativo': return 'default';
          default: return 'warning';
      }
  };

  return (
    <div className="max-w-[1400px] mx-auto p-8 flex flex-col gap-8 h-full relative animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-3xl font-display font-bold text-foreground tracking-tight">Gerenciamento de Usuários</h2>
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mt-1">Controle de acesso, papéis e permissões globais.</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" className="flex items-center gap-2">
             <span className="material-symbols-outlined text-[20px]">upload_file</span>
             Importar CSV
          </Button>
          <Button onClick={() => setShowModal(true)} className="flex items-center gap-2">
             <span className="material-symbols-outlined">person_add</span>
             Novo Usuário
          </Button>
        </div>
      </div>

      <Card className="p-4 flex flex-wrap items-center gap-4">
        <div className="relative flex-1 min-w-[300px]">
          <Input 
            icon="search" 
            placeholder="Buscar por nome, e-mail ou matrícula..." 
            className="w-full"
          />
        </div>
        <div className="flex gap-3 flex-wrap">
           <div className="w-40">
                <Select>
                    <option>Todos os Cargos</option>
                    <option>Aluno</option>
                    <option>Professor</option>
                    <option>Administrador</option>
                </Select>
           </div>
           <div className="w-40">
                <Select>
                    <option>Status: Todos</option>
                    <option>Ativo</option>
                    <option>Inativo</option>
                </Select>
           </div>
           <Button variant="ghost" className="text-harven-gold hover:text-harven-dark">
               Limpar Filtros
           </Button>
        </div>
      </Card>

      <Card className="flex flex-col flex-1 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-muted/30 border-b border-border">
              <tr>
                <th className="p-5 w-10"><input type="checkbox" className="size-4 rounded text-primary border-input focus:ring-primary" /></th>
                <th className="p-5 text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Usuário</th>
                <th className="p-5 text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Role</th>
                <th className="p-5 text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Status</th>
                <th className="p-5 text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Último Acesso</th>
                <th className="p-5 text-right"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {users.map((user) => (
                <tr key={user.id} className="hover:bg-muted/20 group transition-colors">
                  <td className="p-5"><input type="checkbox" className="size-4 rounded text-primary border-input focus:ring-primary" /></td>
                  <td className="p-5">
                    <div className="flex items-center gap-3">
                       <Avatar src={`https://picsum.photos/seed/${user.name}/100/100`} fallback={user.name} />
                       <div>
                          <p className="text-sm font-bold text-foreground">{user.name}</p>
                          <p className="text-xs text-muted-foreground font-medium">{user.email}</p>
                       </div>
                    </div>
                  </td>
                  <td className="p-5">
                    <Badge variant="outline">{user.role}</Badge>
                  </td>
                  <td className="p-5">
                    <Badge variant={getStatusVariant(user.status)}>{user.status}</Badge>
                  </td>
                  <td className="p-5 text-xs text-muted-foreground font-bold">{user.time}</td>
                  <td className="p-5 text-right">
                    <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                       <Button variant="ghost" size="icon" className="size-8"><span className="material-symbols-outlined text-[20px]">edit</span></Button>
                       <Button variant="ghost" size="icon" className="size-8 text-destructive hover:text-destructive"><span className="material-symbols-outlined text-[20px]">block</span></Button>
                       <Button variant="ghost" size="icon" className="size-8"><span className="material-symbols-outlined text-[20px]">more_vert</span></Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="p-4 border-t border-border flex items-center justify-between mt-auto bg-muted/10">
           <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Mostrando {users.length} usuários</span>
           <div className="flex gap-1">
              <Button variant="ghost" size="icon" className="size-8"><span className="material-symbols-outlined">chevron_left</span></Button>
              <Button variant="primary" size="icon" className="size-8 text-[10px]">1</Button>
              <Button variant="ghost" size="icon" className="size-8 text-[10px]">2</Button>
              <Button variant="ghost" size="icon" className="size-8 text-[10px]">3</Button>
              <span className="size-8 flex items-center justify-center text-muted-foreground">...</span>
              <Button variant="ghost" size="icon" className="size-8"><span className="material-symbols-outlined">chevron_right</span></Button>
           </div>
        </div>
      </Card>

      {/* Modal Criar Usuário */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm animate-in fade-in duration-200">
           <Card className="w-full max-w-lg shadow-2xl animate-in zoom-in-95 duration-200">
             <div className="p-6 border-b border-border bg-muted/20 flex justify-between items-center">
               <h3 className="text-lg font-display font-bold text-foreground">Criar Novo Usuário</h3>
               <button onClick={() => setShowModal(false)} className="text-muted-foreground hover:text-foreground">
                 <span className="material-symbols-outlined">close</span>
               </button>
             </div>
             
             <form onSubmit={handleCreateUser} className="p-6 flex flex-col gap-6">
                <div className="space-y-4">
                    <Input 
                        label="Nome Completo"
                        required
                        value={formData.name}
                        onChange={e => setFormData({...formData, name: e.target.value})}
                        placeholder="Ex: João da Silva"
                    />
                    <Input 
                        label="E-mail Institucional"
                        required
                        type="email"
                        value={formData.email}
                        onChange={e => setFormData({...formData, email: e.target.value})}
                        placeholder="Ex: joao@harven.edu"
                    />
                    <div className="grid grid-cols-2 gap-4">
                        <Select 
                            label="Função (Role)"
                            value={formData.role}
                            onChange={e => setFormData({...formData, role: e.target.value})}
                        >
                            <option>Aluno</option>
                            <option>Professor</option>
                            <option>Admin</option>
                        </Select>
                        <Select 
                            label="Status Inicial"
                            value={formData.status}
                            onChange={e => setFormData({...formData, status: e.target.value})}
                        >
                            <option>Ativo</option>
                            <option>Inativo</option>
                            <option>Pendente</option>
                        </Select>
                    </div>
                </div>

                <div className="flex gap-3 pt-2">
                    <Button type="button" variant="outline" fullWidth onClick={() => setShowModal(false)}>
                        Cancelar
                    </Button>
                    <Button type="submit" fullWidth>
                        Criar Usuário
                    </Button>
                </div>
             </form>
           </Card>
        </div>
      )}
    </div>
  );
};

export default UserManagement;
