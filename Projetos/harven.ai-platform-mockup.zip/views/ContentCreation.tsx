
import React, { useState, useEffect } from 'react';
import { ViewType } from '../types';

interface ContentCreationProps {
  onNavigate: (view: ViewType) => void;
}

const ContentCreation: React.FC<ContentCreationProps> = ({ onNavigate }) => {
  const [file, setFile] = useState<File | null>(null);
  const [mediaType, setMediaType] = useState<'text' | 'video' | 'audio'>('text');
  
  // Flow enforced: Upload -> Selection (Method) -> Processing/Manual
  const [step, setStep] = useState<'upload' | 'selection' | 'manual' | 'ai_processing'>('upload');
  const [processingProgress, setProcessingProgress] = useState(0);
  const [processingStage, setProcessingStage] = useState('Inicializando...');

  const [manualData, setManualData] = useState({ chapterTitle: '', question: '', answer: '' });

  const handleFileDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const fileName = mediaType === 'text' ? 'Nova_Aula_05.pdf' : mediaType === 'video' ? 'Aula_Video_01.mp4' : 'Audio_Explainer.mp3';
    setFile({ name: fileName, size: 2048000 } as any);
    setStep('selection'); // Move to method selection
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setStep('selection'); // Move to method selection
    }
  };

  const startAIProcessing = () => {
    setStep('ai_processing');
    let progress = 0;
    const stages = ['Lendo Arquivo...', 'Transcrevendo (Whisper)...', 'Analisando Estrutura Semântica...', 'Gerando Embeddings...', 'Finalizando...'];
    
    const interval = setInterval(() => {
      progress += 2;
      setProcessingProgress(progress);
      
      const stageIndex = Math.floor((progress / 100) * stages.length);
      setProcessingStage(stages[Math.min(stageIndex, stages.length - 1)]);

      if (progress >= 100) {
        clearInterval(interval);
        setTimeout(() => {
             onNavigate('CONTENT_REVISION');
        }, 500);
      }
    }, 100); // 5 segundos total
  };

  return (
    <div className="flex flex-col flex-1 h-full bg-harven-bg">
      <div className="max-w-5xl mx-auto w-full p-8 flex flex-col gap-8 h-full">
        
        {/* Header da View */}
        <div>
           <nav className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">
            <span className="cursor-pointer hover:text-harven-dark" onClick={() => onNavigate('COURSE_DETAILS')}>Cálculo I</span>
            <span className="material-symbols-outlined text-[14px]">chevron_right</span>
            <span className="text-harven-dark">Gerenciador de Conteúdo</span>
          </nav>
          <h1 className="text-3xl font-display font-bold text-harven-dark">
             Adicionar Conteúdo
          </h1>
        </div>

        {/* STEP 1: UPLOAD */}
        {step === 'upload' && (
           <div className="flex-1 flex flex-col items-center justify-center animate-in fade-in zoom-in-95 duration-300">
              
              {/* Media Type Selector */}
              <div className="flex gap-2 mb-6 bg-white p-1 rounded-xl border border-harven-border shadow-sm">
                  <button 
                    onClick={() => setMediaType('text')}
                    className={`px-4 py-2 rounded-lg text-xs font-bold uppercase transition-all flex items-center gap-2 ${mediaType === 'text' ? 'bg-harven-dark text-white' : 'text-gray-400 hover:text-harven-dark'}`}
                  >
                      <span className="material-symbols-outlined text-[18px]">description</span> Documento
                  </button>
                  <button 
                    onClick={() => setMediaType('video')}
                    className={`px-4 py-2 rounded-lg text-xs font-bold uppercase transition-all flex items-center gap-2 ${mediaType === 'video' ? 'bg-harven-dark text-white' : 'text-gray-400 hover:text-harven-dark'}`}
                  >
                      <span className="material-symbols-outlined text-[18px]">movie</span> Vídeo
                  </button>
                  <button 
                    onClick={() => setMediaType('audio')}
                    className={`px-4 py-2 rounded-lg text-xs font-bold uppercase transition-all flex items-center gap-2 ${mediaType === 'audio' ? 'bg-harven-dark text-white' : 'text-gray-400 hover:text-harven-dark'}`}
                  >
                      <span className="material-symbols-outlined text-[18px]">headphones</span> Áudio
                  </button>
              </div>

              <div 
                className="w-full max-w-2xl border-2 border-dashed border-gray-300 rounded-3xl p-12 flex flex-col items-center justify-center bg-white hover:border-primary hover:bg-primary/5 transition-all cursor-pointer group relative"
                onDragOver={(e) => e.preventDefault()}
                onDrop={handleFileDrop}
              >
                 <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={handleFileInput} accept={mediaType === 'text' ? '.pdf,.doc,.docx,.txt' : mediaType === 'video' ? '.mp4,.mov' : '.mp3,.wav'} />
                 <div className="size-20 bg-harven-bg rounded-full flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                    <span className="material-symbols-outlined text-4xl text-gray-400 group-hover:text-primary-dark">
                        {mediaType === 'text' ? 'cloud_upload' : mediaType === 'video' ? 'video_file' : 'audio_file'}
                    </span>
                 </div>
                 <h3 className="text-xl font-bold text-harven-dark mb-2">
                     {mediaType === 'text' ? 'Arraste seu documento (PDF/DOC)' : mediaType === 'video' ? 'Arraste seu vídeo (MP4/MOV)' : 'Arraste seu áudio (MP3/WAV)'}
                 </h3>
                 <p className="text-gray-500 mb-8">Conteúdo base para a aula</p>
                 <div className="flex gap-4 text-xs font-bold text-gray-400 uppercase tracking-widest">
                    {mediaType === 'text' && <span>PDF • DOCX • PPTX • TXT</span>}
                    {mediaType === 'video' && <span>MP4 • MOV • AVI • WEBM</span>}
                    {mediaType === 'audio' && <span>MP3 • WAV • OGG • M4A</span>}
                 </div>
              </div>
           </div>
        )}

        {/* STEP 2: SELECTION (METHOD) */}
        {step === 'selection' && (
           <div className="flex-1 flex flex-col gap-8 animate-in slide-in-from-bottom-4 duration-500">
              <div className="bg-white p-4 rounded-xl border border-harven-border flex items-center gap-4 shadow-sm">
                 <div className="size-10 bg-green-50 text-green-600 rounded-lg flex items-center justify-center">
                    <span className="material-symbols-outlined">
                        {mediaType === 'text' ? 'description' : mediaType === 'video' ? 'movie' : 'headphones'}
                    </span>
                 </div>
                 <div className="flex-1">
                    <p className="text-sm font-bold text-harven-dark">{file?.name || 'Nova_Aula_05.pdf'}</p>
                    <p className="text-xs text-gray-400">Pronto para processamento</p>
                 </div>
                 <button onClick={() => setStep('upload')} className="text-xs font-bold text-gray-400 hover:text-red-500 uppercase">Trocar</button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 h-full max-h-[400px]">
                 {/* Card AI */}
                 <button 
                   onClick={startAIProcessing}
                   className="bg-white border-2 border-primary/20 rounded-3xl p-8 flex flex-col gap-6 text-left hover:border-primary hover:shadow-xl hover:shadow-primary/10 transition-all group relative overflow-hidden"
                 >
                    <div className="absolute top-6 right-6">
                        <span className="bg-primary text-harven-dark text-[10px] font-black px-2 py-1 rounded uppercase shadow-sm">BETA</span>
                    </div>
                    <div className="absolute top-0 right-0 size-40 bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 group-hover:bg-primary/20 transition-colors"></div>
                    <div className="size-14 bg-primary rounded-2xl flex items-center justify-center text-harven-dark shadow-lg shadow-primary/20 group-hover:scale-110 transition-transform">
                       <span className="material-symbols-outlined text-3xl fill-1">auto_awesome</span>
                    </div>
                    <div>
                       <h3 className="text-2xl font-display font-bold text-harven-dark mb-2">Processamento Inteligente (IA)</h3>
                       <p className="text-gray-500 leading-relaxed">
                          A Harven AI analisará o conteúdo, extrairá conceitos-chave e gerará automaticamente perguntas socráticas e a estrutura da aula.
                       </p>
                    </div>
                    <div className="mt-auto flex items-center gap-2 text-sm font-bold text-primary-dark uppercase tracking-wide">
                       Recomendado <span className="material-symbols-outlined">arrow_forward</span>
                    </div>
                 </button>

                 {/* Card Manual */}
                 <button 
                   onClick={() => setStep('manual')}
                   className="bg-white border-2 border-harven-border rounded-3xl p-8 flex flex-col gap-6 text-left hover:border-gray-400 transition-all group"
                 >
                    <div className="size-14 bg-harven-bg rounded-2xl flex items-center justify-center text-gray-500 group-hover:bg-gray-200 transition-colors">
                       <span className="material-symbols-outlined text-3xl">edit_document</span>
                    </div>
                    <div>
                       <h3 className="text-2xl font-display font-bold text-harven-dark mb-2">Processamento Manual</h3>
                       <p className="text-gray-500 leading-relaxed">
                          Você define a estrutura do capítulo e escreve as perguntas e respostas esperadas manualmente. Ideal para controle total.
                       </p>
                    </div>
                    <div className="mt-auto flex items-center gap-2 text-sm font-bold text-gray-400 group-hover:text-harven-dark uppercase tracking-wide transition-colors">
                       Selecionar <span className="material-symbols-outlined">arrow_forward</span>
                    </div>
                 </button>
              </div>
           </div>
        )}

        {/* STEP 3: MANUAL EDITOR */}
        {step === 'manual' && (
           <div className="flex-1 bg-white rounded-2xl border border-harven-border shadow-sm flex flex-col overflow-hidden animate-in fade-in slide-in-from-right-4 duration-500">
              <div className="p-6 border-b border-harven-border bg-harven-bg flex justify-between items-center">
                 <h3 className="font-bold text-harven-dark flex items-center gap-2">
                    <span className="material-symbols-outlined text-gray-400">edit</span>
                    Editor Manual
                 </h3>
                 <button onClick={() => setStep('selection')} className="text-gray-400 hover:text-harven-dark">Cancelar</button>
              </div>
              <div className="p-8 flex-1 overflow-y-auto space-y-6">
                 <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Título do Capítulo</label>
                    <input 
                      className="w-full bg-harven-bg border-none rounded-lg p-3 focus:ring-1 focus:ring-primary text-harven-dark" 
                      placeholder="Ex: Introdução à Derivadas"
                      value={manualData.chapterTitle}
                      onChange={e => setManualData({...manualData, chapterTitle: e.target.value})}
                    />
                 </div>
                 <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Pergunta Socrática</label>
                    <textarea 
                      className="w-full bg-harven-bg border-none rounded-lg p-3 focus:ring-1 focus:ring-primary min-h-[100px] text-harven-dark" 
                      placeholder="Ex: Como a inclinação da reta tangente se relaciona com a taxa de variação instantânea?"
                      value={manualData.question}
                      onChange={e => setManualData({...manualData, question: e.target.value})}
                    />
                 </div>
                 <div className="space-y-2">
                    <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Resposta Esperada / Conceito Chave</label>
                    <textarea 
                      className="w-full bg-harven-bg border-none rounded-lg p-3 focus:ring-1 focus:ring-primary min-h-[100px] text-harven-dark" 
                      placeholder="O aluno deve mencionar o limite da reta secante..."
                      value={manualData.answer}
                      onChange={e => setManualData({...manualData, answer: e.target.value})}
                    />
                 </div>
              </div>
              <div className="p-6 border-t border-harven-border bg-gray-50 flex justify-end gap-3">
                 <button className="px-6 py-2 border border-harven-border rounded-lg text-sm font-bold text-harven-dark hover:bg-white">Adicionar Outra Pergunta</button>
                 <button 
                    onClick={() => onNavigate('CONTENT_REVISION')}
                    className="px-6 py-2 bg-primary hover:bg-primary-dark text-harven-dark rounded-lg text-sm font-bold shadow-lg shadow-primary/20"
                 >
                    Salvar e Revisar
                 </button>
              </div>
           </div>
        )}

        {/* STEP 4: AI PROCESSING LOADER */}
        {step === 'ai_processing' && (
           <div className="flex-1 flex flex-col items-center justify-center animate-in fade-in duration-700">
              <div className="w-full max-w-md text-center space-y-8">
                 <div className="relative size-32 mx-auto">
                    <div className="absolute inset-0 border-4 border-harven-bg rounded-full"></div>
                    <div 
                      className="absolute inset-0 border-4 border-primary rounded-full border-t-transparent animate-spin"
                      style={{ animationDuration: '1.5s' }}
                    ></div>
                    <div className="absolute inset-0 flex items-center justify-center">
                       <span className="material-symbols-outlined text-4xl text-harven-gold animate-pulse">psychology</span>
                    </div>
                 </div>
                 
                 <div>
                    <h3 className="text-2xl font-display font-bold text-harven-dark mb-2">Analisando Conteúdo</h3>
                    <p className="text-primary-dark font-mono text-sm">{processingStage}</p>
                 </div>

                 <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                    <div 
                      className="bg-primary h-full rounded-full transition-all duration-300 ease-out"
                      style={{ width: `${processingProgress}%` }}
                    ></div>
                 </div>
                 
                 <p className="text-xs text-gray-400">Isso pode levar alguns segundos dependendo do tamanho do arquivo.</p>
              </div>
           </div>
        )}

      </div>
    </div>
  );
};

export default ContentCreation;
