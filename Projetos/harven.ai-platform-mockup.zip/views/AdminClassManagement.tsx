
import React, { useState } from 'react';
import { ViewType } from '../types';

interface AdminClassManagementProps {
  onNavigate: (view: ViewType) => void;
}

const AdminClassManagement: React.FC<AdminClassManagementProps> = ({ onNavigate }) => {
  const [showModal, setShowModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [modalTab, setModalTab] = useState<'info' | 'professors' | 'students'>('info');

  // Mock Global Students Database para busca
  const allStudentsDB = [
      { id: 101, name: 'Ana Silva', matricula: '2024101', email: 'ana.silva@harven.edu' },
      { id: 102, name: 'Bruno Santos', matricula: '2024102', email: 'bruno.s@harven.edu' },
      { id: 103, name: 'Carla Dias', matricula: '2024103', email: 'carla.d@harven.edu' },
      { id: 104, name: 'Daniel Oliveira', matricula: '2024104', email: 'daniel.o@harven.edu' },
      { id: 105, name: 'Eduarda Lima', matricula: '2024105', email: 'duda.l@harven.edu' },
      { id: 106, name: 'Fernando Costa', matricula: '2024106', email: 'fernando.c@harven.edu' },
      { id: 107, name: 'Gabriela Rocha', matricula: '2024107', email: 'gabi.r@harven.edu' },
      { id: 108, name: 'Hugo Martins', matricula: '2024108', email: 'hugo.m@harven.edu' },
      { id: 109, name: 'Isabela Ferreira', matricula: '2024109', email: 'isa.f@harven.edu' },
      { id: 110, name: 'João Pedro', matricula: '2024110', email: 'jp.souza@harven.edu' },
  ];

  // Estados para gerenciar alunos no modal
  const [studentSearch, setStudentSearch] = useState('');
  const [searchResults, setSearchResults] = useState<typeof allStudentsDB>([]);
  
  const [enrolledStudents, setEnrolledStudents] = useState([
      { id: 1, name: 'Aluno Exemplo 1', matricula: '2024001' },
      { id: 2, name: 'Aluno Exemplo 2', matricula: '2024002' },
      { id: 3, name: 'Aluno Exemplo 3', matricula: '2024003' },
  ]);

  const [classes, setClasses] = useState([
    { id: 1, name: 'Engenharia de Produção - Turma A', code: 'EP-2024.1-A', year: '2024.1', students: 45, disciplines: 5, status: 'Ativa', department: 'Engenharia' },
    { id: 2, name: 'Direito Constitucional - Noturno', code: 'DIR-2024.1-N', year: '2024.1', students: 60, disciplines: 3, status: 'Ativa', department: 'Direito' },
    { id: 3, name: 'Medicina - Anatomia II', code: 'MED-2023.2-B', year: '2023.2', students: 30, disciplines: 2, status: 'Finalizada', department: 'Saúde' },
  ]);

  const [formData, setFormData] = useState({
    name: '',
    code: '',
    year: '2024.1',
    department: 'Engenharia'
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      setClasses([...classes, { 
        id: classes.length + 1, 
        ...formData, 
        students: enrolledStudents.length, 
        disciplines: 0, 
        status: 'Planejamento' 
      }]);
      setIsSubmitting(false);
      setShowModal(false);
      setFormData({ name: '', code: '', year: '2024.1', department: 'Engenharia' });
      setEnrolledStudents([{ id: 1, name: 'Aluno Exemplo 1', matricula: '2024001' }]); // Reset mock
    }, 1000);
  };

  const handleSearchStudent = (e: React.ChangeEvent<HTMLInputElement>) => {
      const term = e.target.value;
      setStudentSearch(term);
      
      if (term.trim().length > 0) {
          const results = allStudentsDB.filter(student => 
              (student.name.toLowerCase().includes(term.toLowerCase()) || 
               student.matricula.includes(term) || 
               student.email.toLowerCase().includes(term.toLowerCase())) &&
              !enrolledStudents.some(enrolled => enrolled.matricula === student.matricula)
          );
          setSearchResults(results);
      } else {
          setSearchResults([]);
      }
  };

  const handleSelectStudent = (student: typeof allStudentsDB[0]) => {
      setEnrolledStudents([...enrolledStudents, { 
          id: student.id, 
          name: student.name, 
          matricula: student.matricula 
      }]);
      setStudentSearch('');
      setSearchResults([]);
  };

  const handleRemoveStudent = (id: number) => {
      setEnrolledStudents(enrolledStudents.filter(s => s.id !== id));
  };

  return (
    <div className="max-w-7xl mx-auto p-8 flex flex-col gap-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-display font-bold text-harven-dark tracking-tight">Gestão de Turmas</h2>
          <p className="text-gray-500">Administre as turmas, matricule alunos e atribua grades curriculares.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-white border border-harven-border rounded-lg p-1 flex shadow-sm">
            <button 
                onClick={() => setViewMode('grid')}
                className={`p-2 rounded transition-colors ${viewMode === 'grid' ? 'bg-harven-bg text-harven-dark' : 'text-gray-400 hover:text-harven-dark'}`}
            >
                <span className={`material-symbols-outlined text-[20px] ${viewMode === 'grid' ? 'fill-1' : ''}`}>grid_view</span>
            </button>
            <button 
                onClick={() => setViewMode('list')}
                className={`p-2 rounded transition-colors ${viewMode === 'list' ? 'bg-harven-bg text-harven-dark' : 'text-gray-400 hover:text-harven-dark'}`}
            >
                <span className={`material-symbols-outlined text-[20px] ${viewMode === 'list' ? 'fill-1' : ''}`}>view_list</span>
            </button>
          </div>
          <button 
            onClick={() => setShowModal(true)}
            className="bg-primary hover:bg-primary-dark transition-all text-harven-dark font-bold px-5 py-2.5 rounded-lg flex items-center gap-2 shadow-lg shadow-primary/10"
          >
            <span className="material-symbols-outlined">add</span>
            Nova Turma
          </button>
        </div>
      </div>

      <div className="bg-white p-4 rounded-xl border border-harven-border shadow-sm flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-harven-gold">search</span>
          <input className="w-full bg-harven-bg border-none rounded-lg pl-10 pr-4 py-2.5 text-sm focus:ring-1 focus:ring-primary text-harven-dark" placeholder="Buscar turma, código ou ano..." />
        </div>
        <div className="flex gap-3">
          <button className="px-4 py-2 bg-white border border-harven-border rounded-lg text-sm font-bold text-harven-dark flex items-center gap-2">
            <span className="material-symbols-outlined text-gray-400">filter_list</span> Ano Letivo <span className="material-symbols-outlined text-[16px]">expand_more</span>
          </button>
        </div>
      </div>

      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {classes.map((cls) => (
                <div key={cls.id} className="bg-white rounded-xl border border-harven-border p-6 shadow-sm hover:border-primary transition-all group cursor-pointer relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-5">
                        <span className="material-symbols-outlined text-6xl">school</span>
                    </div>
                    <div className="flex justify-between items-start mb-4">
                        <span className="bg-harven-bg text-harven-dark font-mono font-bold text-xs px-2 py-1 rounded border border-harven-border">{cls.code}</span>
                        <span className={`text-[9px] font-bold px-2 py-0.5 rounded uppercase border ${cls.status === 'Ativa' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-gray-100 text-gray-600 border-gray-200'}`}>{cls.status}</span>
                    </div>
                    <h3 className="text-lg font-bold text-harven-dark group-hover:text-primary-dark transition-colors mb-1">{cls.name}</h3>
                    <p className="text-xs text-gray-500 font-medium mb-4">{cls.department} • {cls.year}</p>
                    
                    <div className="grid grid-cols-2 gap-4 border-t border-harven-bg pt-4">
                        <div>
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Alunos</p>
                            <p className="text-xl font-display font-bold text-harven-dark">{cls.students}</p>
                        </div>
                        <div>
                            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Disciplinas</p>
                            <p className="text-xl font-display font-bold text-harven-dark">{cls.disciplines}</p>
                        </div>
                    </div>
                    <div className="mt-4 flex gap-2">
                        <button onClick={() => setShowModal(true)} className="flex-1 py-2 bg-harven-bg hover:bg-primary group-hover:bg-primary group-hover:text-harven-dark rounded-lg text-xs font-bold text-harven-dark transition-all">Gerenciar</button>
                    </div>
                </div>
            ))}
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-harven-border overflow-hidden">
            <table className="w-full text-left">
                <thead className="bg-harven-bg/50 border-b border-harven-border text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                    <tr>
                        <th className="p-4">Código</th>
                        <th className="p-4">Nome da Turma</th>
                        <th className="p-4">Ano/Semestre</th>
                        <th className="p-4">Alunos</th>
                        <th className="p-4">Disciplinas</th>
                        <th className="p-4">Status</th>
                        <th className="p-4 text-right">Ações</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-harven-bg">
                    {classes.map((cls) => (
                        <tr key={cls.id} className="hover:bg-harven-bg/20 group transition-colors">
                            <td className="p-4 font-mono text-xs font-bold text-gray-600">{cls.code}</td>
                            <td className="p-4 text-sm font-bold text-harven-dark">{cls.name}</td>
                            <td className="p-4 text-sm text-gray-500">{cls.year}</td>
                            <td className="p-4 text-sm text-gray-500">{cls.students}</td>
                            <td className="p-4 text-sm text-gray-500">{cls.disciplines}</td>
                            <td className="p-4">
                                <span className={`text-[9px] font-bold px-2 py-0.5 rounded uppercase border ${cls.status === 'Ativa' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-gray-100 text-gray-600 border-gray-200'}`}>{cls.status}</span>
                            </td>
                            <td className="p-4 text-right">
                                <button onClick={() => setShowModal(true)} className="text-gray-400 hover:text-primary-dark transition-colors"><span className="material-symbols-outlined">edit</span></button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
      )}

      {/* Modal de Gestão/Criação Turma */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-harven-dark/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl flex flex-col overflow-hidden animate-in zoom-in-95 duration-200 max-h-[90vh]">
            <div className="p-6 border-b border-harven-border bg-harven-bg flex justify-between items-center">
              <h3 className="text-lg font-display font-bold text-harven-dark">Gestão da Turma</h3>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-harven-dark">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            
            {/* Tabs do Modal */}
            <div className="flex border-b border-harven-border px-6">
                {[
                    { id: 'info', label: 'Dados Gerais' },
                    { id: 'professors', label: 'Professores' },
                    { id: 'students', label: 'Alunos' }
                ].map(tab => (
                    <button
                        key={tab.id}
                        onClick={() => setModalTab(tab.id as any)}
                        className={`px-4 py-3 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors ${modalTab === tab.id ? 'border-primary text-harven-dark' : 'border-transparent text-gray-400 hover:text-harven-dark'}`}
                    >
                        {tab.label}
                    </button>
                ))}
            </div>

            <form onSubmit={handleCreate} className="flex-1 overflow-y-auto p-6 flex flex-col gap-6">
                {modalTab === 'info' && (
                    <div className="space-y-4 animate-in fade-in slide-in-from-right-2 duration-300">
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Nome da Turma</label>
                            <input required value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full bg-harven-bg border-none rounded-lg px-4 py-2.5 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark" placeholder="Ex: Engenharia Civil 2024" />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-1.5">
                                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Código</label>
                                <input required value={formData.code} onChange={e => setFormData({...formData, code: e.target.value})} className="w-full bg-harven-bg border-none rounded-lg px-4 py-2.5 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark" placeholder="EC-24" />
                            </div>
                            <div className="space-y-1.5">
                                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Ano/Semestre</label>
                                <select value={formData.year} onChange={e => setFormData({...formData, year: e.target.value})} className="w-full bg-harven-bg border-none rounded-lg px-4 py-2.5 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark">
                                    <option>2024.1</option>
                                    <option>2024.2</option>
                                    <option>2025.1</option>
                                </select>
                            </div>
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Departamento Principal</label>
                            <select value={formData.department} onChange={e => setFormData({...formData, department: e.target.value})} className="w-full bg-harven-bg border-none rounded-lg px-4 py-2.5 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark">
                                <option>Engenharia</option>
                                <option>Direito</option>
                                <option>Saúde</option>
                                <option>Humanidades</option>
                            </select>
                        </div>
                    </div>
                )}

                {modalTab === 'professors' && (
                    <div className="space-y-4 animate-in fade-in slide-in-from-right-2 duration-300">
                        <div className="flex gap-2">
                            <input className="flex-1 bg-harven-bg border-none rounded-lg px-4 py-2 text-sm" placeholder="Buscar professor..." />
                            <button type="button" className="bg-harven-dark text-primary px-4 rounded-lg font-bold text-xs">Adicionar</button>
                        </div>
                        <div className="space-y-2 max-h-[300px] overflow-y-auto">
                            {['Prof. Elena Vance', 'Dr. Alan Turing', 'Msc. Roberto Campos'].map((prof, i) => (
                                <div key={i} className="flex justify-between items-center p-3 border border-harven-border rounded-lg">
                                    <div className="flex items-center gap-3">
                                        <div className="size-8 bg-harven-bg rounded-full flex items-center justify-center font-bold text-xs text-gray-500">{prof.charAt(0)}</div>
                                        <span className="text-sm font-bold text-harven-dark">{prof}</span>
                                    </div>
                                    <button type="button" className="text-red-500 hover:bg-red-50 p-1 rounded"><span className="material-symbols-outlined text-[18px]">remove_circle</span></button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {modalTab === 'students' && (
                    <div className="space-y-4 animate-in fade-in slide-in-from-right-2 duration-300">
                        <div className="flex justify-between items-center bg-gray-50 p-3 rounded-lg border border-harven-border">
                            <span className="text-xs font-bold text-gray-500">Matrícula em Massa</span>
                            <button type="button" className="text-primary-dark font-bold text-xs underline">Importar CSV</button>
                        </div>
                        
                        <div className="relative">
                             <div className="flex gap-2">
                                 <div className="relative flex-1">
                                    <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">search</span>
                                    <input 
                                    value={studentSearch}
                                    onChange={handleSearchStudent}
                                    className="w-full bg-harven-bg border-none rounded-lg pl-10 pr-4 py-2 text-sm focus:ring-1 focus:ring-primary" 
                                    placeholder="Buscar aluno por nome, matrícula ou email..." 
                                    />
                                 </div>
                             </div>
                             
                             {/* Search Results Dropdown */}
                             {searchResults.length > 0 && (
                                 <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-harven-border rounded-lg shadow-xl max-h-48 overflow-y-auto z-10 animate-in fade-in duration-100">
                                     {searchResults.map(student => (
                                         <button
                                            key={student.id}
                                            type="button"
                                            onClick={() => handleSelectStudent(student)}
                                            className="w-full text-left px-4 py-3 hover:bg-harven-bg flex justify-between items-center group transition-colors border-b border-harven-bg last:border-0"
                                         >
                                            <div>
                                                <p className="text-sm font-bold text-harven-dark">{student.name}</p>
                                                <p className="text-[10px] text-gray-400 font-bold">{student.email} • {student.matricula}</p>
                                            </div>
                                            <span className="material-symbols-outlined text-primary opacity-0 group-hover:opacity-100 transition-opacity">add_circle</span>
                                         </button>
                                     ))}
                                 </div>
                             )}
                        </div>

                        <div className="space-y-2 max-h-[300px] overflow-y-auto">
                            {enrolledStudents.map((student, i) => (
                                <div key={i} className="flex justify-between items-center p-3 border border-harven-border rounded-lg bg-white">
                                    <div className="flex items-center gap-3">
                                        <div className="size-8 bg-harven-bg rounded-full flex items-center justify-center text-xs font-bold text-gray-500">{student.name.charAt(0)}</div>
                                        <div>
                                            <p className="text-sm font-bold text-harven-dark">{student.name}</p>
                                            <p className="text-[10px] text-gray-400">Matrícula: {student.matricula}</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <span className="text-green-600 text-[10px] font-bold uppercase bg-green-50 px-2 py-0.5 rounded">Matriculado</span>
                                        <button 
                                            type="button"
                                            onClick={() => handleRemoveStudent(student.id)}
                                            className="text-gray-300 hover:text-red-500 transition-colors"
                                        >
                                            <span className="material-symbols-outlined text-[18px]">remove_circle</span>
                                        </button>
                                    </div>
                                </div>
                            ))}
                            {enrolledStudents.length === 0 && (
                                <div className="text-center py-8 text-gray-400 text-xs italic border-2 border-dashed border-gray-200 rounded-lg">
                                    Nenhum aluno matriculado nesta turma.
                                </div>
                            )}
                        </div>
                    </div>
                )}

                <div className="pt-2 flex gap-3 border-t border-harven-border mt-auto">
                    <button type="button" onClick={() => setShowModal(false)} className="flex-1 py-3 border border-harven-border rounded-xl text-xs font-bold text-harven-dark hover:bg-gray-50 transition-colors uppercase tracking-widest">Fechar</button>
                    <button type="submit" disabled={isSubmitting} className="flex-1 py-3 bg-primary hover:bg-primary-dark rounded-xl text-xs font-bold text-harven-dark transition-all uppercase tracking-widest shadow-lg shadow-primary/20 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed">
                        {isSubmitting ? 'Salvando...' : 'Salvar Alterações'}
                    </button>
                </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminClassManagement;
