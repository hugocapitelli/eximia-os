
import React, { useState } from 'react';
import { ViewType } from '../types';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';

interface InstructorListProps {
  onNavigate: (view: ViewType) => void;
}

const InstructorList: React.FC<InstructorListProps> = ({ onNavigate }) => {
  const [showModal, setShowModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Estado inicial das Turmas
  const [classes, setClasses] = useState([
    { title: 'Engenharia de Software 2024.1', code: 'ES-24.1', students: 45, subjects: 3, progress: 78, status: 'Ativa', icon: 'terminal', department: 'Engenharia', iconUrl: null as string | null },
    { title: 'Ciência da Computação - Turma A', code: 'CC-24.A', students: 32, subjects: 5, progress: 45, status: 'Ativa', icon: 'code', department: 'Computação', iconUrl: null },
    { title: 'Cálculo I - Manhã', code: 'CAL-101-M', students: 60, subjects: 1, progress: 60, status: 'Ativa', icon: 'calculate', department: 'Matemática', iconUrl: null },
    { title: 'Gestão de Projetos - Noturno', code: 'GP-N24', students: 25, subjects: 2, progress: 88, status: 'Ativa', icon: 'work', department: 'Negócios', iconUrl: null },
  ]);

  const [formData, setFormData] = useState({
    title: '',
    code: '',
    department: 'Engenharia',
    icon: 'school',
    iconUrl: null as string | null
  });

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    setTimeout(() => {
      const newClass = {
        title: formData.title,
        code: formData.code.toUpperCase(),
        department: formData.department,
        icon: formData.icon,
        students: 0,
        subjects: 0,
        progress: 0,
        status: 'Rascunho' as const,
        iconUrl: formData.iconUrl
      };

      setClasses([newClass, ...classes]);
      setIsSubmitting(false);
      setShowModal(false);
      setFormData({ title: '', code: '', department: 'Engenharia', icon: 'school', iconUrl: null });
      onNavigate('INSTRUCTOR_DETAIL');
    }, 1000);
  };

  const handleIconUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          setFormData({ ...formData, iconUrl: URL.createObjectURL(file) });
      }
  };

  const availableIcons = [
      'school', 'code', 'science', 'history_edu', 
      'palette', 'psychology', 'calculate', 'database',
      'biotech', 'gavel', 'balance', 'architecture',
      'music_note', 'lan', 'rocket_launch', 'groups'
  ];

  return (
    <div className="max-w-7xl mx-auto p-8 flex flex-col gap-8 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-display font-bold text-foreground tracking-tight">Minhas Turmas</h2>
          <p className="text-muted-foreground">Gerencie as turmas onde você leciona, seus alunos e disciplinas.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="bg-background border border-border rounded-lg p-1 flex shadow-sm">
            <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setViewMode('grid')}
                className={`size-9 ${viewMode === 'grid' ? 'bg-muted text-foreground' : 'text-muted-foreground'}`}
            >
                <span className={`material-symbols-outlined text-[20px] ${viewMode === 'grid' ? 'fill-1' : ''}`}>grid_view</span>
            </Button>
            <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setViewMode('list')}
                className={`size-9 ${viewMode === 'list' ? 'bg-muted text-foreground' : 'text-muted-foreground'}`}
            >
                <span className={`material-symbols-outlined text-[20px] ${viewMode === 'list' ? 'fill-1' : ''}`}>view_list</span>
            </Button>
          </div>
          <Button onClick={() => setShowModal(true)} className="flex items-center gap-2">
            <span className="material-symbols-outlined">add</span>
            Nova Turma
          </Button>
        </div>
      </div>

      <Card className="p-4 flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Input icon="search" placeholder="Buscar por turma, código..." className="w-full" />
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="flex items-center gap-2">
            <span className="material-symbols-outlined text-muted-foreground">filter_list</span> Status <span className="material-symbols-outlined text-[16px]">expand_more</span>
          </Button>
          <Button variant="outline" className="flex items-center gap-2">
             Recentes primeiro <span className="material-symbols-outlined text-[16px]">expand_more</span>
          </Button>
        </div>
      </Card>

      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {classes.map((cls, i) => (
            <Card 
                key={i} 
                hoverEffect
                className="flex flex-col animate-in zoom-in-95 duration-300 relative h-full"
                onClick={() => onNavigate('INSTRUCTOR_DETAIL')}
            >
                <div className="h-24 bg-gradient-to-br from-foreground to-foreground/80 p-5 flex items-end relative overflow-hidden">
                    <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>
                    
                    <div className="absolute top-3 right-3">
                        <Badge variant={cls.status === 'Ativa' ? 'success' : 'default'} className="border-white/20 bg-white/10 text-white backdrop-blur-sm">
                            {cls.status}
                        </Badge>
                    </div>
                    <div className="bg-background size-12 rounded-lg shadow-lg flex items-center justify-center text-foreground relative z-10 group-hover:scale-110 transition-transform duration-300 overflow-hidden">
                        {cls.iconUrl ? (
                            <img src={cls.iconUrl} alt="icon" className="w-full h-full object-cover" />
                        ) : (
                            <span className="material-symbols-outlined text-[32px]">{cls.icon}</span>
                        )}
                    </div>
                </div>
                <div className="p-5 flex-1 flex flex-col">
                    <h3 className="text-lg font-display font-bold text-foreground group-hover:text-primary-dark transition-colors leading-tight line-clamp-1">{cls.title}</h3>
                    <p className="text-xs text-muted-foreground mt-1 font-bold">{cls.code} • {cls.department}</p>
                    
                    <div className="grid grid-cols-2 gap-4 mt-6">
                        <div className="flex items-center gap-2 text-muted-foreground">
                        <span className="material-symbols-outlined text-[18px]">auto_stories</span>
                        <span className="text-xs font-bold">{cls.subjects} Disciplinas</span>
                        </div>
                        <div className="flex items-center gap-2 text-muted-foreground">
                        <span className="material-symbols-outlined text-[18px]">groups</span>
                        <span className="text-xs font-bold">{cls.students} Alunos</span>
                        </div>
                    </div>

                    <div className="mt-8 pt-4 border-t border-border">
                        <div className="flex justify-between text-[10px] font-bold uppercase tracking-wider text-muted-foreground mb-1.5">
                        <span>Progresso da Turma</span>
                        <span className="text-foreground">{cls.progress}%</span>
                        </div>
                        <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                        <div className="h-full bg-primary rounded-full" style={{ width: `${cls.progress}%` }}></div>
                        </div>
                    </div>
                </div>

                {/* Edit Action Absolute Positioned */}
                <Button 
                    size="icon"
                    variant="outline"
                    onClick={(e) => { e.stopPropagation(); onNavigate('DISCIPLINE_EDIT'); }}
                    className="absolute top-24 right-4 -translate-y-1/2 rounded-full size-8 shadow-sm z-20"
                    title="Editar Turma"
                >
                    <span className="material-symbols-outlined text-[16px]">edit</span>
                </Button>
            </Card>
            ))}

            <Card 
                hoverEffect
                className="border-dashed flex flex-col items-center justify-center p-8 gap-4 min-h-[300px] bg-muted/20"
                onClick={() => setShowModal(true)}
            >
                <div className="size-16 rounded-full bg-muted flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                    <span className="material-symbols-outlined text-muted-foreground group-hover:text-primary-dark text-3xl">add</span>
                </div>
                <div className="text-center">
                    <p className="text-sm font-bold text-foreground group-hover:text-primary-dark transition-colors">Criar Nova Turma</p>
                    <p className="text-xs text-muted-foreground mt-1">Configure um novo grupo de alunos</p>
                </div>
            </Card>
        </div>
      ) : (
        <Card className="flex flex-col gap-4 overflow-hidden">
            <div className="grid grid-cols-12 gap-4 p-4 border-b border-border bg-muted/30 text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
                <div className="col-span-5">Turma</div>
                <div className="col-span-2">Disciplinas</div>
                <div className="col-span-2">Alunos</div>
                <div className="col-span-2">Status</div>
                <div className="col-span-1 text-right">Ações</div>
            </div>
            {classes.map((cls, i) => (
                <div key={i} className="grid grid-cols-12 gap-4 p-4 border-b border-border hover:bg-muted/20 items-center group transition-colors cursor-pointer" onClick={() => onNavigate('INSTRUCTOR_DETAIL')}>
                    <div className="col-span-5 flex items-center gap-4">
                        <div className="size-10 rounded-lg bg-muted border border-border flex items-center justify-center text-foreground overflow-hidden">
                            {cls.iconUrl ? <img src={cls.iconUrl} className="w-full h-full object-cover" /> : <span className="material-symbols-outlined">{cls.icon}</span>}
                        </div>
                        <div>
                            <h4 className="text-sm font-bold text-foreground group-hover:text-primary-dark transition-colors">{cls.title}</h4>
                            <p className="text-[10px] text-muted-foreground font-bold">{cls.code} • {cls.department}</p>
                        </div>
                    </div>
                    <div className="col-span-2 text-sm text-muted-foreground font-medium">{cls.subjects} Disciplinas</div>
                    <div className="col-span-2 text-sm text-muted-foreground font-medium">{cls.students} Alunos</div>
                    <div className="col-span-2">
                        <Badge variant={cls.status === 'Ativa' ? 'success' : 'default'}>{cls.status}</Badge>
                    </div>
                    <div className="col-span-1 flex justify-end gap-2">
                        <Button variant="ghost" size="icon" onClick={(e) => { e.stopPropagation(); onNavigate('DISCIPLINE_EDIT'); }} className="size-8"><span className="material-symbols-outlined text-[18px]">edit</span></Button>
                    </div>
                </div>
            ))}
        </Card>
      )}

      {/* Modal de Criação */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm animate-in fade-in duration-200">
          <Card className="w-full max-w-lg flex flex-col overflow-hidden animate-in zoom-in-95 duration-200 shadow-2xl">
            <div className="p-6 border-b border-border bg-muted/20 flex justify-between items-center">
              <h3 className="text-lg font-display font-bold text-foreground">Nova Turma</h3>
              <button onClick={() => setShowModal(false)} className="text-muted-foreground hover:text-foreground">
                <span className="material-symbols-outlined">close</span>
              </button>
            </div>
            
            <form onSubmit={handleCreate} className="p-6 flex flex-col gap-6">
              
              <div className="flex gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Ícone</label>
                  <div className="grid grid-cols-4 gap-2 h-32 overflow-y-auto custom-scrollbar p-1">
                    {availableIcons.map(icon => (
                      <button 
                        key={icon}
                        type="button"
                        onClick={() => setFormData({...formData, icon, iconUrl: null})}
                        className={`size-10 rounded-lg flex items-center justify-center border transition-all ${formData.icon === icon && !formData.iconUrl ? 'bg-primary text-harven-dark border-primary shadow-sm' : 'bg-background border-border text-muted-foreground hover:border-primary/50'}`}
                      >
                        <span className="material-symbols-outlined text-[20px]">{icon}</span>
                      </button>
                    ))}
                    <label className={`size-10 rounded-lg flex items-center justify-center border transition-all cursor-pointer ${formData.iconUrl ? 'bg-primary border-primary' : 'bg-muted border-dashed border-border'}`}>
                        {formData.iconUrl ? (
                            <img src={formData.iconUrl} className="w-full h-full object-cover rounded-lg" alt="Custom" />
                        ) : (
                            <span className="material-symbols-outlined text-[20px] text-muted-foreground">upload</span>
                        )}
                        <input type="file" className="hidden" accept="image/*" onChange={handleIconUpload} />
                    </label>
                  </div>
                </div>
                <div className="flex-1 space-y-4">
                  <Input 
                    label="Nome da Turma"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({...formData, title: e.target.value})}
                    placeholder="Ex: Engenharia 2024.1" 
                  />
                  <div className="flex gap-4">
                    <div className="w-1/3">
                        <Input 
                            label="Código"
                            required
                            value={formData.code}
                            onChange={(e) => setFormData({...formData, code: e.target.value})}
                            placeholder="ENG-24" 
                        />
                    </div>
                    <div className="space-y-1.5 flex-1">
                      <label className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Departamento</label>
                      <select 
                        value={formData.department}
                        onChange={(e) => setFormData({...formData, department: e.target.value})}
                        className="w-full bg-input/50 border-none rounded-lg px-4 py-2.5 text-sm font-medium focus:ring-1 focus:ring-primary text-foreground"
                      >
                        <option>Engenharia</option>
                        <option>Ciência da Computação</option>
                        <option>Matemática</option>
                        <option>Humanidades</option>
                        <option>Negócios</option>
                      </select>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-orange-50 border border-orange-100 rounded-lg p-4 flex gap-3">
                 <span className="material-symbols-outlined text-orange-500">info</span>
                 <p className="text-xs text-orange-800 leading-relaxed">
                   Ao criar uma turma, você poderá adicionar disciplinas e matricular alunos posteriormente.
                 </p>
              </div>

              <div className="pt-2 flex gap-3">
                <Button type="button" variant="outline" fullWidth onClick={() => setShowModal(false)}>
                  Cancelar
                </Button>
                <Button 
                  type="submit"
                  disabled={isSubmitting}
                  fullWidth
                  className="flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <span className="material-symbols-outlined animate-spin text-[18px]">progress_activity</span>
                      Criando...
                    </>
                  ) : (
                    'Criar Turma'
                  )}
                </Button>
              </div>
            </form>
          </Card>
        </div>
      )}
    </div>
  );
};

export default InstructorList;
