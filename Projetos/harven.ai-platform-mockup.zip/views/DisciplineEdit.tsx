
import React, { useState } from 'react';
import { ViewType } from '../types';

interface DisciplineEditProps {
  onNavigate: (view: ViewType) => void;
}

const DisciplineEdit: React.FC<DisciplineEditProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'info' | 'syllabus' | 'settings'>('info');
  const [selectedIcon, setSelectedIcon] = useState('calculate');
  const [customIcon, setCustomIcon] = useState<string | null>(null);
  const [title, setTitle] = useState('Cálculo Diferencial e Integral I');

  const availableIcons = [
      'school', 'code', 'science', 'history_edu', 
      'palette', 'psychology', 'calculate', 'database',
      'biotech', 'gavel', 'balance', 'architecture'
  ];

  const handleIconUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          setCustomIcon(URL.createObjectURL(file));
      }
  };

  const [courseStructure, setCourseStructure] = useState([
     { id: 1, title: 'Introdução aos Limites', modules: 4, status: 'Publicado' },
     { id: 2, title: 'Derivadas Avançadas', modules: 6, status: 'Rascunho' },
     { id: 3, title: 'Integração e Aplicações', modules: 5, status: 'Publicado' }
  ]);

  const moveCourse = (index: number, direction: 'up' | 'down') => {
      const newStructure = [...courseStructure];
      if (direction === 'up' && index > 0) {
          [newStructure[index], newStructure[index - 1]] = [newStructure[index - 1], newStructure[index]];
      } else if (direction === 'down' && index < newStructure.length - 1) {
          [newStructure[index], newStructure[index + 1]] = [newStructure[index + 1], newStructure[index]];
      }
      setCourseStructure(newStructure);
  };

  return (
    <div className="flex flex-col h-full bg-harven-bg">
      {/* Edit Header */}
      <div className="bg-white border-b border-harven-border px-8 py-5 flex items-center justify-between flex-shrink-0 sticky top-0 z-20">
         <div className="flex items-center gap-4">
            <div>
               <h1 className="text-xl font-display font-bold text-harven-dark flex items-center gap-2">
                  {title}
                  <span className="bg-green-100 text-green-700 text-[9px] font-bold px-2 py-0.5 rounded uppercase border border-green-200">Ativa</span>
               </h1>
               <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Editando Disciplina • MT-101</p>
            </div>
         </div>
         <div className="flex gap-3">
            <button className="px-4 py-2 text-xs font-bold text-gray-400 hover:text-harven-dark uppercase tracking-widest">Descartar</button>
            <button className="px-6 py-2 bg-primary hover:bg-primary-dark text-harven-dark font-bold rounded-lg text-xs uppercase tracking-widest shadow-lg shadow-primary/20 flex items-center gap-2">
               <span className="material-symbols-outlined text-[18px]">save</span>
               Salvar Alterações
            </button>
         </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
         {/* Sidebar Navigation */}
         <div className="w-64 bg-white border-r border-harven-border flex flex-col py-6">
            <nav className="space-y-1 px-4">
               {[
                 { id: 'info', label: 'Informações Gerais', icon: 'info' },
                 { id: 'syllabus', label: 'Estrutura Curricular', icon: 'account_tree' },
                 { id: 'settings', label: 'Configurações', icon: 'settings' },
               ].map((item) => (
                  <button
                     key={item.id}
                     onClick={() => setActiveTab(item.id as any)}
                     className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-bold transition-all ${
                        activeTab === item.id 
                        ? 'bg-harven-bg text-harven-dark shadow-inner' 
                        : 'text-gray-400 hover:bg-gray-50 hover:text-harven-dark'
                     }`}
                  >
                     <span className={`material-symbols-outlined ${activeTab === item.id ? 'fill-1' : ''}`}>{item.icon}</span>
                     {item.label}
                  </button>
               ))}
            </nav>
         </div>

         {/* Content Area */}
         <div className="flex-1 overflow-y-auto p-10 custom-scrollbar">
            <div className="max-w-4xl mx-auto space-y-8">
               
               {activeTab === 'info' && (
                  <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
                     <section className="bg-white p-8 rounded-2xl border border-harven-border shadow-sm space-y-6">
                        <h3 className="text-lg font-display font-bold text-harven-dark border-b border-harven-bg pb-4">Dados Básicos</h3>
                        <div className="grid grid-cols-2 gap-6">
                           <div className="space-y-1.5">
                              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Nome da Disciplina</label>
                              <input 
                                className="w-full bg-harven-bg border-none rounded-lg p-3 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark" 
                                value={title}
                                onChange={(e) => setTitle(e.target.value)}
                              />
                           </div>
                           <div className="space-y-1.5">
                              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Código Oficial</label>
                              <input className="w-full bg-harven-bg border-none rounded-lg p-3 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark" defaultValue="MT-101" />
                           </div>
                           <div className="col-span-2 space-y-1.5">
                              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Descrição da Ementa</label>
                              <textarea className="w-full bg-harven-bg border-none rounded-lg p-3 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark min-h-[120px] resize-none" defaultValue="Disciplina fundamental focada no estudo de limites, derivadas e integrais e suas aplicações em problemas de engenharia e ciências exatas." />
                           </div>
                        </div>
                     </section>

                     <section className="bg-white p-8 rounded-2xl border border-harven-border shadow-sm space-y-6">
                        <h3 className="text-lg font-display font-bold text-harven-dark border-b border-harven-bg pb-4">Categorização & Visual</h3>
                        <div className="grid grid-cols-2 gap-6">
                           <div className="space-y-1.5">
                              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Departamento</label>
                              <select className="w-full bg-harven-bg border-none rounded-lg p-3 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark">
                                 <option>Ciências Exatas</option>
                                 <option>Engenharia</option>
                                 <option>Humanidades</option>
                              </select>
                           </div>
                           <div className="col-span-2 space-y-2">
                              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Ícone Representativo</label>
                              <div className="flex flex-wrap gap-3">
                                 {availableIcons.map(icon => (
                                    <button 
                                        key={icon} 
                                        onClick={() => { setSelectedIcon(icon); setCustomIcon(null); }}
                                        className={`size-12 rounded-xl flex items-center justify-center border transition-all ${selectedIcon === icon && !customIcon ? 'bg-primary text-harven-dark border-primary shadow-sm ring-2 ring-primary/20' : 'bg-harven-bg border-transparent text-gray-400 hover:border-gray-300'}`}
                                    >
                                       <span className="material-symbols-outlined text-[24px]">{icon}</span>
                                    </button>
                                 ))}
                                 
                                 <label className={`size-12 rounded-xl flex items-center justify-center border transition-all cursor-pointer ${customIcon ? 'bg-primary border-primary ring-2 ring-primary/20' : 'bg-harven-bg border-dashed border-gray-400 hover:bg-white'}`}>
                                     {customIcon ? (
                                         <img src={customIcon} className="w-full h-full object-cover rounded-xl" alt="Custom" />
                                     ) : (
                                         <span className="material-symbols-outlined text-gray-400">upload</span>
                                     )}
                                     <input type="file" className="hidden" accept="image/*" onChange={handleIconUpload} />
                                 </label>
                              </div>
                              <p className="text-[9px] text-gray-400">Selecione um ícone padrão ou faça upload de um ícone personalizado (SVG/PNG).</p>
                           </div>
                        </div>
                     </section>
                  </div>
               )}

               {activeTab === 'syllabus' && (
                  <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                     <div className="flex justify-between items-center">
                        <p className="text-gray-500 text-sm">Organize a hierarquia de cursos desta disciplina. Arraste para reordenar.</p>
                        <button className="bg-harven-dark text-white text-xs font-bold px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-black transition-colors">
                           <span className="material-symbols-outlined text-[16px]">add</span> Adicionar Curso
                        </button>
                     </div>
                     
                     <div className="space-y-4">
                        {courseStructure.map((course, i) => (
                           <div key={course.id} className="bg-white p-4 rounded-xl border border-harven-border flex items-center gap-4 group hover:border-primary transition-all">
                              <div className="flex flex-col gap-1 text-gray-300">
                                  <button onClick={() => moveCourse(i, 'up')} disabled={i === 0} className="hover:text-primary-dark disabled:opacity-30"><span className="material-symbols-outlined text-[18px]">keyboard_arrow_up</span></button>
                                  <button onClick={() => moveCourse(i, 'down')} disabled={i === courseStructure.length - 1} className="hover:text-primary-dark disabled:opacity-30"><span className="material-symbols-outlined text-[18px]">keyboard_arrow_down</span></button>
                              </div>
                              <div className="size-10 bg-harven-bg rounded-lg flex items-center justify-center text-gray-500 font-bold text-sm">{i + 1}</div>
                              <div className="flex-1">
                                 <h4 className="font-bold text-harven-dark">{course.title}</h4>
                                 <p className="text-xs text-gray-400">{course.modules} Módulos</p>
                              </div>
                              <span className={`text-[9px] font-bold px-2 py-0.5 rounded uppercase ${course.status === 'Publicado' ? 'bg-green-50 text-green-600' : 'bg-gray-100 text-gray-500'}`}>
                                 {course.status}
                              </span>
                              <button 
                                 onClick={() => onNavigate('COURSE_DETAILS')}
                                 className="size-8 rounded-lg hover:bg-harven-bg flex items-center justify-center text-gray-400 hover:text-primary-dark transition-colors"
                                 title="Editar Curso"
                              >
                                 <span className="material-symbols-outlined text-[20px]">edit</span>
                              </button>
                           </div>
                        ))}
                     </div>
                  </div>
               )}

            </div>
         </div>
      </div>
    </div>
  );
};

export default DisciplineEdit;
