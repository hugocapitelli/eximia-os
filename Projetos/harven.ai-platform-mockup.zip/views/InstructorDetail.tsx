
import React, { useState } from 'react';
import { ViewType } from '../types';

interface InstructorDetailProps {
  onNavigate: (view: ViewType) => void;
}

const InstructorDetail: React.FC<InstructorDetailProps> = ({ onNavigate }) => {
  const [showModal, setShowModal] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeTab, setActiveTab] = useState<'subjects' | 'students' | 'grades'>('subjects');
  const [searchTerm, setSearchTerm] = useState('');

  // Lista de Disciplinas dentro da Turma
  const [subjects, setSubjects] = useState([
    { id: 1, title: 'Introdução aos Limites', modules: 4, students: 32, progress: 80, time: '2 dias atrás', image: 'https://picsum.photos/seed/math1/400/200' },
    { id: 2, title: 'Derivadas Avançadas', modules: 6, students: 28, progress: 45, time: '5 horas atrás', image: '' },
    { id: 3, title: 'Integração e Aplicações', modules: 5, students: 15, progress: 12, time: '1 hora atrás', image: 'https://picsum.photos/seed/math2/400/200' },
  ]);

  // Lista de Alunos (Mock)
  const students = [
      { id: 1, name: 'Ana Silva', email: 'ana.silva@email.com', progress: 85, status: 'Ativo', lastAccess: 'Hoje, 09:00' },
      { id: 2, name: 'Bruno Santos', email: 'bruno.s@email.com', progress: 45, status: 'Ativo', lastAccess: 'Ontem' },
      { id: 3, name: 'Carlos Lima', email: 'carlos.l@email.com', progress: 12, status: 'Risco', lastAccess: 'Há 5 dias' },
      { id: 4, name: 'Daniela Costa', email: 'dani.c@email.com', progress: 92, status: 'Ativo', lastAccess: 'Hoje, 10:30' },
      { id: 5, name: 'Eduardo Pereira', email: 'edu.p@email.com', progress: 60, status: 'Inativo', lastAccess: 'Há 2 semanas' },
  ];

  const [formData, setFormData] = useState({
    title: '',
    modules: '',
    imageUrl: '',
    imageFile: null as File | null
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files[0]) {
          const file = e.target.files[0];
          setFormData({
              ...formData,
              imageFile: file,
              imageUrl: URL.createObjectURL(file) // Mock display
          });
      }
  };

  const handleCreateSubject = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    setTimeout(() => {
      const newSubject = {
        id: subjects.length + 1,
        title: formData.title,
        modules: parseInt(formData.modules) || 1,
        students: 0,
        progress: 0,
        time: 'Agora mesmo',
        image: formData.imageUrl || 'https://picsum.photos/seed/newcourse/400/200'
      };
      
      setSubjects([newSubject, ...subjects]);
      setFormData({ title: '', modules: '', imageUrl: '', imageFile: null });
      setIsSubmitting(false);
      setShowModal(false);
    }, 800);
  };

  const renderStars = (grade: number) => {
    return (
        <div className="flex gap-0.5 justify-center" title={`Nota: ${grade}/5`}>
            {[1, 2, 3, 4, 5].map(star => (
                <span 
                    key={star} 
                    className={`material-symbols-outlined text-[18px] ${star <= grade ? 'text-harven-gold fill-1' : 'text-gray-200'}`}
                >
                    star
                </span>
            ))}
        </div>
    )
  };

  const filteredSubjects = subjects.filter(s => s.title.toLowerCase().includes(searchTerm.toLowerCase()));
  const filteredStudents = students.filter(s => s.name.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="flex flex-col flex-1 h-full animate-in fade-in duration-500 relative">
      <div className="relative h-64 bg-harven-dark overflow-hidden flex-shrink-0">
        <div className="absolute inset-0 bg-cover bg-center opacity-20" style={{ backgroundImage: 'url(https://picsum.photos/seed/math/1200/600)' }}></div>
        <div className="absolute inset-0 bg-gradient-to-r from-harven-dark via-harven-dark/80 to-transparent p-10 flex flex-col justify-end">
          <div className="max-w-6xl mx-auto w-full flex justify-between items-end">
            <div className="flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <span className="bg-primary text-harven-dark text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-widest">Turma Ativa</span>
                <span className="text-harven-gold text-xs font-bold flex items-center gap-1">
                  <span className="material-symbols-outlined text-[16px]">school</span> Engenharias
                </span>
              </div>
              <h1 className="text-4xl font-display font-bold text-white tracking-tight">Engenharia de Software 2024.1</h1>
              <p className="text-white/60 max-w-xl text-sm leading-relaxed">
                Turma focada na formação fundamental de engenharia de software, abrangendo desde algoritmos até gestão de projetos.
              </p>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => onNavigate('DISCIPLINE_EDIT')}
                className="px-5 py-2 border border-primary text-primary hover:bg-primary/10 transition-colors font-bold rounded-lg text-sm"
              >
                Configurar Turma
              </button>
              <button 
                onClick={() => setShowModal(true)}
                className="px-5 py-2 bg-primary text-harven-dark font-bold rounded-lg text-sm shadow-xl shadow-primary/20 hover:bg-primary-dark transition-all flex items-center gap-2"
              >
                <span className="material-symbols-outlined text-[18px]">add_circle</span>
                Adicionar Disciplina
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto w-full p-10 flex flex-col gap-10">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
           {[
             { label: 'Total de Disciplinas', val: subjects.length.toString(), trend: '+1 nova agora', icon: 'menu_book' },
             { label: 'Alunos Matriculados', val: '45', trend: 'Lotação 90%', icon: 'groups' },
             { label: 'Progresso Médio', val: '68%', trend: 'Desempenho estável', icon: 'analytics' },
             { label: 'Conversas Socráticas', val: '24', trend: 'Interações ativas hoje', icon: 'forum' },
           ].map((stat, i) => (
             <div key={i} className="bg-white p-5 rounded-xl border border-harven-border shadow-sm flex flex-col gap-1 group relative overflow-hidden">
                <div className="absolute top-4 right-4 size-8 bg-harven-bg rounded-lg flex items-center justify-center text-harven-gold group-hover:bg-primary group-hover:text-harven-dark transition-colors">
                  <span className="material-symbols-outlined text-[18px]">{stat.icon}</span>
                </div>
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{stat.label}</p>
                <p className="text-2xl font-display font-bold text-harven-dark mt-1">{stat.val}</p>
                <p className="text-[10px] font-bold text-green-600 mt-2">{stat.trend}</p>
             </div>
           ))}
        </div>

        <div className="space-y-6">
          <div className="flex flex-col md:flex-row justify-between items-end border-b border-harven-border gap-4 pb-0">
             <div className="flex gap-8">
               <button 
                onClick={() => setActiveTab('subjects')}
                className={`text-sm font-bold pb-4 -mb-px transition-colors border-b-4 ${activeTab === 'subjects' ? 'text-harven-dark border-primary' : 'text-gray-400 border-transparent hover:text-harven-dark'}`}
               >
                   Disciplinas da Turma
               </button>
               <button 
                onClick={() => setActiveTab('students')}
                className={`text-sm font-bold pb-4 -mb-px transition-colors border-b-4 ${activeTab === 'students' ? 'text-harven-dark border-primary' : 'text-gray-400 border-transparent hover:text-harven-dark'}`}
               >
                   Alunos
               </button>
               <button 
                onClick={() => setActiveTab('grades')}
                className={`text-sm font-bold pb-4 -mb-px transition-colors border-b-4 ${activeTab === 'grades' ? 'text-harven-dark border-primary' : 'text-gray-400 border-transparent hover:text-harven-dark'}`}
               >
                   Quadro de Notas
               </button>
             </div>
             
             <div className="flex items-center gap-4 pb-2 w-full md:w-auto">
                <div className="relative flex-1 md:w-64">
                    <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 text-[18px]">search</span>
                    <input 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full bg-white border border-harven-border rounded-lg pl-9 pr-4 py-1.5 text-sm focus:ring-1 focus:ring-primary placeholder-gray-400" 
                        placeholder={activeTab === 'students' ? "Buscar aluno..." : "Buscar disciplina..."}
                    />
                </div>
                <div className="flex items-center gap-2 text-xs font-bold text-gray-400 whitespace-nowrap hidden md:flex">
                    <span className="text-harven-dark flex items-center cursor-pointer">MAIS RECENTES <span className="material-symbols-outlined text-[16px]">expand_more</span></span>
                </div>
             </div>
          </div>

          <div className="min-h-[300px]">
            {activeTab === 'subjects' && (
                <div className="flex flex-col gap-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                    {filteredSubjects.map((subject) => (
                    <div 
                        key={subject.id} 
                        className="bg-white p-5 rounded-xl border border-harven-border flex flex-col md:flex-row items-center gap-8 shadow-sm group hover:shadow-md hover:border-primary/50 transition-all cursor-pointer"
                        onClick={() => onNavigate('COURSE_DETAILS')} 
                    >
                        <div className="w-full md:w-32 h-20 rounded-xl bg-harven-bg flex items-center justify-center flex-shrink-0 overflow-hidden relative">
                        {subject.image ? (
                            <img src={subject.image} alt={subject.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                        ) : (
                            <span className="material-symbols-outlined text-[36px] text-harven-dark group-hover:text-primary-dark transition-colors">functions</span>
                        )}
                        <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <span className="material-symbols-outlined text-white">visibility</span>
                        </div>
                        </div>
                        
                        <div className="flex-1 min-w-0">
                        <h4 className="text-lg font-bold text-harven-dark leading-tight">{subject.title}</h4>
                        <div className="flex items-center gap-3 text-xs font-bold text-gray-400 uppercase tracking-widest mt-1">
                            <span>{subject.modules} Módulos</span>
                            <span className="size-1 rounded-full bg-gray-200"></span>
                            <span>{subject.students} Alunos</span>
                        </div>
                        </div>
                        <div className="w-full md:w-64 flex flex-col gap-1">
                        <div className="flex justify-between text-[10px] font-bold text-gray-400 uppercase">
                            <span>Progresso Geral</span>
                            <span className="text-harven-dark">{subject.progress}%</span>
                        </div>
                        <div className="h-2 w-full bg-harven-bg rounded-full overflow-hidden">
                            <div className="h-full bg-primary rounded-full transition-all duration-500" style={{ width: `${subject.progress}%` }}></div>
                        </div>
                        <span className="text-[9px] font-bold text-gray-400 mt-1 uppercase tracking-tighter">ÚLTIMA ATIVIDADE: {subject.time}</span>
                        </div>
                        <div className="flex gap-2">
                        <button 
                            onClick={(e) => {
                                e.stopPropagation();
                                onNavigate('COURSE_EDIT');
                            }}
                            className="px-4 py-2 bg-harven-bg hover:bg-primary group-hover:bg-primary group-hover:text-harven-dark border border-transparent rounded-lg text-xs font-bold text-harven-dark transition-all shadow-sm"
                        >
                            GERENCIAR
                        </button>
                        <button className="px-2 py-2 border border-harven-border hover:bg-gray-50 rounded-lg text-gray-400">
                            <span className="material-symbols-outlined text-[18px]">more_vert</span>
                        </button>
                        </div>
                    </div>
                    ))}
                    {filteredSubjects.length === 0 && (
                        <div className="p-10 text-center border-2 border-dashed border-gray-200 rounded-xl">
                            <p className="text-gray-400 text-sm">Nenhuma disciplina encontrada.</p>
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'students' && (
                <div className="flex flex-col gap-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
                    <div className="bg-white rounded-xl border border-harven-border overflow-hidden">
                        <table className="w-full text-left">
                            <thead className="bg-harven-bg/50 border-b border-harven-border text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                                <tr>
                                    <th className="p-4">Aluno</th>
                                    <th className="p-4">Progresso Geral</th>
                                    <th className="p-4">Status</th>
                                    <th className="p-4">Último Acesso</th>
                                    <th className="p-4 text-right">Ações</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-harven-bg">
                                {filteredStudents.map((student) => (
                                    <tr key={student.id} className="hover:bg-harven-bg/20 transition-colors">
                                        <td className="p-4">
                                            <div className="flex items-center gap-3">
                                                <div className="size-8 rounded-full bg-harven-dark text-white flex items-center justify-center font-bold text-xs">
                                                    {student.name.charAt(0)}
                                                </div>
                                                <div>
                                                    <p className="text-sm font-bold text-harven-dark">{student.name}</p>
                                                    <p className="text-[10px] text-gray-400">{student.email}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="p-4">
                                            <div className="flex items-center gap-2 max-w-[150px]">
                                                <div className="flex-1 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                                                    <div className="h-full bg-primary" style={{ width: `${student.progress}%` }}></div>
                                                </div>
                                                <span className="text-xs font-bold text-harven-dark">{student.progress}%</span>
                                            </div>
                                        </td>
                                        <td className="p-4">
                                            <span className={`text-[9px] font-bold px-2 py-0.5 rounded uppercase border ${
                                                student.status === 'Ativo' ? 'bg-green-50 text-green-600 border-green-100' : 
                                                student.status === 'Risco' ? 'bg-red-50 text-red-600 border-red-100' : 'bg-gray-100 text-gray-500 border-gray-200'
                                            }`}>
                                                {student.status}
                                            </span>
                                        </td>
                                        <td className="p-4 text-xs font-medium text-gray-500">{student.lastAccess}</td>
                                        <td className="p-4 text-right">
                                            <button className="text-gray-400 hover:text-primary-dark transition-colors"><span className="material-symbols-outlined text-[18px]">visibility</span></button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {activeTab === 'grades' && (
                <div className="animate-in fade-in slide-in-from-bottom-2 duration-300 overflow-x-auto">
                    <div className="bg-white rounded-xl border border-harven-border min-w-[800px]">
                        <table className="w-full text-left">
                            <thead className="bg-harven-bg/50 border-b border-harven-border text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                                <tr>
                                    <th className="p-4 sticky left-0 bg-[#f8f9fa] z-10 border-r border-harven-border shadow-[2px_0_5px_rgba(0,0,0,0.05)]">Aluno</th>
                                    {subjects.map(s => (
                                        <th key={s.id} className="p-4 text-center max-w-[120px] truncate" title={s.title}>{s.title}</th>
                                    ))}
                                    <th className="p-4 text-center font-black text-harven-dark">MÉDIA GLOBAL</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-harven-bg">
                                {students.map((student) => {
                                    // Generate mock grades 1-5 based on student ID
                                    const getGrade = (sid: number, subId: number) => {
                                        const base = 3 + (sid % 3); // 3, 4, 5
                                        const varr = (subId % 2) === 0 ? 0 : -1;
                                        let grade = base + varr;
                                        if (grade > 5) grade = 5;
                                        if (grade < 1) grade = 1;
                                        return grade;
                                    }
                                    
                                    const grades = subjects.map(s => getGrade(student.id, s.id));
                                    const avg = Math.round(grades.reduce((a, b) => a + b, 0) / grades.length);

                                    return (
                                        <tr key={student.id} className="hover:bg-harven-bg/20 transition-colors">
                                            <td className="p-4 sticky left-0 bg-white group-hover:bg-[#fbfcf8] z-10 border-r border-harven-border font-bold text-sm text-harven-dark">
                                                {student.name}
                                            </td>
                                            {grades.map((g, i) => (
                                                <td key={i} className="p-4 text-center">
                                                    {renderStars(g)}
                                                </td>
                                            ))}
                                            <td className="p-4 text-center">
                                                {renderStars(avg)}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}
          </div>
        </div>
      </div>

      {/* Modal de Adicionar Disciplina */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-harven-dark/80 backdrop-blur-sm animate-in fade-in duration-200">
           <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
             <div className="p-6 border-b border-harven-border bg-harven-bg flex justify-between items-center">
               <h3 className="text-lg font-display font-bold text-harven-dark">Nova Disciplina</h3>
               <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-harven-dark">
                 <span className="material-symbols-outlined">close</span>
               </button>
             </div>
             
             <form onSubmit={handleCreateSubject} className="p-6 flex flex-col gap-6">
                <div className="space-y-4">
                   <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Capa da Disciplina</label>
                      <div className="flex flex-col gap-3">
                         <div className="flex gap-2">
                            <input 
                                value={formData.imageUrl}
                                onChange={(e) => setFormData({...formData, imageUrl: e.target.value})}
                                className="flex-1 bg-harven-bg border-none rounded-lg px-4 py-3 text-sm font-medium focus:ring-1 focus:ring-primary placeholder-gray-400 text-harven-dark"
                                placeholder="URL da imagem..."
                            />
                            <label className="px-3 py-3 bg-harven-bg hover:bg-gray-200 rounded-lg cursor-pointer flex items-center justify-center border border-transparent">
                                <span className="material-symbols-outlined text-gray-500">upload_file</span>
                                <input type="file" accept="image/*" className="hidden" onChange={handleFileChange} />
                            </label>
                         </div>
                         <div className="h-32 w-full rounded-lg bg-gray-100 border border-harven-border flex items-center justify-center overflow-hidden">
                            {formData.imageUrl ? (
                                <img src={formData.imageUrl} className="w-full h-full object-cover" alt="Preview" onError={(e) => (e.currentTarget.src = 'https://via.placeholder.com/150')} />
                            ) : (
                                <div className="text-center text-gray-400">
                                    <span className="material-symbols-outlined text-3xl">image</span>
                                    <p className="text-[10px] uppercase font-bold mt-1">Preview</p>
                                </div>
                            )}
                         </div>
                      </div>
                   </div>

                   <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Nome da Disciplina</label>
                      <input 
                        required
                        value={formData.title}
                        onChange={(e) => setFormData({...formData, title: e.target.value})}
                        className="w-full bg-harven-bg border-none rounded-lg px-4 py-3 text-sm font-medium focus:ring-1 focus:ring-primary placeholder-gray-400 text-harven-dark"
                        placeholder="Ex: Física II"
                      />
                   </div>
                   <div className="space-y-1.5">
                      <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Qtd. Módulos (Estimada)</label>
                      <input 
                        required
                        type="number"
                        min="1"
                        value={formData.modules}
                        onChange={(e) => setFormData({...formData, modules: e.target.value})}
                        className="w-full bg-harven-bg border-none rounded-lg px-4 py-3 text-sm font-medium focus:ring-1 focus:ring-primary placeholder-gray-400 text-harven-dark"
                        placeholder="Ex: 6"
                      />
                   </div>
                </div>
                
                <div className="pt-2 flex gap-3">
                   <button 
                     type="button" 
                     onClick={() => setShowModal(false)}
                     className="flex-1 py-3 border border-harven-border rounded-xl text-xs font-bold text-harven-dark hover:bg-gray-50 transition-colors uppercase tracking-widest"
                   >
                     Cancelar
                   </button>
                   <button 
                     type="submit"
                     disabled={isSubmitting}
                     className="flex-1 py-3 bg-primary hover:bg-primary-dark rounded-xl text-xs font-bold text-harven-dark transition-all uppercase tracking-widest shadow-lg shadow-primary/20 flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                   >
                     {isSubmitting ? (
                       <>
                         <span className="material-symbols-outlined animate-spin text-[18px]">progress_activity</span>
                         Adicionando...
                       </>
                     ) : (
                       'Confirmar'
                     )}
                   </button>
                </div>
             </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default InstructorDetail;
