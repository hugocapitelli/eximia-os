
import React, { useState } from 'react';
import { Button } from '../components/ui/Button';
import { Card } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { ViewType } from '../types';

interface AccountSettingsProps {
  onNavigate: (view: ViewType) => void;
}

const AccountSettings: React.FC<AccountSettingsProps> = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'profile' | 'security' | 'notifications'>('profile');
  const [avatarUrl, setAvatarUrl] = useState('https://picsum.photos/seed/student/200/200');

  const handleAvatarChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setAvatarUrl(URL.createObjectURL(file));
    }
  };

  return (
    <div className="flex flex-col h-full bg-harven-bg overflow-y-auto custom-scrollbar">
      <div className="max-w-4xl mx-auto w-full p-8 md:p-12 flex flex-col gap-8">
        
        <div className="flex items-center gap-4 mb-2">
            <button onClick={() => onNavigate('USER_PROFILE')} className="p-2 hover:bg-white rounded-full transition-colors text-gray-400 hover:text-harven-dark">
                <span className="material-symbols-outlined">arrow_back</span>
            </button>
            <div>
                <h1 className="text-3xl font-display font-bold text-harven-dark">Minha Conta</h1>
                <p className="text-gray-500">Gerencie suas informações pessoais e preferências de segurança.</p>
            </div>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
            {/* Sidebar Navigation */}
            <div className="w-full md:w-64 flex-shrink-0">
                <nav className="flex flex-row md:flex-col gap-2 overflow-x-auto md:overflow-visible pb-4 md:pb-0">
                    {[
                        { id: 'profile', label: 'Perfil Público', icon: 'person' },
                        { id: 'security', label: 'Login e Segurança', icon: 'lock' },
                        { id: 'notifications', label: 'Notificações', icon: 'notifications' },
                    ].map(item => (
                        <button
                            key={item.id}
                            onClick={() => setActiveTab(item.id as any)}
                            className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all whitespace-nowrap ${
                                activeTab === item.id 
                                ? 'bg-white text-harven-dark shadow-sm ring-1 ring-harven-border' 
                                : 'text-gray-400 hover:text-harven-dark hover:bg-white/50'
                            }`}
                        >
                            <span className={`material-symbols-outlined ${activeTab === item.id ? 'fill-1' : ''}`}>{item.icon}</span>
                            {item.label}
                        </button>
                    ))}
                </nav>
            </div>

            {/* Content Area */}
            <div className="flex-1 space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                
                {activeTab === 'profile' && (
                    <Card className="p-8 space-y-8">
                        <div>
                            <h3 className="text-lg font-bold text-harven-dark mb-6 border-b border-harven-bg pb-4">Imagem de Perfil</h3>
                            <div className="flex items-center gap-6">
                                <div className="size-24 rounded-full overflow-hidden border-2 border-harven-border">
                                    <img src={avatarUrl} alt="Avatar" className="w-full h-full object-cover" />
                                </div>
                                <div className="space-y-3">
                                    <div className="flex gap-3">
                                        <label className="px-4 py-2 bg-primary hover:bg-primary-dark text-harven-dark text-xs font-bold uppercase rounded-lg cursor-pointer transition-colors shadow-sm">
                                            Alterar Foto
                                            <input type="file" className="hidden" accept="image/*" onChange={handleAvatarChange} />
                                        </label>
                                        <button 
                                            onClick={() => setAvatarUrl('https://picsum.photos/seed/student/200/200')}
                                            className="px-4 py-2 border border-harven-border hover:bg-red-50 hover:text-red-500 hover:border-red-100 text-gray-500 text-xs font-bold uppercase rounded-lg transition-colors"
                                        >
                                            Remover
                                        </button>
                                    </div>
                                    <p className="text-[10px] text-gray-400 font-medium">
                                        Recomendado: JPG, PNG ou GIF. Máx. 2MB.
                                    </p>
                                </div>
                            </div>
                        </div>

                        <div className="space-y-6">
                            <h3 className="text-lg font-bold text-harven-dark mb-6 border-b border-harven-bg pb-4">Dados Pessoais</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <Input label="Nome Completo" defaultValue="Lucas Martins" />
                                <Input label="Nome de Usuário" defaultValue="@lucasmartins" />
                                <Input label="E-mail" defaultValue="lucas.martins@harven.edu" disabled className="bg-gray-50 opacity-70" />
                                <Input label="Telefone" placeholder="(00) 00000-0000" />
                            </div>
                            <div className="space-y-1.5">
                                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Bio / Sobre Mim</label>
                                <textarea className="w-full bg-harven-bg border-none rounded-lg p-3 text-sm focus:ring-1 focus:ring-primary text-harven-dark min-h-[100px] resize-none" defaultValue="Apaixonado por tecnologia e inteligência artificial." />
                            </div>
                        </div>

                        <div className="flex justify-end pt-4">
                            <Button>Salvar Alterações</Button>
                        </div>
                    </Card>
                )}

                {activeTab === 'security' && (
                    <Card className="p-8 space-y-8">
                        <div>
                            <h3 className="text-lg font-bold text-harven-dark mb-6 border-b border-harven-bg pb-4">Alterar Senha</h3>
                            <div className="space-y-4 max-w-md">
                                <Input label="Senha Atual" type="password" placeholder="••••••••" />
                                <Input label="Nova Senha" type="password" placeholder="••••••••" />
                                <Input label="Confirmar Nova Senha" type="password" placeholder="••••••••" />
                            </div>
                            <div className="mt-6 flex justify-end max-w-md">
                                <Button variant="outline">Atualizar Senha</Button>
                            </div>
                        </div>

                        <div>
                            <h3 className="text-lg font-bold text-harven-dark mb-6 border-b border-harven-bg pb-4">Sessões Ativas</h3>
                            <div className="space-y-4">
                                <div className="flex items-center justify-between p-4 bg-harven-bg/30 rounded-xl border border-harven-border">
                                    <div className="flex items-center gap-4">
                                        <span className="material-symbols-outlined text-gray-400 text-3xl">desktop_mac</span>
                                        <div>
                                            <p className="text-sm font-bold text-harven-dark">Chrome no Windows</p>
                                            <p className="text-xs text-gray-500">São Paulo, BR • Ativo agora</p>
                                        </div>
                                    </div>
                                    <span className="text-[10px] font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded uppercase border border-green-100">Atual</span>
                                </div>
                                <div className="flex items-center justify-between p-4 bg-white rounded-xl border border-harven-border">
                                    <div className="flex items-center gap-4">
                                        <span className="material-symbols-outlined text-gray-400 text-3xl">smartphone</span>
                                        <div>
                                            <p className="text-sm font-bold text-harven-dark">Safari no iPhone 13</p>
                                            <p className="text-xs text-gray-500">Rio de Janeiro, BR • Há 2 dias</p>
                                        </div>
                                    </div>
                                    <button className="text-red-500 hover:text-red-600 text-xs font-bold uppercase">Sair</button>
                                </div>
                            </div>
                        </div>
                    </Card>
                )}

                {activeTab === 'notifications' && (
                    <Card className="p-8 space-y-8">
                        <div>
                            <h3 className="text-lg font-bold text-harven-dark mb-6 border-b border-harven-bg pb-4">Preferências de E-mail</h3>
                            <div className="space-y-4">
                                {[
                                    { label: 'Resumo Semanal de Progresso', desc: 'Receba um e-mail toda segunda-feira com suas estatísticas.', checked: true },
                                    { label: 'Novos Cursos Recomendados', desc: 'Sugestões baseadas no seu histórico.', checked: false },
                                    { label: 'Respostas no Fórum', desc: 'Notificar quando alguém responder seus comentários.', checked: true },
                                    { label: 'Lembretes de Estudo', desc: 'Receba um empurrãozinho se ficar inativo por 3 dias.', checked: true },
                                ].map((opt, i) => (
                                    <div key={i} className="flex items-start justify-between group">
                                        <div>
                                            <p className="text-sm font-bold text-harven-dark">{opt.label}</p>
                                            <p className="text-xs text-gray-500">{opt.desc}</p>
                                        </div>
                                        <label className="relative inline-flex items-center cursor-pointer mt-1">
                                            <input type="checkbox" className="sr-only peer" defaultChecked={opt.checked} />
                                            <div className="w-9 h-5 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-primary"></div>
                                        </label>
                                    </div>
                                ))}
                            </div>
                        </div>
                        <div className="flex justify-end">
                            <Button>Salvar Preferências</Button>
                        </div>
                    </Card>
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default AccountSettings;
