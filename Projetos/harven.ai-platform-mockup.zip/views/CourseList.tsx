
import React, { useState, useMemo } from 'react';
import { ViewType } from '../types';
import { Button } from '../components/ui/Button';
import { Card, CardContent } from '../components/ui/Card';
import { Input } from '../components/ui/Input';
import { Badge } from '../components/ui/Badge';
import { Tabs } from '../components/ui/Tabs';
import { Progress } from '../components/ui/Progress';
import { Select } from '../components/ui/Select';

interface CourseListProps {
  onNavigate: (view: ViewType) => void;
}

const CourseList: React.FC<CourseListProps> = ({ onNavigate }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('Todos');
  const [selectedCategory, setSelectedCategory] = useState('Todas');

  const courses = [
    {
      id: 1,
      title: 'Advanced Growth Hacking Strategies',
      instructor: 'Dr. Elena Vance',
      category: 'Marketing',
      progress: 35,
      total_modules: 8,
      image: 'https://picsum.photos/seed/growth/600/400',
      last_accessed: 'Há 2 dias',
      status: 'Em Andamento',
      isFavorite: true
    },
    {
      id: 2,
      title: 'Fundamentos de Deep Learning',
      instructor: 'Prof. Alan Turing',
      category: 'Tecnologia',
      progress: 75,
      total_modules: 12,
      image: 'https://picsum.photos/seed/deep/600/400',
      last_accessed: 'Hoje',
      status: 'Em Andamento',
      isFavorite: false
    },
    {
      id: 3,
      title: 'Neurociência Cognitiva Aplicada',
      instructor: 'Dra. Sarah Klein',
      category: 'Ciências',
      progress: 0,
      total_modules: 5,
      image: 'https://picsum.photos/seed/neuro/600/400',
      last_accessed: '-',
      status: 'Não Iniciado',
      isFavorite: true
    },
    {
      id: 4,
      title: 'UX Design para Sistemas Complexos',
      instructor: 'Designer John Doe',
      category: 'Design',
      progress: 100,
      total_modules: 6,
      image: 'https://picsum.photos/seed/ux/600/400',
      last_accessed: 'Semana passada',
      status: 'Concluído',
      isFavorite: false
    },
    {
      id: 5,
      title: 'Finanças Corporativas e Valuation',
      instructor: 'Msc. Roberto Campos',
      category: 'Negócios',
      progress: 12,
      total_modules: 10,
      image: 'https://picsum.photos/seed/finance/600/400',
      last_accessed: 'Ontem',
      status: 'Em Andamento',
      isFavorite: false
    }
  ];

  // Extrair categorias únicas
  const categories = ['Todas', ...Array.from(new Set(courses.map(c => c.category)))];

  const filteredCourses = useMemo(() => {
    return courses.filter(course => {
      // Filtro por Aba
      let matchesTab = true;
      if (activeTab === 'Em Andamento') matchesTab = course.status === 'Em Andamento';
      else if (activeTab === 'Não Iniciados') matchesTab = course.status === 'Não Iniciado';
      else if (activeTab === 'Concluídos') matchesTab = course.status === 'Concluído';
      else if (activeTab === 'Favoritos') matchesTab = course.isFavorite;

      // Filtro por Texto
      const query = searchTerm.toLowerCase();
      const matchesSearch = 
        course.title.toLowerCase().includes(query) || 
        course.instructor.toLowerCase().includes(query) ||
        course.category.toLowerCase().includes(query);

      // Filtro por Categoria
      const matchesCategory = selectedCategory === 'Todas' || course.category === selectedCategory;

      return matchesTab && matchesSearch && matchesCategory;
    });
  }, [searchTerm, activeTab, selectedCategory]);

  return (
    <div className="max-w-7xl mx-auto p-8 flex flex-col gap-8 h-full animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between items-end gap-6">
        <div>
          <h2 className="text-3xl font-display font-bold text-foreground tracking-tight">Meus Cursos</h2>
          <p className="text-muted-foreground mt-1">Explore seu catálogo e continue aprendendo.</p>
        </div>
        
        <div className="flex items-end gap-3 w-full md:w-auto">
           <Input 
             icon="search"
             placeholder="Buscar cursos..." 
             value={searchTerm}
             onChange={(e) => setSearchTerm(e.target.value)}
             className="w-full md:w-64"
           />
           <div className="w-40">
             <Select 
               value={selectedCategory} 
               onChange={(e) => setSelectedCategory(e.target.value)}
             >
                {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                ))}
             </Select>
           </div>
        </div>
      </div>

      <div className="border-b border-border pb-1">
         <Tabs 
            items={['Todos', 'Em Andamento', 'Não Iniciados', 'Concluídos', 'Favoritos']}
            activeTab={activeTab}
            onChange={setActiveTab}
            className="bg-transparent p-0 justify-start"
         />
      </div>

      {filteredCourses.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pb-10">
          {filteredCourses.map((course) => (
            <Card 
              key={course.id} 
              hoverEffect
              className="flex flex-col h-full animate-in fade-in zoom-in-95 duration-300 group"
              onClick={() => onNavigate('COURSE_DETAILS')}
            >
              <div className="relative h-40 overflow-hidden bg-muted">
                <img src={course.image} alt={course.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-60"></div>
                <div className="absolute top-3 right-3">
                    <Badge variant="default" className="bg-white/90 backdrop-blur text-foreground border-none">
                      {course.category}
                    </Badge>
                </div>
                {course.isFavorite && (
                   <div className="absolute top-3 left-3 text-harven-gold drop-shadow-md">
                      <span className="material-symbols-outlined fill-1 text-[20px]">star</span>
                   </div>
                )}
                {course.status === 'Concluído' && (
                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center backdrop-blur-[2px]">
                      <Badge variant="success" className="bg-primary text-primary-foreground border-none">
                        <span className="material-symbols-outlined text-[16px] fill-1 mr-1">check_circle</span> Concluído
                      </Badge>
                  </div>
                )}
              </div>
              
              <CardContent className="flex-1 flex flex-col p-5">
                <h3 className="font-display font-bold text-lg text-foreground leading-tight line-clamp-2 group-hover:text-primary-dark transition-colors">
                  {course.title}
                </h3>
                <p className="text-xs text-muted-foreground mt-2 font-medium flex items-center gap-1">
                  <span className="material-symbols-outlined text-[14px]">school</span>
                  {course.instructor}
                </p>
                
                <div className="mt-auto pt-6 space-y-3">
                  <div className="flex justify-between items-end">
                      <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">Progresso</span>
                      <span className="text-xs font-bold text-foreground">{course.progress}%</span>
                  </div>
                  
                  <Progress value={course.progress} className="h-1.5" />
                  
                  <div className="flex justify-between items-center pt-2">
                      <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-tight">
                        {course.total_modules} Módulos
                      </span>
                      {course.progress > 0 && course.progress < 100 ? (
                        <button className="text-xs font-bold text-primary-dark hover:underline flex items-center gap-1">
                          Continuar <span className="material-symbols-outlined text-[14px]">arrow_forward</span>
                        </button>
                      ) : course.progress === 0 ? (
                        <button className="text-xs font-bold text-foreground hover:text-primary-dark transition-colors">Iniciar</button>
                      ) : (
                        <button className="text-xs font-bold text-muted-foreground hover:text-foreground transition-colors">Rever</button>
                      )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          
          <Card 
            hoverEffect
            className="flex flex-col items-center justify-center p-6 gap-4 text-center border-dashed bg-muted/20 min-h-[300px]"
            onClick={() => {}}
          >
            <div className="size-12 rounded-full bg-muted flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                <span className="material-symbols-outlined text-muted-foreground group-hover:text-primary-dark">add</span>
            </div>
            <div>
                <p className="text-sm font-bold text-foreground">Explorar Catálogo</p>
                <p className="text-xs text-muted-foreground mt-1">Descubra novos conteúdos</p>
            </div>
          </Card>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-20 text-center opacity-60">
           <div className="size-16 bg-muted rounded-full flex items-center justify-center mb-4">
             <span className="material-symbols-outlined text-muted-foreground text-3xl">search_off</span>
           </div>
           <h3 className="text-lg font-bold text-foreground">Nenhum curso encontrado</h3>
           <p className="text-sm text-muted-foreground mt-1">Tente ajustar seus termos de busca ou filtros.</p>
           <Button 
             variant="ghost" 
             onClick={() => { setSearchTerm(''); setActiveTab('Todos'); setSelectedCategory('Todas'); }}
             className="mt-4"
           >
             Limpar Filtros
           </Button>
        </div>
      )}
    </div>
  );
};

export default CourseList;
