
import React, { useState } from 'react';
import { Sidebar } from './components/organisms/Sidebar';
import { DesignSystemViewer } from './components/pages/DesignSystemViewer';
import { DesignSystemLibrary } from './components/pages/DesignSystemLibrary';
import { JourneyDashboard } from './components/pages/JourneyDashboard';
import { JourneyGoals } from './components/pages/JourneyGoals';
import { JourneyHabits } from './components/pages/JourneyHabits';
import { JourneyLibrary } from './components/pages/JourneyLibrary';
import { AcademyDashboard } from './components/pages/AcademyDashboard';
import { AcademyLesson } from './components/pages/AcademyLesson';
import { AcademyCatalog } from './components/pages/AcademyCatalog';
import { AcademyAchievements } from './components/pages/AcademyAchievements';
import { AcademyTracks } from './components/pages/AcademyTracks';
import { AcademyCommunity } from './components/pages/AcademyCommunity';
import { AcademyFavorites } from './components/pages/AcademyFavorites';
import { AcademyAdminEditor } from './components/pages/AcademyAdminEditor';
import { BrandDashboard } from './components/pages/BrandDashboard';
import { BrandVisualIdentity } from './components/pages/BrandVisualIdentity';
import { BrandVoice } from './components/pages/BrandVoice';
import { BrandAssets } from './components/pages/BrandAssets';
import { Inbox } from './components/pages/Inbox';
import { CourseDesigner } from './components/pages/CourseDesigner';
import { FinanceDashboard } from './components/pages/FinanceDashboard';
import { StrategyDashboard } from './components/pages/StrategyDashboard';
import { SyntheticMinds } from './components/pages/SyntheticMinds';
import { TeamDashboard } from './components/pages/TeamDashboard';
import { UserManagement } from './components/pages/UserManagement';
import { ContentDashboard } from './components/pages/ContentDashboard';
import { ContentCurator } from './components/pages/ContentCurator';
import { ContentSocial } from './components/pages/ContentSocial';
import { ContentNewsletter } from './components/pages/ContentNewsletter';
import { ContentCopyBank } from './components/pages/ContentCopyBank';
import { ContentEbooks } from './components/pages/ContentEbooks';
import { ContentVideos } from './components/pages/ContentVideos';

export default function App() {
  const [activePage, setActivePage] = useState<string>('content-dashboard');
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [selectedDSId, setSelectedDSId] = useState<string>('eximia-os-v6');

  // Helper for Academy navigation
  const handleAcademyNavigation = (courseId: string) => {
      setSelectedCourseId(courseId);
      setActivePage('academy-lesson');
  };

  // Helper for Academy Editor navigation
  const handleAcademyEdit = (courseId: string) => {
      setSelectedCourseId(courseId);
      setActivePage('academy-editor');
  };

  // Helper for Academy Page switching
  const handleAcademyPageChange = (pageId: string) => {
      setActivePage(pageId);
  }

  // Helper for DS navigation
  const handleDSNavigation = (dsId: string) => {
      setSelectedDSId(dsId);
      setActivePage('ds-viewer');
  };

  // Page Content Renderer
  const renderContent = () => {
    switch (activePage) {
      // Inbox Route
      case 'inbox': return <Inbox />;

      // Finance Route
      case 'finance-dashboard': return <FinanceDashboard />;
      case 'finance-transactions': return <FinanceDashboard />;

      // Strategy Route
      case 'strategy-dashboard': return <StrategyDashboard />;
      case 'strategy-forge': return <StrategyDashboard />;
      case 'strategy-warroom': return <StrategyDashboard />;

      // Content Routes (New)
      case 'content': return <ContentDashboard />;
      case 'content-dashboard': return <ContentDashboard />;
      case 'content-courses': return <CourseDesigner />;
      case 'course-designer': return <CourseDesigner />; // Keep legacy route just in case
      case 'content-curator': return <ContentCurator />;
      case 'content-ebooks': return <ContentEbooks />;
      case 'content-social': return <ContentSocial />;
      case 'content-newsletter': return <ContentNewsletter />;
      case 'content-videos': return <ContentVideos />;
      case 'content-copies': return <ContentCopyBank />;

      // Team Route (Expanded)
      case 'team': return <TeamDashboard view="overview" />;
      case 'team-dashboard': return <TeamDashboard view="overview" />;
      case 'team-org': return <TeamDashboard view="org" />;
      case 'team-members': return <TeamDashboard view="members" />;
      case 'team-hiring': return <TeamDashboard view="hiring" />;
      case 'team-onboarding': return <TeamDashboard view="onboarding" />;
      case 'team-performance': return <TeamDashboard view="performance" />;
      case 'team-rituals': return <TeamDashboard view="rituals" />;
      case 'team-culture': return <TeamDashboard view="culture" />;
      case 'team-comms': return <TeamDashboard view="comms" />;
      case 'team-offboarding': return <TeamDashboard view="offboarding" />;
      case 'team-management': return <UserManagement />;

      // Journey Routes
      case 'journey-dashboard': return <JourneyDashboard />;
      case 'journey-goals': return <JourneyGoals />;
      case 'journey-habits': return <JourneyHabits />;
      case 'journey-library': return <JourneyLibrary />;
      
      // Academy Routes
      case 'academy-dashboard': return <AcademyDashboard onNavigateToCourse={handleAcademyNavigation} onEditCourse={handleAcademyEdit} onNavigate={handleAcademyPageChange} />;
      case 'academy-catalog': return <AcademyCatalog onNavigateToCourse={handleAcademyNavigation} />;
      case 'academy-achievements': return <AcademyAchievements />;
      case 'academy-tracks': return <AcademyTracks onNavigate={handleAcademyPageChange} />;
      case 'academy-community': return <AcademyCommunity onNavigate={handleAcademyPageChange} />;
      case 'academy-favorites': return <AcademyFavorites onNavigateToCourse={handleAcademyNavigation} onNavigate={handleAcademyPageChange} />;
      case 'academy-lesson': 
         return selectedCourseId 
            ? <AcademyLesson courseId={selectedCourseId} onBack={() => setActivePage('academy-dashboard')} />
            : <AcademyDashboard onNavigateToCourse={handleAcademyNavigation} onNavigate={handleAcademyPageChange} />;
      case 'academy-editor':
          return selectedCourseId
            ? <AcademyAdminEditor courseId={selectedCourseId} onBack={() => setActivePage('academy-dashboard')} />
            : <AcademyDashboard onNavigateToCourse={handleAcademyNavigation} onNavigate={handleAcademyPageChange} />;

      // Brand Routes
      case 'brand-dashboard': return <BrandDashboard />;
      case 'brand-visual': return <BrandVisualIdentity />;
      case 'brand-voice': return <BrandVoice />;
      case 'brand-assets': return <BrandAssets />;

      // Design System Routes
      case 'ds-library': return <DesignSystemLibrary onSelectDS={handleDSNavigation} />;
      case 'ds-viewer': return (
          <DesignSystemViewer 
            dsId={selectedDSId} 
            onBack={() => setActivePage('ds-library')} 
            onSwitch={setSelectedDSId}
          />
      );
      case 'design-system': return <DesignSystemLibrary onSelectDS={handleDSNavigation} />;

      // Synthetic Minds (AI)
      case 'synthetic-minds': return <SyntheticMinds />;

      // Restored Modules Placeholders
      case 'sales': return <div className="p-10 text-center text-zinc-500">Página em construção: Vendas</div>;
      case 'sales-ai': return <div className="p-10 text-center text-zinc-500">Página em construção: Sales AI</div>;
      case 'crm': return <div className="p-10 text-center text-zinc-500">Página em construção: CRM</div>;
      case 'content-calendar': return <div className="p-10 text-center text-zinc-500">Página em construção: Content Calendar</div>;
      case 'content-ideas': return <div className="p-10 text-center text-zinc-500">Página em construção: Content Ideas</div>;

      default:
        return <div className="p-10 text-center text-zinc-500">Página em construção: {activePage}</div>;
    }
  };

  return (
    <div className="flex min-h-screen bg-[#050505] text-zinc-200 font-sans selection:bg-amber-500/30 selection:text-white">
      {/* 1. Sidebar */}
      <Sidebar 
        onNavigate={(id) => setActivePage(id)} 
        activePageId={activePage}
      />

      <main className={`flex-1 transition-all duration-300 ease-in-out ${activePage === 'academy-lesson' || activePage === 'academy-editor' ? 'ml-0 z-50 fixed inset-0' : 'ml-20 md:ml-64'}`}>
        {renderContent()}
      </main>

      <style>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.4s ease-out forwards;
        }
      `}</style>
    </div>
  );
}
