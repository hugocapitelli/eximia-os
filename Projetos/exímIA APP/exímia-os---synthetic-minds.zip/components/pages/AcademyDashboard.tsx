
import React, { useState, useEffect, useRef } from 'react';
import { ACADEMY_COURSES } from '../../constants';
import { AcademyCourseCard } from '../academy/AcademyCourseCard';
import { Button } from '../atoms/Button';
import { SearchBar } from '../molecules/SearchBar';
import { GraduationCap, Trophy, Flame, Play, Search, User, Zap, Settings, PenTool, GripVertical, Trash2, Layers } from 'lucide-react';
import { AcademyCourse } from '../../types';

interface AcademyDashboardProps {
    onNavigateToCourse: (courseId: string) => void;
    onEditCourse?: (courseId: string) => void;
    onNavigate?: (pageId: string) => void;
}

export const AcademyDashboard: React.FC<AcademyDashboardProps> = ({ onNavigateToCourse, onEditCourse, onNavigate }) => {
  const [selectedFilter, setSelectedFilter] = useState('TODOS');
  const [isAdminMode, setIsAdminMode] = useState(false);
  const [localCourses, setLocalCourses] = useState<AcademyCourse[]>(ACADEMY_COURSES);
  
  // Drag & Drop Refs
  const dragItem = useRef<number | null>(null);
  const dragOverItem = useRef<number | null>(null);

  // Custom filters based on the screenshot
  const filters = ['TODOS', 'AGENTES', 'AUTOMAÇÃO', 'EVENTOS', 'FUNDAMENTOS', 'BUSINESS', 'MAKERS', 'MENTALIDADE', 'NEGÓCIOS', 'PROGRAMAÇÃO', 'RAG', 'VENDAS'];

  // Update local list when filter changes
  useEffect(() => {
      const filtered = selectedFilter === 'TODOS' 
        ? ACADEMY_COURSES 
        : ACADEMY_COURSES.filter(c => c.category.toUpperCase() === selectedFilter || c.tags?.some(t => t.toUpperCase() === selectedFilter));
      setLocalCourses(filtered);
  }, [selectedFilter]);

  const handleNavClick = (pageId: string) => {
      if (onNavigate) {
          onNavigate(pageId);
      }
  };

  const handleCourseClick = (courseId: string) => {
      if (isAdminMode && onEditCourse) {
          onEditCourse(courseId);
      } else {
          onNavigateToCourse(courseId);
      }
  };

  // --- Drag & Drop Handlers ---
  const handleDragStart = (e: React.DragEvent<HTMLDivElement>, position: number) => {
      if (!isAdminMode) {
          e.preventDefault();
          return;
      }
      dragItem.current = position;
      // Visual feedback
      e.currentTarget.style.opacity = '0.4';
      e.dataTransfer.effectAllowed = "move";
  };

  const handleDragEnter = (e: React.DragEvent<HTMLDivElement>, position: number) => {
      if (!isAdminMode) return;
      e.preventDefault(); // Necessary to allow dropping
      
      dragOverItem.current = position;
      
      const dragIndex = dragItem.current;
      const dragOverIndex = dragOverItem.current;

      if (dragIndex === null || dragOverIndex === null || dragIndex === dragOverIndex) return;

      // Reorder Logic
      const newCourses = [...localCourses];
      const draggedItemContent = newCourses[dragIndex];
      
      // Remove from old index and insert at new index
      newCourses.splice(dragIndex, 1);
      newCourses.splice(dragOverIndex, 0, draggedItemContent);
      
      // Update ref to track the item's new position continuously
      dragItem.current = dragOverIndex;
      
      setLocalCourses(newCourses);
  };

  const handleDragEnd = (e: React.DragEvent<HTMLDivElement>) => {
      dragItem.current = null;
      dragOverItem.current = null;
      e.currentTarget.style.opacity = '1'; // Reset opacity
  };

  return (
    <div className="min-h-screen bg-[#050505] text-zinc-200 font-sans transition-colors duration-500">
       
       {/* Top Navigation */}
       <div className={`sticky top-0 z-30 backdrop-blur-md border-b transition-colors duration-500 ${isAdminMode ? 'bg-[#1a1500]/80 border-amber-500/20' : 'bg-[#050505]/80 border-[#1F1F22]'}`}>
           <div className="max-w-[1800px] mx-auto px-6 h-16 flex items-center justify-between">
               <div className="flex items-center gap-8">
                   <nav className="hidden md:flex items-center gap-6">
                       <button onClick={() => handleNavClick('academy-dashboard')} className="text-xs font-bold tracking-widest transition-colors text-white">EXPLORAR</button>
                       <button onClick={() => handleNavClick('academy-tracks')} className="text-xs font-bold tracking-widest transition-colors text-zinc-500 hover:text-zinc-300">TRILHAS</button>
                       <button onClick={() => handleNavClick('academy-favorites')} className="text-xs font-bold tracking-widest transition-colors text-zinc-500 hover:text-zinc-300">FAVORITOS</button>
                       <div className="h-4 w-[1px] bg-zinc-800" />
                       <button onClick={() => handleNavClick('academy-community')} className="text-xs font-bold tracking-widest text-zinc-500 hover:text-zinc-300">COMUNIDADE</button>
                       <button onClick={() => handleNavClick('journey-library')} className="text-xs font-bold tracking-widest text-zinc-500 hover:text-zinc-300">LIVROS</button>
                   </nav>
               </div>

               <div className="flex items-center gap-6">
                   <div className="relative hidden md:block group">
                       <Search className="absolute left-0 top-1.5 w-3 h-3 text-zinc-500 group-hover:text-zinc-300 transition-colors" />
                       <input 
                           type="text" 
                           placeholder="BUSCAR..." 
                           className="bg-transparent border-b border-zinc-800 text-[10px] font-bold tracking-widest py-1 pl-5 w-32 focus:w-48 focus:border-zinc-500 focus:outline-none transition-all text-zinc-300 placeholder-zinc-700"
                       />
                   </div>
                   
                   {/* Admin Mode Toggle */}
                   <button 
                        onClick={() => setIsAdminMode(!isAdminMode)}
                        className={`
                            flex items-center gap-2 px-3 py-1.5 rounded-full border transition-all duration-300
                            ${isAdminMode 
                                ? 'bg-amber-500 text-zinc-900 border-amber-400 shadow-[0_0_15px_rgba(245,158,11,0.4)]' 
                                : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-zinc-300'}
                        `}
                   >
                       {isAdminMode ? <Settings className="w-3 h-3 animate-spin-slow" /> : <PenTool className="w-3 h-3" />}
                       <span className="text-[10px] font-bold uppercase tracking-wider">{isAdminMode ? 'Editor Ativo' : 'Modo Editor'}</span>
                   </button>

                   <div className="w-8 h-8 rounded-full bg-zinc-800 border border-zinc-700 overflow-hidden">
                        <User className="w-full h-full p-1.5 text-zinc-400" />
                   </div>
               </div>
           </div>
       </div>

       {/* Main Content */}
       <div className="max-w-[1800px] mx-auto px-6 py-8">
           
           {/* Hero Section */}
           {!isAdminMode && (
               <div className="relative w-full h-[450px] rounded-3xl overflow-hidden mb-16 border border-zinc-800 group animate-in fade-in slide-in-from-top-4 duration-500">
                   <div className="absolute inset-0 bg-gradient-to-r from-[#1e1b4b] via-[#09090b] to-[#2e1065] opacity-80" />
                   <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20" />
                   <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-8 z-10">
                       <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 backdrop-blur-sm mb-6">
                           <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">✦ ExímIA Academy v4.1</span>
                       </div>
                       <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 tracking-tight drop-shadow-2xl">Construa o Futuro.</h1>
                       <p className="text-lg md:text-xl text-zinc-400 max-w-2xl font-serif leading-relaxed mb-10">Um ecossistema de design feito para escalar com elegância.</p>
                       <div className="flex gap-4">
                           <button className="px-8 py-4 bg-[#d4b589] hover:bg-[#c2a275] text-zinc-900 font-bold rounded-lg transition-all shadow-[0_0_20px_rgba(212,181,137,0.3)]">Começar Agora</button>
                           <button className="px-8 py-4 bg-transparent border border-zinc-700 text-white hover:bg-white/5 font-bold rounded-lg flex items-center gap-2 transition-all"><Play className="w-4 h-4 fill-current" /> Demo</button>
                       </div>
                   </div>
               </div>
           )}

           {isAdminMode && (
               <div className="mb-8 p-6 bg-amber-500/5 border border-amber-500/20 rounded-2xl flex items-center justify-between animate-in fade-in duration-300">
                   <div className="flex items-center gap-4">
                       <div className="p-3 bg-amber-500/10 rounded-lg text-amber-500 border border-amber-500/20"><Layers className="w-6 h-6" /></div>
                       <div><h2 className="text-lg font-bold text-white">Painel de Curadoria</h2><p className="text-sm text-zinc-400">Arraste para reordenar. O card encolhe para revelar as ferramentas.</p></div>
                   </div>
                   <div className="flex gap-3">
                       <Button variant="secondary" icon={<Zap className="w-4 h-4" />}>Gerar com AI</Button>
                       <Button variant="primary" icon={<Play className="w-4 h-4" />} className="bg-amber-500 hover:bg-amber-400 text-zinc-900">Novo Curso</Button>
                   </div>
               </div>
           )}

           {/* Filter Bar */}
           <div className="flex items-center gap-3 mb-10 overflow-x-auto pb-4 hide-scrollbar">
               {filters.map(filter => (
                   <button key={filter} onClick={() => setSelectedFilter(filter)} className={`px-5 py-2.5 rounded-full text-[10px] font-bold tracking-widest transition-all whitespace-nowrap border ${selectedFilter === filter ? 'bg-white text-black border-white shadow-[0_0_15px_rgba(255,255,255,0.4)]' : 'bg-[#0A0A0A] text-zinc-500 border-zinc-800 hover:border-zinc-600 hover:text-zinc-300'}`}>{filter}</button>
               ))}
           </div>

           {/* Section Header */}
           <div className="flex justify-between items-end mb-8 border-b border-zinc-800 pb-4">
               <div className="flex items-center gap-4"><h2 className="text-xs font-bold text-zinc-500 tracking-[0.2em]">TODOS OS CURSOS</h2><div className="h-[1px] w-12 bg-zinc-800" /></div>
               <span className="text-[10px] font-bold text-zinc-600 tracking-wider">{localCourses.length} cursos</span>
           </div>

           {/* Course Grid */}
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
               {localCourses.map((course, index) => (
                   <div 
                        key={course.id} 
                        className={`h-[360px] relative group perspective-1000 ${isAdminMode ? 'cursor-grab active:cursor-grabbing' : ''}`}
                        draggable={isAdminMode}
                        onDragStart={(e) => handleDragStart(e, index)}
                        onDragEnter={(e) => handleDragEnter(e, index)}
                        onDragEnd={handleDragEnd}
                        onDragOver={(e) => e.preventDefault()}
                   >
                       {/* 
                           Z-INDEX STRUCTURE:
                           Layer 0: Backplate (Glass) - Behind everything
                           Layer 10: Card Content - In the middle (shrinks in admin)
                           Layer 20: Controls - On top (visible only in admin)
                       */}

                       {/* Layer 0: Admin Backplate */}
                       {isAdminMode && (
                           <div className="absolute inset-0 z-0 animate-in fade-in duration-500 pointer-events-none">
                               <div className="absolute inset-0 rounded-2xl border-2 border-white/10 bg-white/5 backdrop-blur-sm shadow-[0_0_30px_rgba(0,0,0,0.5)]" />
                           </div>
                       )}

                       {/* Layer 10: Course Card */}
                       <div className={`
                           h-full w-full transition-all duration-300 ease-out relative z-10 origin-center
                           ${isAdminMode ? 'scale-[0.90] cursor-default' : 'hover:-translate-y-2 cursor-pointer'}
                       `}>
                           <AcademyCourseCard 
                               course={course} 
                               onClick={() => !isAdminMode && handleCourseClick(course.id)} 
                           />
                       </div>

                       {/* Layer 20: Admin Controls (Buttons stay ON TOP) */}
                       {isAdminMode && (
                           <div className="absolute inset-0 z-20 pointer-events-none animate-in fade-in duration-500">
                               {/* Controls positioned relative to the container size */}
                               
                               {/* Left: Drag Handle */}
                               <div className="absolute top-2 left-2 pointer-events-auto">
                                   <button className="w-8 h-8 bg-[#121214] border border-zinc-700 rounded-full flex items-center justify-center text-zinc-400 hover:text-white shadow-xl hover:scale-110 transition-all cursor-grab active:cursor-grabbing">
                                       <GripVertical className="w-4 h-4" />
                                   </button>
                               </div>

                               {/* Right Top: Edit */}
                               <div className="absolute top-2 right-2 pointer-events-auto">
                                   <button
                                       onClick={(e) => { e.stopPropagation(); onEditCourse && onEditCourse(course.id); }}
                                       className="w-10 h-10 bg-amber-500 border-2 border-amber-300 rounded-full flex items-center justify-center text-zinc-900 shadow-[0_0_20px_rgba(245,158,11,0.6)] hover:scale-110 hover:rotate-12 transition-all"
                                       title="Editar Curso"
                                   >
                                       <PenTool className="w-4 h-4 fill-current" />
                                   </button>
                               </div>

                               {/* Right Bottom: Delete */}
                               <div className="absolute bottom-2 right-2 pointer-events-auto">
                                   <button className="w-8 h-8 bg-[#121214] border border-zinc-700 rounded-full flex items-center justify-center text-rose-500 hover:bg-rose-950 hover:border-rose-500 transition-all shadow-xl">
                                       <Trash2 className="w-4 h-4" />
                                   </button>
                               </div>

                               {/* Center Area: Quick Manage */}
                               <div 
                                   onClick={() => onEditCourse && onEditCourse(course.id)}
                                   className="absolute inset-0 flex items-center justify-center cursor-pointer group/edit pointer-events-auto"
                               >
                                   <div className="w-1/2 h-1/2 flex items-center justify-center">
                                        <div className="px-5 py-2.5 bg-black/90 backdrop-blur-md rounded-full border border-white/20 text-white text-xs font-bold uppercase tracking-widest shadow-2xl opacity-0 group-hover/edit:opacity-100 transition-all duration-300 flex items-center gap-2 transform translate-y-4 group-hover/edit:translate-y-0">
                                            <Settings className="w-3 h-3" /> Gerenciar
                                        </div>
                                   </div>
                               </div>
                           </div>
                       )}
                   </div>
               ))}
           </div>

           {/* Newsletter Section */}
           {!isAdminMode && (
               <div className="mt-20 relative rounded-3xl bg-[#0A0A0A] border border-zinc-800 p-12 overflow-hidden">
                   <div className="relative z-10 max-w-xl">
                       <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-zinc-800 bg-zinc-900/50 mb-6">
                           <Zap className="w-3 h-3 text-white" />
                           <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">NOVO RECURSO</span>
                       </div>
                       <h2 className="text-4xl md:text-5xl font-bold text-white mb-2 leading-tight">
                           Sincronize com<br />
                           <span className="text-[#d4b589]">Inteligência.</span>
                       </h2>
                   </div>
                   <div className="absolute right-0 bottom-0 w-1/2 h-full bg-gradient-to-l from-[#d4b589]/10 to-transparent blur-3xl pointer-events-none" />
               </div>
           )}
       </div>
    </div>
  );
};
