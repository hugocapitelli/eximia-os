
import React, { useState } from 'react';
import { JOURNEY_BOOKS } from '../../constants';
import { BookCard } from '../journey/BookCard';
import { Button } from '../atoms/Button';
import { SearchBar } from '../molecules/SearchBar';
import { Plus, BookOpen, Clock, CheckCircle2, Library, Filter } from 'lucide-react';

export const JourneyLibrary: React.FC = () => {
  const [activeTab, setActiveTab] = useState('All');
  const tabs = ['All', 'Reading', 'To Read', 'Completed'];

  const filteredBooks = activeTab === 'All' 
    ? JOURNEY_BOOKS 
    : JOURNEY_BOOKS.filter(b => {
        if (activeTab === 'Reading') return b.status === 'reading';
        if (activeTab === 'To Read') return b.status === 'to_read';
        if (activeTab === 'Completed') return b.status === 'completed';
        return true;
    });

  // Stats calculation
  const readingCount = JOURNEY_BOOKS.filter(b => b.status === 'reading').length;
  const completedCount = JOURNEY_BOOKS.filter(b => b.status === 'completed').length;
  const toReadCount = JOURNEY_BOOKS.filter(b => b.status === 'to_read').length;

  return (
    <div className="max-w-7xl mx-auto px-6 py-8 animate-fade-in font-sans">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-zinc-900 dark:text-zinc-100">Biblioteca</h1>
          <p className="text-zinc-600 dark:text-zinc-400 mt-1 font-serif text-lg">
            Gestão de conhecimento e leituras.
          </p>
        </div>
        <Button icon={<Plus className="w-4 h-4" />}>Novo Livro</Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
         <div className="bg-zinc-50 dark:bg-[#18181B] p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 flex items-center gap-4">
            <div className="p-3 bg-blue-100 dark:bg-blue-900/20 rounded-lg text-blue-600 dark:text-blue-400">
               <Clock className="w-6 h-6" />
            </div>
            <div>
               <p className="text-2xl font-bold text-zinc-900 dark:text-zinc-100">{readingCount}</p>
               <p className="text-xs text-zinc-500 uppercase font-bold tracking-wider">Lendo</p>
            </div>
         </div>
         <div className="bg-zinc-50 dark:bg-[#18181B] p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 flex items-center gap-4">
            <div className="p-3 bg-emerald-100 dark:bg-emerald-900/20 rounded-lg text-emerald-600 dark:text-emerald-400">
               <CheckCircle2 className="w-6 h-6" />
            </div>
            <div>
               <p className="text-2xl font-bold text-zinc-900 dark:text-zinc-100">{completedCount}</p>
               <p className="text-xs text-zinc-500 uppercase font-bold tracking-wider">Concluídos</p>
            </div>
         </div>
         <div className="bg-zinc-50 dark:bg-[#18181B] p-4 rounded-xl border border-zinc-200 dark:border-zinc-800 flex items-center gap-4">
            <div className="p-3 bg-zinc-100 dark:bg-zinc-800 rounded-lg text-zinc-500">
               <Library className="w-6 h-6" />
            </div>
            <div>
               <p className="text-2xl font-bold text-zinc-900 dark:text-zinc-100">{toReadCount}</p>
               <p className="text-xs text-zinc-500 uppercase font-bold tracking-wider">Na Fila</p>
            </div>
         </div>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
          <div className="flex items-center gap-2 overflow-x-auto pb-2 md:pb-0 hide-scrollbar w-full md:w-auto">
            {tabs.map(tab => (
               <button
                 key={tab}
                 onClick={() => setActiveTab(tab)}
                 className={`px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap ${
                   activeTab === tab 
                     ? 'bg-zinc-900 dark:bg-zinc-100 text-zinc-100 dark:text-zinc-900 shadow-lg' 
                     : 'bg-white dark:bg-zinc-800/50 text-zinc-600 dark:text-zinc-400 hover:bg-zinc-100 dark:hover:bg-zinc-800 border border-zinc-200 dark:border-zinc-700/50'
                 }`}
               >
                 {tab}
               </button>
            ))}
          </div>
          <div className="w-full md:w-72">
              <SearchBar />
          </div>
      </div>

      {/* Book Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredBooks.map(book => (
          <BookCard key={book.id} book={book} />
        ))}
        
        {filteredBooks.length === 0 && (
             <div className="col-span-full py-16 text-center border-2 border-dashed border-zinc-200 dark:border-zinc-800 rounded-xl">
                 <BookOpen className="w-12 h-12 text-zinc-300 dark:text-zinc-700 mx-auto mb-4" />
                 <p className="text-zinc-400">Nenhum livro encontrado nesta categoria.</p>
                 <Button variant="ghost" size="sm" className="mt-2" icon={<Plus className="w-4 h-4"/>}>Adicionar Livro</Button>
             </div>
        )}
      </div>
    </div>
  );
};
