
import React from 'react';

export const DesignSystemEditor: React.FC<any> = () => {
    return null;
};
