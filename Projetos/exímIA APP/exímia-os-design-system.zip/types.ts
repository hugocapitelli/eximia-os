import React from 'react';

export type Theme = 'light' | 'dark';

export interface ColorDefinition {
  name: string;
  variable: string;
  hex: string;
  usage: string;
}

export interface TypographyDefinition {
  element: string;
  size: string;
  weight: string;
  lineHeight: string;
  description: string;
}

export interface NavigationItem {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}