import React, { useState, useEffect } from 'react';
import { 
  Layout, 
  Palette, 
  Type, 
  Box, 
  Layers, 
  Moon, 
  Sun, 
  Menu,
  Check,
  ChevronDown,
  Info,
  AlertTriangle,
  XCircle,
  Search
} from 'lucide-react';
import WindowCard from './components/WindowCard';
import ColorSwatch from './components/ColorSwatch';
import TypeSpec from './components/TypeSpec';

// --- Types & Interfaces ---
type TabId = 'overview' | 'colors' | 'typography' | 'components' | 'layout';

const App: React.FC = () => {
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [activeTab, setActiveTab] = useState<TabId>('overview');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  // Initialize theme based on system preference
  useEffect(() => {
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      setTheme('dark');
    }
  }, []);

  // Toggle Theme Effect
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.body.classList.add('bg-zinc-950');
      document.body.classList.remove('bg-slate-50');
    } else {
      document.documentElement.classList.remove('dark');
      document.body.classList.add('bg-slate-50');
      document.body.classList.remove('bg-zinc-950');
    }
  }, [theme]);

  const navItems = [
    { id: 'overview', label: 'Philosophy', icon: Layers },
    { id: 'colors', label: 'Palette', icon: Palette },
    { id: 'typography', label: 'Typography', icon: Type },
    { id: 'components', label: 'Components', icon: Box },
    { id: 'layout', label: 'Layout & Spacing', icon: Layout },
  ];

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return <OverviewSection />;
      case 'colors':
        return <ColorsSection />;
      case 'typography':
        return <TypographySection />;
      case 'components':
        return <ComponentsSection />;
      case 'layout':
        return <LayoutSection />;
      default:
        return <OverviewSection />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row font-sans text-slate-900 dark:text-zinc-100">
      {/* Sidebar Navigation */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 w-64 transform transition-transform duration-300 ease-in-out
        md:relative md:translate-x-0
        bg-slate-50 dark:bg-zinc-950 border-r border-slate-200 dark:border-zinc-800
        ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        <div className="p-6 h-full flex flex-col">
          {/* Logo / Brand */}
          <div className="flex items-center gap-3 mb-10">
            <div className="w-8 h-8 bg-amber-500 rounded-md flex items-center justify-center shadow-lg shadow-amber-500/20">
              <span className="text-amber-950 font-bold text-lg">E</span>
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight text-slate-900 dark:text-zinc-100 leading-none">ExímIA OS</h1>
              <span className="text-xs text-slate-500 dark:text-zinc-500 font-mono">Design System v1.0</span>
            </div>
          </div>

          {/* Nav Links */}
          <nav className="flex-1 space-y-1">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id as TabId);
                  setIsMobileMenuOpen(false);
                }}
                className={`
                  w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-all duration-200
                  ${activeTab === item.id 
                    ? 'bg-amber-500/10 text-amber-700 dark:text-amber-400 border border-amber-500/20' 
                    : 'text-slate-600 dark:text-zinc-400 hover:bg-slate-100 dark:hover:bg-zinc-900'}
                `}
              >
                <item.icon className={`w-4 h-4 ${activeTab === item.id ? 'text-amber-500' : 'opacity-70'}`} />
                {item.label}
              </button>
            ))}
          </nav>

          {/* Theme Toggle (Sidebar Footer) */}
          <div className="pt-6 border-t border-slate-200 dark:border-zinc-800">
             <div className="flex items-center justify-between px-3 py-2 bg-slate-100 dark:bg-zinc-900 rounded-lg">
                <span className="text-xs font-medium text-slate-500 dark:text-zinc-400">Appearance</span>
                <button
                  onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
                  className="p-1.5 rounded-md hover:bg-white dark:hover:bg-zinc-800 transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500"
                >
                  {theme === 'light' ? <Moon size={16} className="text-slate-600" /> : <Sun size={16} className="text-amber-400" />}
                </button>
             </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto h-screen bg-white dark:bg-black">
        {/* Mobile Header */}
        <div className="md:hidden sticky top-0 z-40 bg-slate-50/80 dark:bg-zinc-950/80 backdrop-blur-md border-b border-slate-200 dark:border-zinc-800 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 bg-amber-500 rounded flex items-center justify-center">
              <span className="text-amber-950 font-bold text-xs">E</span>
            </div>
            <span className="font-semibold text-sm">ExímIA OS</span>
          </div>
          <button onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} className="p-2 text-slate-600 dark:text-zinc-400">
            <Menu size={20} />
          </button>
        </div>

        {/* Content Container */}
        <div className="max-w-7xl mx-auto px-4 sm:px-8 py-10">
          {renderContent()}
        </div>
      </main>

      {/* Mobile Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 md:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </div>
  );
};

// --- Section Components ---

const OverviewSection = () => (
  <div className="space-y-8 animate-[fadeIn_0.3s_ease-out]">
    <header className="mb-12">
      <h1 className="text-4xl font-bold text-slate-900 dark:text-zinc-100 mb-4 tracking-tight">Soft Business Philosophy</h1>
      <p className="text-xl text-slate-600 dark:text-zinc-400 max-w-3xl leading-relaxed">
        ExímIA OS bridges the gap between serious enterprise tools and premium consumer products. 
        We call this aesthetic "Soft Business" — organized, data-dense, yet approachable and optimistic.
      </p>
    </header>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <WindowCard title="Visual Principles" className="h-full">
        <ul className="space-y-6">
          <li className="flex items-start gap-4">
            <div className="mt-1 w-8 h-8 rounded-full bg-slate-100 dark:bg-zinc-800 flex items-center justify-center text-slate-900 dark:text-zinc-100 font-bold text-sm">1</div>
            <div>
              <h3 className="text-lg font-semibold text-slate-900 dark:text-zinc-100 mb-1">Consistent Containment</h3>
              <p className="text-slate-600 dark:text-zinc-400 text-sm leading-relaxed">
                Tools live within "windows". We simulate a desktop-app experience on the web to provide a sense of stability and focus.
              </p>
            </div>
          </li>
          <li className="flex items-start gap-4">
            <div className="mt-1 w-8 h-8 rounded-full bg-slate-100 dark:bg-zinc-800 flex items-center justify-center text-slate-900 dark:text-zinc-100 font-bold text-sm">2</div>
            <div>
              <h3 className="text-lg font-semibold text-slate-900 dark:text-zinc-100 mb-1">Data Density</h3>
              <p className="text-slate-600 dark:text-zinc-400 text-sm leading-relaxed">
                We respect the user's intelligence. Interfaces are optimized for readability without hiding necessary complexity.
              </p>
            </div>
          </li>
          <li className="flex items-start gap-4">
            <div className="mt-1 w-8 h-8 rounded-full bg-slate-100 dark:bg-zinc-800 flex items-center justify-center text-slate-900 dark:text-zinc-100 font-bold text-sm">3</div>
            <div>
              <h3 className="text-lg font-semibold text-slate-900 dark:text-zinc-100 mb-1">Stark Contrast</h3>
              <p className="text-slate-600 dark:text-zinc-400 text-sm leading-relaxed">
                A sharp divide between themes. Dark mode uses deep blacks and zincs for high contrast; Light mode uses soft slates and whites.
              </p>
            </div>
          </li>
        </ul>
      </WindowCard>

      <div className="space-y-6">
         <WindowCard title="Primary Brand Color" className="bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/30">
            <div className="flex flex-col items-center justify-center py-8 text-center">
              <div className="w-24 h-24 bg-amber-500 rounded-2xl shadow-xl shadow-amber-500/20 mb-6 flex items-center justify-center">
                <Sun size={40} className="text-amber-950" />
              </div>
              <h3 className="text-xl font-bold text-amber-900 dark:text-amber-100">ExímIA Amber</h3>
              <p className="mt-2 text-amber-800/80 dark:text-amber-200/60 text-sm max-w-xs">
                Represents energy, optimism, and clarity. It cuts through the neutral noise to guide action.
              </p>
            </div>
         </WindowCard>

         <WindowCard title="Interface Chrome" className="h-64 flex flex-col justify-center items-center">
            <div className="text-center p-6">
               <div className="text-slate-400 dark:text-zinc-600 mb-4">
                 <Layout size={48} className="mx-auto opacity-50" />
               </div>
               <p className="text-sm font-medium text-slate-500 dark:text-zinc-500">
                 "Interface disappears for content to shine."
               </p>
            </div>
         </WindowCard>
      </div>
    </div>
  </div>
);

const ColorsSection = () => (
  <div className="space-y-10 animate-[fadeIn_0.3s_ease-out]">
    <div className="border-b border-slate-200 dark:border-zinc-800 pb-6">
      <h2 className="text-3xl font-bold mb-2">Color Palette</h2>
      <p className="text-slate-600 dark:text-zinc-400">
        A system built on functional neutrals (Slate/Zinc) and a vibrant primary action color (Amber).
      </p>
    </div>

    <WindowCard title="Primary Scale: Amber">
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-11 gap-4">
        <ColorSwatch name="50" shade="Bg" hex="#fffcf7" />
        <ColorSwatch name="100" shade="Highlight" hex="#fef6e6" />
        <ColorSwatch name="200" shade="Light" hex="#fde8c4" />
        <ColorSwatch name="300" shade="Soft" hex="#fdd595" />
        <ColorSwatch name="400" shade="Accent" hex="#fdc779" description="Secondary" />
        <ColorSwatch name="500" shade="Primary" hex="#fdbf68" description="Brand Base" textColor="text-amber-950" />
        <ColorSwatch name="600" shade="Hover" hex="#db9d46" textColor="text-white" />
        <ColorSwatch name="700" shade="Deep" hex="#b87a30" textColor="text-white" />
        <ColorSwatch name="800" shade="Darker" hex="#945d25" textColor="text-white" />
        <ColorSwatch name="900" shade="Text" hex="#78481f" textColor="text-white" />
        <ColorSwatch name="950" shade="Deepest" hex="#45260d" textColor="text-white" />
      </div>
    </WindowCard>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <WindowCard title="Semantic Colors">
        <div className="space-y-4">
          <div className="flex items-center gap-4">
             <div className="w-16 h-16 rounded-lg bg-emerald-500 shadow-sm"></div>
             <div>
               <p className="font-bold text-slate-900 dark:text-zinc-100">Success</p>
               <p className="text-xs font-mono text-slate-500">emerald-500 (Light) / emerald-400 (Dark)</p>
               <p className="text-sm text-slate-600 dark:text-zinc-400">Confirmations, completion, positive trends.</p>
             </div>
          </div>
          <div className="flex items-center gap-4">
             <div className="w-16 h-16 rounded-lg bg-orange-500 shadow-sm"></div>
             <div>
               <p className="font-bold text-slate-900 dark:text-zinc-100">Warning</p>
               <p className="text-xs font-mono text-slate-500">orange-500 (Light) / orange-400 (Dark)</p>
               <p className="text-sm text-slate-600 dark:text-zinc-400">Alerts, attention needed, pending states.</p>
             </div>
          </div>
          <div className="flex items-center gap-4">
             <div className="w-16 h-16 rounded-lg bg-rose-500 shadow-sm"></div>
             <div>
               <p className="font-bold text-slate-900 dark:text-zinc-100">Destructive</p>
               <p className="text-xs font-mono text-slate-500">rose-500 (Light) / rose-400 (Dark)</p>
               <p className="text-sm text-slate-600 dark:text-zinc-400">Deletions, critical errors, dangerous actions.</p>
             </div>
          </div>
          <div className="flex items-center gap-4">
             <div className="w-16 h-16 rounded-lg bg-sky-500 shadow-sm"></div>
             <div>
               <p className="font-bold text-slate-900 dark:text-zinc-100">Info</p>
               <p className="text-xs font-mono text-slate-500">sky-500 (Light) / sky-400 (Dark)</p>
               <p className="text-sm text-slate-600 dark:text-zinc-400">Guidance, tips, neutral status updates.</p>
             </div>
          </div>
        </div>
      </WindowCard>

      <WindowCard title="Neutral System">
         <div className="space-y-6">
            <div>
               <h4 className="text-sm font-semibold mb-3 uppercase tracking-wider text-slate-500">Light Mode (Slate)</h4>
               <div className="grid grid-cols-5 gap-2">
                 <div className="h-10 rounded bg-slate-50 border border-slate-200" title="Surface"></div>
                 <div className="h-10 rounded bg-slate-100" title="Subtle"></div>
                 <div className="h-10 rounded bg-slate-200" title="Border"></div>
                 <div className="h-10 rounded bg-slate-600" title="Body Text"></div>
                 <div className="h-10 rounded bg-slate-900" title="Heading"></div>
               </div>
               <div className="mt-2 flex justify-between text-xs font-mono text-slate-400">
                  <span>Surface</span>
                  <span>Heading</span>
               </div>
            </div>

            <div>
               <h4 className="text-sm font-semibold mb-3 uppercase tracking-wider text-slate-500">Dark Mode (Zinc)</h4>
               <div className="grid grid-cols-5 gap-2">
                 <div className="h-10 rounded bg-zinc-950 border border-zinc-800" title="Background"></div>
                 <div className="h-10 rounded bg-zinc-900" title="Surface/Subtle"></div>
                 <div className="h-10 rounded bg-zinc-800" title="Border"></div>
                 <div className="h-10 rounded bg-zinc-400" title="Body Text"></div>
                 <div className="h-10 rounded bg-zinc-100" title="Heading"></div>
               </div>
               <div className="mt-2 flex justify-between text-xs font-mono text-zinc-500">
                  <span>Background</span>
                  <span>Heading</span>
               </div>
            </div>
         </div>
      </WindowCard>
    </div>
  </div>
);

const TypographySection = () => (
  <div className="space-y-8 animate-[fadeIn_0.3s_ease-out]">
    <div className="border-b border-slate-200 dark:border-zinc-800 pb-6">
      <h2 className="text-3xl font-bold mb-2">Typography</h2>
      <p className="text-slate-600 dark:text-zinc-400">
        Prioritizing readability and data density. Using <span className="font-semibold text-slate-900 dark:text-zinc-100">Inter</span> for UI and <span className="font-mono font-medium text-slate-800 dark:text-zinc-200">JetBrains Mono</span> for technical data.
      </p>
    </div>

    <WindowCard title="Scale & Hierarchy">
      <div className="space-y-2">
        <TypeSpec 
          element="Display" 
          specs="48px / Bold / 1.1" 
          sample="Make it happen." 
          className="text-5xl font-bold tracking-tight leading-[1.1]"
        />
        <TypeSpec 
          element="H1 / Page Title" 
          specs="30px / SemiBold / 1.2" 
          sample="Dashboard Overview" 
          className="text-3xl font-semibold leading-tight"
        />
        <TypeSpec 
          element="H2 / Section" 
          specs="24px / SemiBold / 1.3" 
          sample="Recent Activity" 
          className="text-2xl font-semibold leading-snug"
        />
        <TypeSpec 
          element="Body / Default" 
          specs="16px / Regular / 1.5" 
          sample="The quick brown fox jumps over the lazy dog. Used for standard content paragraphs." 
          className="text-base font-normal leading-relaxed text-slate-600 dark:text-zinc-300"
        />
        <TypeSpec 
          element="Label / Mono" 
          specs="14px / Medium / 1.4" 
          sample="ID: #88219-X" 
          className="text-sm font-mono font-medium tracking-wide text-slate-500 dark:text-zinc-400"
        />
        <TypeSpec 
          element="Caption" 
          specs="12px / Regular / 1.4" 
          sample="Updated 2 hours ago" 
          className="text-xs font-normal text-slate-500 dark:text-zinc-500"
        />
      </div>
    </WindowCard>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <WindowCard title="Font Usage Rule">
        <div className="bg-slate-100 dark:bg-zinc-900 p-6 rounded-md mb-4 border border-slate-200 dark:border-zinc-800">
          <h3 className="font-sans text-xl font-bold text-slate-900 dark:text-zinc-100 mb-2">Inter</h3>
          <p className="font-sans text-slate-600 dark:text-zinc-400">
            Use for headlines, navigation, body copy, and general UI labels. Optimized for screen legibility at small sizes.
          </p>
        </div>
        <div className="bg-slate-100 dark:bg-zinc-900 p-6 rounded-md border border-slate-200 dark:border-zinc-800">
          <h3 className="font-mono text-xl font-medium text-slate-900 dark:text-zinc-100 mb-2">JetBrains Mono</h3>
          <p className="font-mono text-sm text-slate-600 dark:text-zinc-400">
            USE_FOR: IDs, code_snippets, tabular_data, timestamps, and technical_metadata.
          </p>
        </div>
      </WindowCard>

       <WindowCard title="Density Example">
         <div className="space-y-4">
           <div>
             <label className="block text-xs font-medium text-slate-500 dark:text-zinc-500 mb-1">PROJECT NAME</label>
             <div className="text-sm font-semibold text-slate-900 dark:text-zinc-100">ExímIA Financial Suite</div>
           </div>
           <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-zinc-500 mb-1">API KEY</label>
                <div className="font-mono text-xs bg-slate-100 dark:bg-zinc-900 p-2 rounded border border-slate-200 dark:border-zinc-800 text-slate-700 dark:text-zinc-300">pk_live_559201...</div>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-500 dark:text-zinc-500 mb-1">STATUS</label>
                <div className="flex items-center gap-2 mt-1">
                   <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                   <span className="text-sm text-slate-700 dark:text-zinc-300">Operational</span>
                </div>
              </div>
           </div>
         </div>
       </WindowCard>
    </div>
  </div>
);

const ComponentsSection = () => (
  <div className="space-y-10 animate-[fadeIn_0.3s_ease-out]">
    <div className="border-b border-slate-200 dark:border-zinc-800 pb-6">
      <h2 className="text-3xl font-bold mb-2">Component Library</h2>
      <p className="text-slate-600 dark:text-zinc-400">
        Interactable elements designed with clear states and subtle affordances.
      </p>
    </div>

    {/* Buttons */}
    <WindowCard title="Button System">
      <div className="space-y-8">
        <div className="flex flex-wrap items-center gap-4">
          <button className="px-4 py-2 rounded-md text-sm font-medium transition-transform active:scale-95 bg-amber-500 hover:bg-amber-600 text-amber-950 dark:bg-amber-400 dark:hover:bg-amber-300 dark:text-zinc-900 shadow-sm">
            Primary Action
          </button>
          <button className="px-4 py-2 rounded-md text-sm font-medium transition-transform active:scale-95 bg-slate-100 hover:bg-slate-200 text-slate-900 dark:bg-zinc-800 dark:hover:bg-zinc-700 dark:text-zinc-100 border border-slate-200 dark:border-zinc-700">
            Secondary
          </button>
          <button className="px-4 py-2 rounded-md text-sm font-medium transition-transform active:scale-95 text-slate-600 hover:bg-slate-100 dark:text-zinc-400 dark:hover:bg-zinc-800">
            Ghost / Link
          </button>
          <button className="px-4 py-2 rounded-md text-sm font-medium transition-transform active:scale-95 bg-rose-500 hover:bg-rose-600 text-white shadow-sm">
            Destructive
          </button>
          <button disabled className="px-4 py-2 rounded-md text-sm font-medium bg-slate-100 text-slate-400 cursor-not-allowed dark:bg-zinc-800 dark:text-zinc-600">
            Disabled
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-slate-50 dark:bg-zinc-900/50 p-4 rounded border border-slate-200 dark:border-zinc-800">
          <div>
            <span className="text-xs font-mono text-slate-400 dark:text-zinc-500 block mb-2">PRIMARY (LIGHT)</span>
            <code className="text-xs bg-white dark:bg-zinc-950 p-1 rounded border border-slate-200 dark:border-zinc-800 block">bg-amber-500 text-amber-950 hover:bg-amber-600</code>
          </div>
          <div>
            <span className="text-xs font-mono text-slate-400 dark:text-zinc-500 block mb-2">PRIMARY (DARK)</span>
            <code className="text-xs bg-white dark:bg-zinc-950 p-1 rounded border border-slate-200 dark:border-zinc-800 block">bg-amber-400 text-zinc-900 hover:bg-amber-300</code>
          </div>
        </div>
      </div>
    </WindowCard>

    {/* Form Controls */}
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <WindowCard title="Form Controls">
        <form className="space-y-4" onSubmit={(e) => e.preventDefault()}>
          <div className="space-y-1">
            <label className="block text-sm font-medium text-slate-700 dark:text-zinc-300">Email Address</label>
            <div className="relative">
              <input 
                type="email" 
                placeholder="name@company.com" 
                className="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-slate-300 dark:border-zinc-700 rounded-md text-sm shadow-sm placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent transition-all"
              />
            </div>
          </div>

          <div className="space-y-1">
             <label className="block text-sm font-medium text-slate-700 dark:text-zinc-300">Role</label>
             <div className="relative">
                <select className="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-slate-300 dark:border-zinc-700 rounded-md text-sm shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-transparent appearance-none">
                  <option>Administrator</option>
                  <option>Editor</option>
                  <option>Viewer</option>
                </select>
                <ChevronDown className="absolute right-3 top-2.5 text-slate-400 pointer-events-none" size={16} />
             </div>
          </div>

          <div className="flex items-center gap-2 pt-2">
             <input type="checkbox" id="check" className="w-4 h-4 text-amber-500 border-slate-300 rounded focus:ring-amber-500 dark:border-zinc-700 dark:bg-zinc-900" />
             <label htmlFor="check" className="text-sm text-slate-600 dark:text-zinc-400">Enable notifications</label>
          </div>
        </form>
      </WindowCard>

      <WindowCard title="Alerts & Status">
        <div className="space-y-4">
           {/* Info */}
           <div className="flex gap-3 p-3 rounded-md bg-sky-50 dark:bg-sky-900/20 border border-sky-100 dark:border-sky-800">
              <Info className="text-sky-500 shrink-0" size={20} />
              <div>
                <h4 className="text-sm font-medium text-sky-900 dark:text-sky-200">Update Available</h4>
                <p className="text-xs text-sky-700 dark:text-sky-300/70 mt-0.5">A new version of the dashboard is ready.</p>
              </div>
           </div>

           {/* Warning */}
           <div className="flex gap-3 p-3 rounded-md bg-orange-50 dark:bg-orange-900/20 border border-orange-100 dark:border-orange-800">
              <AlertTriangle className="text-orange-500 shrink-0" size={20} />
              <div>
                <h4 className="text-sm font-medium text-orange-900 dark:text-orange-200">Storage Low</h4>
                <p className="text-xs text-orange-700 dark:text-orange-300/70 mt-0.5">You are at 95% of your storage capacity.</p>
              </div>
           </div>

           {/* Destructive */}
           <div className="flex gap-3 p-3 rounded-md bg-rose-50 dark:bg-rose-900/20 border border-rose-100 dark:border-rose-800">
              <XCircle className="text-rose-500 shrink-0" size={20} />
              <div>
                <h4 className="text-sm font-medium text-rose-900 dark:text-rose-200">Payment Failed</h4>
                <p className="text-xs text-rose-700 dark:text-rose-300/70 mt-0.5">Please check your payment method.</p>
              </div>
           </div>
        </div>
      </WindowCard>
    </div>
  </div>
);

const LayoutSection = () => (
  <div className="space-y-10 animate-[fadeIn_0.3s_ease-out]">
     <div className="border-b border-slate-200 dark:border-zinc-800 pb-6">
      <h2 className="text-3xl font-bold mb-2">Spacing & Radius</h2>
      <p className="text-slate-600 dark:text-zinc-400">
        Based on a 4px grid system for mathematical rhythm and consistency.
      </p>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <WindowCard title="Spacing Scale (Base 4px)">
        <div className="space-y-4">
           {[
             { name: 'xs', val: '4px', class: 'h-4 w-4' },
             { name: 'sm', val: '8px', class: 'h-8 w-8' },
             { name: 'md', val: '16px', class: 'h-16 w-16' },
             { name: 'lg', val: '24px', class: 'h-24 w-24' },
             { name: 'xl', val: '32px', class: 'h-32 w-32' },
           ].map((space) => (
             <div key={space.name} className="flex items-center gap-6">
                <div className="w-16 font-mono text-sm text-slate-500 dark:text-zinc-400 text-right">{space.name} ({space.val})</div>
                <div className={`${space.class} bg-amber-200 dark:bg-amber-900/40 border border-amber-500/30 rounded relative`}>
                   <div className="absolute inset-0 flex items-center justify-center text-[10px] text-amber-700 dark:text-amber-500 font-mono hidden md:flex">
                     {space.val}
                   </div>
                </div>
             </div>
           ))}
        </div>
      </WindowCard>

      <WindowCard title="Border Radius">
         <div className="grid grid-cols-2 gap-6">
            <div className="flex flex-col items-center gap-2">
               <div className="w-20 h-20 bg-slate-200 dark:bg-zinc-800 rounded-sm border border-slate-300 dark:border-zinc-700"></div>
               <span className="text-xs font-mono text-slate-500">sm (4px)</span>
            </div>
            <div className="flex flex-col items-center gap-2">
               <div className="w-20 h-20 bg-slate-200 dark:bg-zinc-800 rounded-md border border-slate-300 dark:border-zinc-700"></div>
               <span className="text-xs font-mono text-slate-500">md (6px)</span>
            </div>
            <div className="flex flex-col items-center gap-2">
               <div className="w-20 h-20 bg-slate-200 dark:bg-zinc-800 rounded-lg border border-slate-300 dark:border-zinc-700"></div>
               <span className="text-xs font-mono text-slate-500">lg (8px)</span>
            </div>
            <div className="flex flex-col items-center gap-2">
               <div className="w-20 h-20 bg-slate-200 dark:bg-zinc-800 rounded-xl border border-slate-300 dark:border-zinc-700"></div>
               <span className="text-xs font-mono text-slate-500">xl (12px)</span>
            </div>
         </div>
      </WindowCard>
    </div>

    <WindowCard title="Shadow & Elevation">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 p-4">
         <div className="h-32 bg-white dark:bg-zinc-900 rounded-lg shadow-sm border border-slate-100 dark:border-zinc-800 flex items-center justify-center">
            <span className="text-sm font-mono text-slate-400">shadow-sm</span>
         </div>
         <div className="h-32 bg-white dark:bg-zinc-900 rounded-lg shadow-md border border-slate-100 dark:border-zinc-800 flex items-center justify-center">
            <span className="text-sm font-mono text-slate-400">shadow-md</span>
         </div>
         <div className="h-32 bg-white dark:bg-zinc-900 rounded-lg shadow-xl border border-slate-100 dark:border-zinc-800 flex items-center justify-center">
            <span className="text-sm font-mono text-slate-400">shadow-xl</span>
         </div>
      </div>
    </WindowCard>
  </div>
);

export default App;