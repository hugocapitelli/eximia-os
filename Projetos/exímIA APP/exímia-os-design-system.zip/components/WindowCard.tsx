import React from 'react';

interface WindowCardProps {
  title: string;
  children: React.ReactNode;
  className?: string;
  footer?: React.ReactNode;
  noPadding?: boolean;
}

const WindowCard: React.FC<WindowCardProps> = ({ 
  title, 
  children, 
  className = "", 
  footer,
  noPadding = false
}) => {
  return (
    <div className={`
      group
      flex flex-col 
      rounded-lg 
      border border-slate-200 dark:border-zinc-800 
      bg-slate-50 dark:bg-zinc-950 
      shadow-sm 
      overflow-hidden
      transition-all duration-300 ease-out
      hover:shadow-md
      ${className}
    `}>
      {/* Window Chrome Header */}
      <div className="
        h-10 px-4 
        flex items-center justify-between 
        bg-slate-100 dark:bg-zinc-900 
        border-b border-slate-200 dark:border-zinc-800
        select-none
      ">
        <div className="flex items-center gap-2">
          {/* Traffic Lights / Window Controls Simulation */}
          <div className="flex gap-1.5 opacity-60 group-hover:opacity-100 transition-opacity duration-200">
            <div className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-zinc-700" />
            <div className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-zinc-700" />
            <div className="w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-zinc-700" />
          </div>
          {/* Vertical Separator */}
          <div className="h-4 w-px bg-slate-300 dark:bg-zinc-800 mx-2" />
          {/* Title */}
          <span className="text-xs font-mono font-medium text-slate-500 dark:text-zinc-500 tracking-wide uppercase">
            {title}
          </span>
        </div>
      </div>

      {/* Content Area */}
      <div className={`flex-1 ${noPadding ? '' : 'p-6'}`}>
        {children}
      </div>

      {/* Optional Footer */}
      {footer && (
        <div className="
          px-6 py-3 
          bg-slate-50 dark:bg-zinc-900/50 
          border-t border-slate-200 dark:border-zinc-800
        ">
          {footer}
        </div>
      )}
    </div>
  );
};

export default WindowCard;