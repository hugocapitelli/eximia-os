import React from 'react';

interface TypeSpecProps {
  element: string;
  specs: string; // e.g., "48px / 700 / 1.1"
  sample: string;
  className?: string;
}

const TypeSpec: React.FC<TypeSpecProps> = ({ element, specs, sample, className = "" }) => {
  return (
    <div className="flex flex-col md:flex-row md:items-baseline gap-4 py-6 border-b border-slate-100 dark:border-zinc-800 last:border-0">
      <div className="w-full md:w-1/4 flex flex-col gap-1">
        <span className="text-sm font-bold text-amber-600 dark:text-amber-500">{element}</span>
        <span className="font-mono text-xs text-slate-400 dark:text-zinc-500">{specs}</span>
      </div>
      <div className={`w-full md:w-3/4 text-slate-900 dark:text-zinc-100 ${className}`}>
        {sample}
      </div>
    </div>
  );
};

export default TypeSpec;