import React from 'react';

interface ColorSwatchProps {
  name: string;
  shade: string;
  hex: string;
  textColor?: string;
  description?: string;
}

const ColorSwatch: React.FC<ColorSwatchProps> = ({ 
  name, 
  shade, 
  hex, 
  textColor = "text-slate-900",
  description
}) => {
  return (
    <div className="flex flex-col gap-2">
      <div 
        className="
          h-24 w-full rounded-md shadow-sm border border-black/5 dark:border-white/5 
          flex flex-col justify-end p-3 relative group overflow-hidden
        "
        style={{ backgroundColor: hex }}
      >
        <span className={`font-mono text-xs font-bold ${textColor} opacity-90`}>{shade}</span>
        <span className={`font-mono text-[10px] ${textColor} opacity-70`}>{hex}</span>
        
        {/* Copy Hex on Hover Interaction */}
        <div 
          className="absolute inset-0 flex items-center justify-center bg-black/10 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
          onClick={() => navigator.clipboard.writeText(hex)}
        >
          <span className="text-white text-xs font-medium">Copy</span>
        </div>
      </div>
      <div className="flex flex-col">
        <span className="text-sm font-medium text-slate-700 dark:text-zinc-200">{name}</span>
        {description && (
          <span className="text-xs text-slate-500 dark:text-zinc-500">{description}</span>
        )}
      </div>
    </div>
  );
};

export default ColorSwatch;