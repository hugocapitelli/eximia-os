
import React, { useState, useEffect } from 'react';
import { ViewType, UserRole } from '../types';

interface SidebarProps {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
  isOpen: boolean;
  onToggle: () => void;
  userRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  logoUrl: string;
}

const Sidebar: React.FC<SidebarProps> = ({ currentView, onNavigate, isOpen, userRole, onRoleChange, logoUrl }) => {
  const [imgError, setImgError] = useState(false);

  // Reseta o erro quando a URL do logo muda (ex: novo upload)
  useEffect(() => {
    setImgError(false);
  }, [logoUrl]);
  
  const NavItem = ({ icon, label, view, activeView }: { icon: string, label: string, view: ViewType, activeView: ViewType }) => {
    const isActive = activeView === view || 
                    (view === 'COURSE_LIST' && (activeView === 'COURSE_DETAILS' || activeView === 'CHAPTER_DETAIL' || activeView === 'CHAPTER_READER')) ||
                    (view === 'INSTRUCTOR_LIST' && (activeView === 'INSTRUCTOR_DETAIL' || activeView === 'CONTENT_REVISION' || activeView === 'DISCIPLINE_EDIT' || activeView === 'COURSE_EDIT'));

    return (
      <button 
        onClick={() => onNavigate(view)}
        className={`flex items-center gap-3 px-3 py-3 rounded-lg transition-all group w-full text-left
          ${isActive ? 'bg-primary/10 text-primary' : 'text-gray-400 hover:bg-white/5 hover:text-white'}`}
      >
        <span className={`material-symbols-outlined text-[22px] ${isActive ? 'fill-1' : ''}`}>{icon}</span>
        {isOpen && <span className="text-sm font-medium animate-in fade-in duration-200">{label}</span>}
      </button>
    );
  };

  const getUserData = () => {
    switch (userRole) {
      case 'STUDENT': return { name: 'Aluno Premium', plan: 'Plano Pro', img: 'https://picsum.photos/seed/student/100/100' };
      case 'INSTRUCTOR': return { name: 'Prof. Elena Vance', plan: 'Docente Titular', img: 'https://picsum.photos/seed/teacher/100/100' };
      case 'ADMIN': return { name: 'Admin System', plan: 'Super Admin', img: 'https://picsum.photos/seed/admin/100/100' };
    }
  };

  const userData = getUserData();

  return (
    <aside className={`${isOpen ? 'w-64' : 'w-20'} h-full bg-harven-sidebar flex flex-col flex-shrink-0 transition-all duration-300 z-30 border-r border-white/5`}>
      <div className="h-16 flex items-center px-6 border-b border-white/10 gap-3 overflow-hidden">
        <div 
          onClick={() => onNavigate(userRole === 'STUDENT' ? 'STUDENT_DASHBOARD' : userRole === 'INSTRUCTOR' ? 'INSTRUCTOR_LIST' : 'ADMIN_CONSOLE')}
          className="flex items-center cursor-pointer transition-transform hover:scale-105 origin-left"
        >
          {isOpen ? (
             !imgError ? (
               <img 
                 src={logoUrl} 
                 alt="Logo" 
                 className="h-10 w-auto object-contain animate-in fade-in duration-200" 
                 onError={() => setImgError(true)}
               />
             ) : (
               <span className="text-white text-xl font-bold tracking-tight font-display whitespace-nowrap animate-in fade-in">PLATAFORMA</span>
             )
          ) : (
             !imgError ? (
               <img 
                 src={logoUrl} 
                 alt="Logo" 
                 className="size-8 object-contain"
                 onError={() => setImgError(true)}
               />
             ) : (
               <div className="size-8 rounded bg-primary flex items-center justify-center flex-shrink-0">
                 <span className="material-symbols-outlined text-harven-dark font-bold text-xl">token</span>
               </div>
             )
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto py-6 px-3 flex flex-col gap-1">
        
        {userRole === 'STUDENT' && (
          <>
            {isOpen && <p className="px-3 text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2 animate-in slide-in-from-left-2">Área do Aluno</p>}
            <NavItem icon="dashboard" label="Dashboard" view="STUDENT_DASHBOARD" activeView={currentView} />
            <NavItem icon="school" label="Meus Cursos" view="COURSE_LIST" activeView={currentView} />
            <NavItem icon="history" label="Histórico" view="STUDENT_HISTORY" activeView={currentView} />
            <NavItem icon="emoji_events" label="Conquistas" view="STUDENT_ACHIEVEMENTS" activeView={currentView} />
            
            <div className="my-2 h-px bg-white/5"></div>
            
            <a 
              href="#" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-3 px-3 py-3 rounded-lg transition-all group w-full text-left text-gray-400 hover:bg-white/5 hover:text-white"
            >
              <span className="material-symbols-outlined text-[22px]">contact_page</span>
              {isOpen && (
                <div className="flex-1 flex items-center justify-between animate-in fade-in duration-200">
                   <span className="text-sm font-medium">Portal do Aluno</span>
                   <span className="material-symbols-outlined text-[16px] opacity-50 group-hover:opacity-100 transition-opacity">open_in_new</span>
                </div>
              )}
            </a>
          </>
        )}
        
        {userRole === 'INSTRUCTOR' && (
          <>
            {isOpen && <p className="px-3 text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2 animate-in slide-in-from-left-2">Acadêmico</p>}
            <NavItem icon="groups" label="Minhas Turmas" view="INSTRUCTOR_LIST" activeView={currentView} />
          </>
        )}
        
        {userRole === 'ADMIN' && (
          <>
            {isOpen && <p className="px-3 text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 animate-in slide-in-from-left-2">Administração</p>}
            <NavItem icon="admin_panel_settings" label="Console Geral" view="ADMIN_CONSOLE" activeView={currentView} />
            <NavItem icon="class" label="Gestão de Turmas" view="ADMIN_CLASSES" activeView={currentView} />
            <NavItem icon="group" label="Usuários" view="USER_MANAGEMENT" activeView={currentView} />
            <NavItem icon="settings" label="Configurações" view="SYSTEM_SETTINGS" activeView={currentView} />
          </>
        )}

      </div>

      <div className="p-4 border-t border-white/10 bg-black/20">
        <div className="flex flex-col gap-2">
          {isOpen && <label className="text-[9px] font-bold text-gray-500 uppercase tracking-widest px-1">Alternar Perfil (Demo)</label>}
          <div className="flex items-center gap-3 px-2 py-2 bg-white/5 rounded-lg border border-white/5">
            <img 
              src={userData.img} 
              alt="User" 
              className="size-8 rounded-full border border-harven-gold object-cover"
            />
            {isOpen ? (
              <div className="flex-1 min-w-0">
                 <select 
                  value={userRole}
                  onChange={(e) => onRoleChange(e.target.value as UserRole)}
                  className="bg-transparent border-none p-0 text-white text-sm font-medium focus:ring-0 w-full cursor-pointer"
                 >
                   <option value="STUDENT" className="text-black">Aluno</option>
                   <option value="INSTRUCTOR" className="text-black">Professor</option>
                   <option value="ADMIN" className="text-black">Admin</option>
                 </select>
                 <p className="text-harven-gold text-[10px] uppercase font-bold tracking-tighter">{userData.plan}</p>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
