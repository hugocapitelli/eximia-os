
import React, { useState, useEffect } from 'react';
import { ViewType } from '../types';

interface HeaderProps {
  title: string;
  onNavigate: (view: ViewType) => void;
  currentView: ViewType;
  onBack?: () => void;
  logoUrl: string;
}

const Header: React.FC<HeaderProps> = ({ title, onNavigate, currentView, onBack, logoUrl }) => {
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    setImgError(false);
  }, [logoUrl]);

  return (
    <header className="h-16 bg-harven-dark border-b border-white/5 flex items-center justify-between px-6 flex-shrink-0 z-20">
      <div className="flex items-center gap-4">
        {onBack && (
          <button 
            onClick={onBack}
            className="p-1 hover:bg-white/10 rounded text-gray-400 hover:text-white transition-colors"
            title="Voltar"
          >
            <span className="material-symbols-outlined">arrow_back</span>
          </button>
        )}
        <div className="flex items-center text-sm text-gray-400 font-display">
          {!imgError && (
            <img 
              src={logoUrl} 
              alt="Logo" 
              className="h-8 w-auto mr-3 cursor-pointer hover:opacity-80 object-contain"
              onClick={() => onNavigate('STUDENT_DASHBOARD')}
              onError={() => setImgError(true)}
            />
          )}
          {imgError && (
             <span className="material-symbols-outlined text-[20px] mr-2 text-primary">token</span>
          )}
          <span className="material-symbols-outlined text-[16px] mx-1">chevron_right</span>
          <span className="text-white font-medium">{title}</span>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="hidden md:flex relative group">
          <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-500 text-[20px]">search</span>
          <input 
            className="bg-[#152214] text-gray-200 text-sm rounded-lg pl-10 pr-4 py-1.5 border border-white/5 focus:outline-none focus:border-primary w-64 placeholder-gray-600 transition-all"
            placeholder="Pesquisar..."
            type="text"
          />
        </div>
        
        <button className="relative p-2 text-gray-400 hover:text-white transition-colors">
          <span className="material-symbols-outlined">notifications</span>
          <span className="absolute top-2 right-2 size-2 bg-primary rounded-full border-2 border-harven-dark"></span>
        </button>
        
        <button className="p-2 text-gray-400 hover:text-white transition-colors">
          <span className="material-symbols-outlined">help</span>
        </button>

        <div className="h-8 w-px bg-white/10 mx-1"></div>
        
        <button className="hidden sm:flex flex-col items-end mr-2">
          <span className="text-white text-xs font-bold leading-none">Minha Conta</span>
          <span className="text-harven-gold text-[10px] font-medium leading-none mt-1">Configurações</span>
        </button>
      </div>
    </header>
  );
};

export default Header;
