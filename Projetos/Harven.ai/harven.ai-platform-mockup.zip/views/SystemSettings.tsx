
import React, { useState } from 'react';

interface SystemSettingsProps {
  onLogoUpdate?: (url: string) => void;
  logoUrl?: string;
}

const SystemSettings: React.FC<SystemSettingsProps> = ({ onLogoUpdate, logoUrl = '/assets/logo/2.png' }) => {
  const [activeTab, setActiveTab] = useState<'general' | 'integrations' | 'security' | 'logs'>('general');

  // Mock de Logs
  const auditLogs = [
      { id: 1, action: 'Alteração de Permissão', user: 'Admin System', target: 'Pedro Alves', ip: '192.168.1.42', date: 'Hoje, 14:32' },
      { id: 2, action: 'Atualização de Chave API', user: 'Admin System', target: 'OpenAI Integration', ip: '192.168.1.42', date: 'Ontem, 09:15' },
      { id: 3, action: 'Login Falho', user: 'julia.l@harven.edu', target: 'Sistema', ip: '200.14.55.12', date: 'Ontem, 18:40' },
      { id: 4, action: 'Backup Manual', user: 'Admin System', target: 'Database', ip: '192.168.1.42', date: '12 Out, 10:00' },
  ];

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const imageUrl = URL.createObjectURL(file);
      if (onLogoUpdate) {
        onLogoUpdate(imageUrl);
      }
    }
  };

  return (
    <div className="flex flex-col flex-1 h-full overflow-hidden bg-harven-bg">
      {/* Sticky Header with Tabs */}
      <div className="bg-white border-b border-harven-border px-8 py-4 flex-shrink-0 z-10 sticky top-0 shadow-sm">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-end md:items-center gap-4">
           <div className="flex gap-8 overflow-x-auto no-scrollbar w-full md:w-auto">
               {[
                   { id: 'general', label: 'Geral' },
                   { id: 'integrations', label: 'Integrações' },
                   { id: 'security', label: 'Segurança' },
                   { id: 'logs', label: 'Logs de Auditoria' },
               ].map((tab) => (
                   <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id as any)}
                        className={`text-sm font-bold pb-4 -mb-4 transition-colors whitespace-nowrap ${
                            activeTab === tab.id 
                            ? 'text-harven-dark border-b-4 border-primary' 
                            : 'text-gray-400 hover:text-harven-dark border-b-4 border-transparent'
                        }`}
                   >
                       {tab.label}
                   </button>
               ))}
           </div>
           <div className="flex justify-end w-full md:w-auto">
              <button className="bg-primary hover:bg-primary-dark transition-all text-harven-dark font-bold px-5 py-2 rounded-lg text-xs shadow-lg shadow-primary/20 uppercase tracking-widest flex items-center gap-2">
                  <span className="material-symbols-outlined text-[18px]">save</span>
                  Salvar Alterações
              </button>
           </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 md:p-10 custom-scrollbar">
        <div className="max-w-6xl mx-auto flex flex-col gap-10">
          
          {/* TAB: GERAL */}
          {activeTab === 'general' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
                <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Identidade */}
                    <div className="lg:col-span-2 bg-white rounded-2xl border border-harven-border p-8 shadow-sm space-y-6">
                        <h4 className="text-xs font-black text-harven-gold uppercase tracking-widest border-b border-harven-bg pb-3 flex items-center gap-2">
                            <span className="material-symbols-outlined text-[18px]">badge</span> Identidade do Site
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-1.5">
                                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Nome da Plataforma</label>
                                <input className="w-full bg-harven-bg border-none rounded-lg py-3 px-4 text-sm focus:ring-1 focus:ring-primary text-harven-dark" defaultValue="Academy Platform" />
                            </div>
                            <div className="space-y-1.5">
                                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">URL Base</label>
                                <input className="w-full bg-harven-bg border-none rounded-lg py-3 px-4 text-sm focus:ring-1 focus:ring-primary text-harven-dark" defaultValue="https://app.school.com" />
                            </div>
                        </div>
                        <div className="space-y-1.5">
                            <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">E-mail de Suporte</label>
                            <input className="w-full bg-harven-bg border-none rounded-lg py-3 px-4 text-sm focus:ring-1 focus:ring-primary text-harven-dark" defaultValue="suporte@school.com" />
                            <p className="text-[9px] font-bold text-gray-400 uppercase italic">Visível para alunos no rodapé.</p>
                        </div>
                    </div>

                    {/* Branding */}
                    <div className="bg-white rounded-2xl border border-harven-border p-8 shadow-sm space-y-6">
                        <h4 className="text-xs font-black text-harven-gold uppercase tracking-widest border-b border-harven-bg pb-3 flex items-center gap-2">
                            <span className="material-symbols-outlined text-[18px]">palette</span> Branding
                        </h4>
                        <div className="flex flex-col gap-4">
                            <div className="flex justify-between items-center">
                                <span className="text-xs font-bold text-harven-dark uppercase">Cor Primária</span>
                                <div className="flex items-center gap-2 cursor-pointer group">
                                    <span className="text-[10px] font-mono font-bold text-gray-400 group-hover:text-harven-dark">#D0FF00</span>
                                    <div className="size-8 rounded-full bg-primary shadow-sm border border-harven-border"></div>
                                </div>
                            </div>
                            <div className="pt-4 border-t border-harven-bg space-y-3">
                                <label className="text-xs font-bold text-harven-dark uppercase block">Logotipo Oficial</label>
                                <div className="flex items-center gap-3">
                                    <div className="flex-1 bg-harven-dark p-3 rounded-lg flex items-center justify-center border border-harven-border">
                                        <img src={logoUrl} alt="Logo White" className="h-8 w-auto object-contain" onError={(e) => e.currentTarget.style.display = 'none'} />
                                    </div>
                                    <div className="flex-1 bg-white p-3 rounded-lg flex items-center justify-center border border-harven-border">
                                        <img src={logoUrl} alt="Logo Dark" className="h-8 w-auto object-contain" onError={(e) => e.currentTarget.style.display = 'none'} />
                                    </div>
                                </div>
                                
                                <label className="border-2 border-dashed border-gray-200 rounded-xl p-4 flex flex-col items-center gap-2 group hover:border-primary transition-all cursor-pointer bg-harven-bg/30 mt-2 relative">
                                    <span className="material-symbols-outlined text-gray-300 group-hover:text-primary-dark text-2xl">upload_file</span>
                                    <span className="text-[10px] font-bold text-gray-400 group-hover:text-harven-dark">ATUALIZAR LOGO (PNG)</span>
                                    <input type="file" className="hidden" accept="image/*" onChange={handleLogoUpload} />
                                </label>
                            </div>
                        </div>
                    </div>
                </section>

                <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Funcionalidades */}
                    <div className="bg-white rounded-2xl border border-harven-border p-8 shadow-sm space-y-6">
                        <h4 className="text-xs font-black text-harven-gold uppercase tracking-widest border-b border-harven-bg pb-3 flex items-center gap-2">
                            <span className="material-symbols-outlined text-[18px]">toggle_on</span> Módulos
                        </h4>
                        <div className="space-y-4">
                            {[
                                { label: 'Auto-registro de Alunos', active: true, desc: 'Permite que alunos se cadastrem com email institucional.' },
                                { label: 'Tutor Socrático (AI)', active: true, desc: 'Habilita o chat de IA nos capítulos.' },
                                { label: 'Gamificação & Ranking', active: false, desc: 'Exibe leaderboards e medalhas.' },
                                { label: 'Modo Escuro', active: true, desc: 'Permite alternar tema.' },
                            ].map((item, i) => (
                                <div key={i} className="flex justify-between items-start group">
                                    <div>
                                        <p className="text-sm font-bold text-harven-dark group-hover:text-primary-dark transition-colors">{item.label}</p>
                                        <p className="text-[10px] text-gray-400">{item.desc}</p>
                                    </div>
                                    <label className="relative inline-flex items-center cursor-pointer mt-1">
                                        <input type="checkbox" className="sr-only peer" defaultChecked={item.active} />
                                        <div className="w-9 h-5 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-primary"></div>
                                    </label>
                                </div>
                            ))}
                        </div>
                    </div>

                    {/* Limites */}
                    <div className="bg-white rounded-2xl border border-harven-border p-8 shadow-sm space-y-6">
                        <h4 className="text-xs font-black text-harven-gold uppercase tracking-widest border-b border-harven-bg pb-3 flex items-center gap-2">
                            <span className="material-symbols-outlined text-[18px]">data_usage</span> Quotas & Limites
                        </h4>
                        <div className="space-y-5">
                            <div className="space-y-1.5">
                                <div className="flex justify-between">
                                    <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Max. Tokens IA / Resposta</label>
                                    <span className="text-[10px] font-bold text-harven-dark">2048</span>
                                </div>
                                <input type="range" className="w-full accent-primary" min="512" max="4096" defaultValue="2048" />
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-xs font-bold text-harven-dark uppercase">Limite Upload (MB)</span>
                                <input className="w-24 bg-harven-bg border-none rounded-lg py-1.5 px-3 text-sm font-bold text-right focus:ring-1 focus:ring-primary text-harven-dark" defaultValue="500" />
                            </div>
                            <div className="bg-orange-50 p-4 rounded-xl border border-orange-100 flex gap-3 items-center">
                                <span className="material-symbols-outlined text-orange-500">warning</span>
                                <div>
                                    <p className="text-[10px] font-bold text-orange-700 uppercase">Armazenamento</p>
                                    <p className="text-xs font-bold text-orange-900">75% Utilizado (750GB / 1TB)</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
          )}

          {/* TAB: INTEGRAÇÕES */}
          {activeTab === 'integrations' && (
             <div className="grid grid-cols-1 gap-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="bg-white rounded-2xl border border-harven-border p-8 shadow-sm">
                    <h3 className="text-lg font-display font-bold text-harven-dark mb-6">Provedores de Inteligência Artificial</h3>
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div className="border border-harven-border rounded-xl p-6 flex flex-col gap-4 hover:border-primary transition-colors bg-white">
                            <div className="flex justify-between items-start">
                                <div className="flex items-center gap-3">
                                    <div className="size-10 bg-green-50 rounded-lg flex items-center justify-center text-green-600">
                                        <span className="material-symbols-outlined">smart_toy</span>
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-harven-dark text-sm">OpenAI API</h4>
                                        <p className="text-[10px] text-gray-400 font-bold uppercase">Modelo: GPT-4o</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-1 bg-green-100 text-green-700 px-2 py-0.5 rounded text-[9px] font-bold uppercase">
                                    <span className="size-1.5 rounded-full bg-green-600"></span> Conectado
                                </div>
                            </div>
                            <div className="space-y-1">
                                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Chave de API</label>
                                <div className="flex gap-2">
                                    <input type="password" value="sk-xxxxxxxxxxxxxxxxxxxx" readOnly className="flex-1 bg-harven-bg border-none rounded text-xs text-gray-500 font-mono" />
                                    <button className="text-xs font-bold text-primary-dark uppercase hover:underline">Alterar</button>
                                </div>
                            </div>
                        </div>

                        <div className="border border-harven-border rounded-xl p-6 flex flex-col gap-4 hover:border-primary transition-colors bg-gray-50 opacity-70">
                            <div className="flex justify-between items-start">
                                <div className="flex items-center gap-3">
                                    <div className="size-10 bg-gray-200 rounded-lg flex items-center justify-center text-gray-500">
                                        <span className="material-symbols-outlined">neurology</span>
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-gray-600 text-sm">Anthropic Claude</h4>
                                        <p className="text-[10px] text-gray-400 font-bold uppercase">Modelo: Sonnet 3.5</p>
                                    </div>
                                </div>
                                <button className="bg-white border border-gray-300 text-gray-500 px-3 py-1 rounded text-[10px] font-bold uppercase hover:text-harven-dark">Conectar</button>
                            </div>
                            <p className="text-xs text-gray-400 mt-2">Habilite para usar como modelo alternativo ou de fallback.</p>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-2xl border border-harven-border p-8 shadow-sm">
                    <h3 className="text-lg font-display font-bold text-harven-dark mb-6">Autenticação (SSO)</h3>
                    <div className="space-y-4">
                        {[
                            { name: 'Microsoft Azure AD', icon: 'window', status: 'Ativo' },
                            { name: 'Google Workspace', icon: 'radio_button_checked', status: 'Inativo' },
                        ].map((sso, i) => (
                            <div key={i} className="flex items-center justify-between p-4 border border-harven-border rounded-xl bg-white">
                                <div className="flex items-center gap-3">
                                    <span className="material-symbols-outlined text-gray-500">{sso.icon}</span>
                                    <span className="text-sm font-bold text-harven-dark">{sso.name}</span>
                                </div>
                                <div className="flex items-center gap-4">
                                    <span className={`text-[10px] font-bold uppercase ${sso.status === 'Ativo' ? 'text-green-600' : 'text-gray-400'}`}>{sso.status}</span>
                                    <label className="relative inline-flex items-center cursor-pointer">
                                        <input type="checkbox" className="sr-only peer" defaultChecked={sso.status === 'Ativo'} />
                                        <div className="w-9 h-5 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-primary"></div>
                                    </label>
                                    <button className="size-8 flex items-center justify-center rounded-lg hover:bg-harven-bg text-gray-400"><span className="material-symbols-outlined text-[18px]">settings</span></button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
             </div>
          )}

          {/* TAB: SEGURANÇA */}
          {activeTab === 'security' && (
             <div className="space-y-6 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="bg-white rounded-2xl border border-harven-border p-8 shadow-sm">
                    <h3 className="text-lg font-display font-bold text-harven-dark mb-6 flex items-center gap-2">
                        <span className="material-symbols-outlined text-red-500">lock</span>
                        Políticas de Acesso
                    </h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="space-y-4">
                            <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">Senhas</h4>
                            <div className="space-y-3">
                                <label className="flex items-center gap-3 p-3 border border-harven-border rounded-lg cursor-pointer hover:bg-harven-bg transition-colors">
                                    <input type="checkbox" className="rounded text-primary focus:ring-primary" defaultChecked />
                                    <span className="text-sm font-bold text-harven-dark">Exigir Mínimo de 8 Caracteres</span>
                                </label>
                                <label className="flex items-center gap-3 p-3 border border-harven-border rounded-lg cursor-pointer hover:bg-harven-bg transition-colors">
                                    <input type="checkbox" className="rounded text-primary focus:ring-primary" defaultChecked />
                                    <span className="text-sm font-bold text-harven-dark">Exigir Caracteres Especiais (!@#)</span>
                                </label>
                                <label className="flex items-center gap-3 p-3 border border-harven-border rounded-lg cursor-pointer hover:bg-harven-bg transition-colors">
                                    <input type="checkbox" className="rounded text-primary focus:ring-primary" />
                                    <span className="text-sm font-bold text-harven-dark">Expiração de Senha (90 dias)</span>
                                </label>
                            </div>
                        </div>

                        <div className="space-y-4">
                            <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">Sessão</h4>
                            <div className="space-y-1.5">
                                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Timeout de Sessão Ociosa</label>
                                <select className="w-full bg-harven-bg border-none rounded-lg p-3 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark">
                                    <option>15 minutos</option>
                                    <option>30 minutos</option>
                                    <option>1 hora</option>
                                    <option>Nunca</option>
                                </select>
                            </div>
                            <div className="pt-2">
                                <button className="w-full py-3 bg-red-50 text-red-600 font-bold text-xs uppercase rounded-lg border border-red-100 hover:bg-red-100 transition-colors">
                                    Forçar Logout de Todos os Usuários
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div className="bg-white rounded-2xl border border-harven-border p-8 shadow-sm flex justify-between items-center">
                    <div>
                        <h4 className="font-bold text-harven-dark">Autenticação de Dois Fatores (2FA)</h4>
                        <p className="text-xs text-gray-500 mt-1">Obrigar administradores e professores a usarem 2FA.</p>
                    </div>
                    <label className="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" className="sr-only peer" />
                        <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                    </label>
                </div>
             </div>
          )}

          {/* TAB: LOGS */}
          {activeTab === 'logs' && (
             <div className="bg-white rounded-2xl border border-harven-border shadow-sm overflow-hidden animate-in fade-in slide-in-from-right-4 duration-300 min-h-[500px] flex flex-col">
                <div className="p-6 border-b border-harven-border flex flex-col md:flex-row justify-between items-center gap-4 bg-harven-bg/30">
                    <h3 className="font-display font-bold text-harven-dark flex items-center gap-2">
                        <span className="material-symbols-outlined text-gray-400">history</span>
                        Registro de Auditoria
                    </h3>
                    <div className="flex gap-2 w-full md:w-auto">
                        <input className="bg-white border border-harven-border rounded-lg px-4 py-2 text-xs w-full md:w-64" placeholder="Buscar por usuário ou ação..." />
                        <button className="bg-white border border-harven-border px-3 py-2 rounded-lg text-gray-500 hover:text-harven-dark"><span className="material-symbols-outlined text-[18px]">download</span></button>
                    </div>
                </div>
                <div className="overflow-x-auto flex-1">
                    <table className="w-full text-left">
                        <thead className="bg-harven-bg/50 border-b border-harven-border text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                            <tr>
                                <th className="p-4">Ação</th>
                                <th className="p-4">Usuário</th>
                                <th className="p-4">Alvo/Recurso</th>
                                <th className="p-4">IP</th>
                                <th className="p-4 text-right">Data</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-harven-bg">
                            {auditLogs.map((log) => (
                                <tr key={log.id} className="hover:bg-harven-bg/20 transition-colors">
                                    <td className="p-4 text-sm font-bold text-harven-dark">{log.action}</td>
                                    <td className="p-4 text-xs font-medium text-gray-600">{log.user}</td>
                                    <td className="p-4 text-xs font-medium text-gray-500 font-mono">{log.target}</td>
                                    <td className="p-4 text-xs text-gray-400 font-mono">{log.ip}</td>
                                    <td className="p-4 text-right text-xs font-bold text-gray-500">{log.date}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
                <div className="p-4 border-t border-harven-border bg-harven-bg/20 flex justify-center">
                    <button className="text-xs font-bold text-primary-dark hover:underline uppercase tracking-widest">Carregar Mais Antigos</button>
                </div>
             </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default SystemSettings;
