
import React, { useState } from 'react';
import { ViewType } from '../types';

interface AdminConsoleProps {
  onNavigate: (view: ViewType) => void;
}

const AdminConsole: React.FC<AdminConsoleProps> = ({ onNavigate }) => {
  const [showModal, setShowModal] = useState(false);
  const [actionType, setActionType] = useState<'ANNOUNCEMENT' | 'MAINTENANCE'>('ANNOUNCEMENT');
  const [recipientType, setRecipientType] = useState('ALL');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Mock data para logs
  const [logs, setLogs] = useState([
    { msg: 'Novo usuário cadastrado: m.silva@example.com', author: 'Admin • Há 5 min', status: 'Sucesso', color: 'green' },
    { msg: 'Falha na sincronização de API: OpenAI Gateway', author: 'Sistema • Há 24 min', status: 'Erro', color: 'red' },
    { msg: 'Relatório mensal gerado automaticamente', author: 'Scheduler • Há 1 hora', status: 'Concluído', color: 'blue' },
    { msg: 'Disciplina arquivada: História da Arte I', author: 'Coord. Elena • Há 2 horas', status: 'Processado', color: 'gray' },
  ]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    setTimeout(() => {
      const newLog = actionType === 'ANNOUNCEMENT' 
        ? { msg: 'Comunicado Global disparado para 12.450 usuários', author: 'Admin • Agora', status: 'Enviado', color: 'blue' }
        : { msg: 'Agendamento de Manutenção: Sistema ficará offline', author: 'Admin • Agora', status: 'Agendado', color: 'orange' };
      
      setLogs([newLog, ...logs]);
      setIsSubmitting(false);
      setShowModal(false);
      setRecipientType('ALL');
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto p-8 flex flex-col gap-8 relative">
      <div className="flex flex-col md:flex-row justify-between items-end gap-6">
        <div>
          <h2 className="text-3xl font-display font-bold text-harven-dark tracking-tight">Bem-vindo, Admin</h2>
          <p className="text-gray-500 font-bold text-xs uppercase tracking-widest mt-1">Visão geral do sistema e métricas de hoje.</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="bg-primary hover:bg-primary-dark transition-all text-harven-dark font-bold px-6 py-2.5 rounded-lg flex items-center gap-2 shadow-lg shadow-primary/20 uppercase tracking-wider text-xs"
        >
          <span className="material-symbols-outlined text-[20px]">add_circle</span>
          Nova Ação Global
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: 'Total Usuários', val: '12.450', icon: 'group', trend: '+12% este mês', color: 'blue' },
          { label: 'Disciplinas', val: '42', icon: 'menu_book', trend: '8 pendentes de prof.', color: 'harven-gold' },
          { label: 'Performance', val: '98%', icon: 'monitoring', trend: 'Sistemas operacionais', color: 'green' },
          { label: 'Alertas IA', val: '3', icon: 'warning', trend: 'Ação requerida', color: 'red' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-xl border border-harven-border shadow-sm flex flex-col gap-1 group hover:border-primary/50 transition-colors cursor-pointer">
            <div className="flex justify-between items-start mb-2">
               <div className="bg-harven-bg p-2 rounded-lg text-harven-dark group-hover:bg-primary transition-colors">
                  <span className="material-symbols-outlined text-[20px]">{stat.icon}</span>
               </div>
               <span className={`text-[9px] font-black text-white bg-${stat.color}-500 px-1.5 py-0.5 rounded uppercase tracking-tighter`}>Live</span>
            </div>
            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{stat.label}</p>
            <p className="text-3xl font-display font-bold text-harven-dark">{stat.val}</p>
            <p className="text-[10px] font-bold text-green-600 mt-2">{stat.trend}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-xl border border-harven-border p-8 shadow-sm flex flex-col">
           <div className="flex justify-between items-start mb-8">
              <div>
                 <h3 className="font-display font-bold text-lg text-harven-dark">Crescimento de Usuários</h3>
                 <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">Últimos 6 meses</p>
              </div>
              <div className="flex items-center gap-2 bg-green-50 text-green-700 px-3 py-1 rounded-full text-xs font-bold">
                 <span className="material-symbols-outlined text-[16px]">trending_up</span> +15%
              </div>
           </div>
           <div className="flex-1 h-64 w-full flex items-end justify-between px-2 pt-10 relative">
              {/* Simple Chart Mockup with CSS/SVG */}
              <svg className="absolute inset-0 h-full w-full opacity-20">
                <path d="M0,100 Q100,50 200,80 T400,30 T600,10" fill="none" stroke="#d0ff00" strokeWidth="4" />
              </svg>
              <div className="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-10">
                 <div className="w-full h-px bg-gray-400"></div>
                 <div className="w-full h-px bg-gray-400"></div>
                 <div className="w-full h-px bg-gray-400"></div>
                 <div className="w-full h-px bg-gray-400"></div>
              </div>
              {['JAN', 'FEV', 'MAR', 'ABR', 'MAI', 'JUN'].map((m, i) => (
                <div key={i} className="flex flex-col items-center gap-2 group w-full">
                  <div className="w-full bg-harven-bg rounded-t-lg h-32 relative overflow-hidden">
                    <div className="absolute bottom-0 w-full bg-harven-dark group-hover:bg-primary transition-all rounded-t-lg" style={{ height: `${20 + i * 15}%` }}></div>
                  </div>
                  <span className="text-[10px] font-bold text-gray-400">{m}</span>
                </div>
              ))}
           </div>
        </div>

        <div className="bg-white rounded-xl border border-harven-border p-8 shadow-sm">
           <div className="flex justify-between items-center mb-8">
              <div>
                 <h3 className="font-display font-bold text-lg text-harven-dark">Ações Rápidas</h3>
                 <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mt-1">Gerenciamento imediato</p>
              </div>
              <button className="text-gray-400 hover:text-harven-dark transition-colors"><span className="material-symbols-outlined">more_horiz</span></button>
           </div>
           <div className="grid grid-cols-2 gap-4">
              <button 
                onClick={() => onNavigate('USER_MANAGEMENT')}
                className="p-6 bg-harven-bg rounded-xl border border-transparent hover:border-primary hover:bg-white hover:shadow-md transition-all group flex flex-col gap-3"
              >
                <span className="material-symbols-outlined text-gray-400 group-hover:text-primary-dark transition-colors text-3xl">person_add</span>
                <span className="text-sm font-bold text-harven-dark">Criar Usuário</span>
              </button>
              <button 
                className="p-6 bg-harven-bg rounded-xl border border-transparent hover:border-primary hover:bg-white hover:shadow-md transition-all group flex flex-col gap-3"
              >
                <span className="material-symbols-outlined text-gray-400 group-hover:text-primary-dark transition-colors text-3xl">library_add</span>
                <span className="text-sm font-bold text-harven-dark">Criar Disciplina</span>
              </button>
              <button className="col-span-2 p-4 bg-harven-dark rounded-xl text-white font-bold text-sm hover:bg-black transition-colors flex items-center justify-center gap-3">
                 <span className="material-symbols-outlined text-primary text-[20px]">build</span>
                 ENTRAR EM MODO MANUTENÇÃO
              </button>
           </div>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-harven-border shadow-sm overflow-hidden">
        <div className="p-6 border-b border-harven-border flex justify-between items-center">
           <h3 className="font-display font-bold text-harven-dark">Logs Recentes do Sistema</h3>
           <button className="text-[10px] font-black text-primary-dark uppercase tracking-widest hover:underline">Ver todos os logs</button>
        </div>
        <div className="divide-y divide-harven-border">
           {logs.map((log, i) => (
             <div key={i} className="p-4 flex items-center justify-between hover:bg-harven-bg/30 transition-colors group">
                <div className="flex items-center gap-4">
                   <div className="size-8 rounded-full bg-harven-bg flex items-center justify-center text-gray-400 group-hover:text-harven-dark">
                      <span className="material-symbols-outlined text-[18px]">history</span>
                   </div>
                   <div>
                      <p className="text-sm font-bold text-harven-dark">{log.msg}</p>
                      <p className="text-[10px] font-bold text-gray-400 uppercase">{log.author}</p>
                   </div>
                </div>
                <span className={`bg-${log.color}-50 text-${log.color}-600 border border-${log.color}-100 text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-tighter`}>{log.status}</span>
             </div>
           ))}
        </div>
      </div>

      {/* Modal de Ação Global */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-harven-dark/80 backdrop-blur-sm animate-in fade-in duration-200">
           <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
             
             {/* Header do Modal */}
             <div className="p-6 border-b border-harven-border bg-harven-bg flex justify-between items-center">
               <div className="flex items-center gap-3">
                 <div className="size-10 bg-harven-dark rounded-lg flex items-center justify-center text-primary shadow-sm">
                    <span className="material-symbols-outlined">campaign</span>
                 </div>
                 <div>
                   <h3 className="text-lg font-display font-bold text-harven-dark">Ação Global</h3>
                   <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">Impacto em todo o sistema</p>
                 </div>
               </div>
               <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-harven-dark transition-colors">
                 <span className="material-symbols-outlined">close</span>
               </button>
             </div>
             
             {/* Tipo de Ação */}
             <div className="flex p-2 bg-white border-b border-harven-border gap-2">
                <button 
                  onClick={() => setActionType('ANNOUNCEMENT')}
                  className={`flex-1 py-3 rounded-lg text-xs font-bold uppercase tracking-wide transition-all flex items-center justify-center gap-2 ${actionType === 'ANNOUNCEMENT' ? 'bg-primary/10 text-harven-dark ring-1 ring-primary' : 'text-gray-400 hover:bg-gray-50'}`}
                >
                  <span className="material-symbols-outlined text-[18px]">notifications_active</span>
                  Comunicado
                </button>
                <button 
                  onClick={() => setActionType('MAINTENANCE')}
                  className={`flex-1 py-3 rounded-lg text-xs font-bold uppercase tracking-wide transition-all flex items-center justify-center gap-2 ${actionType === 'MAINTENANCE' ? 'bg-red-50 text-red-700 ring-1 ring-red-200' : 'text-gray-400 hover:bg-gray-50'}`}
                >
                  <span className="material-symbols-outlined text-[18px]">engineering</span>
                  Manutenção
                </button>
             </div>

             <form onSubmit={handleSubmit} className="p-6 flex flex-col gap-6">
                
                {actionType === 'ANNOUNCEMENT' && (
                  <div className="space-y-4 animate-in fade-in slide-in-from-left-4 duration-300">
                     <div className="space-y-1.5">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Tipo de Destinatário</label>
                        <select 
                           value={recipientType} 
                           onChange={(e) => setRecipientType(e.target.value)}
                           className="w-full bg-harven-bg border-none rounded-lg px-4 py-3 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark"
                        >
                           <option value="ALL">Todos os Usuários (12.450)</option>
                           <option value="ROLE">Por Função (Professor/Aluno)</option>
                           <option value="SPECIFIC_USER">Usuários Específicos</option>
                           <option value="SPECIFIC_CLASS">Por Turma</option>
                        </select>
                     </div>

                     {/* Sub-opções baseadas na seleção */}
                     {recipientType === 'ROLE' && (
                        <div className="space-y-1.5 animate-in fade-in duration-200">
                           <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Selecione a Função</label>
                           <select className="w-full bg-harven-bg border-none rounded-lg px-4 py-3 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark">
                              <option>Apenas Professores</option>
                              <option>Apenas Alunos</option>
                              <option>Apenas Administradores</option>
                           </select>
                        </div>
                     )}

                     {recipientType === 'SPECIFIC_USER' && (
                        <div className="space-y-1.5 animate-in fade-in duration-200">
                           <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Buscar Usuários</label>
                           <div className="relative">
                              <span className="material-symbols-outlined absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">search</span>
                              <input 
                                 className="w-full bg-harven-bg border-none rounded-lg pl-10 pr-4 py-3 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark" 
                                 placeholder="Digite o nome, e-mail ou ID..." 
                              />
                           </div>
                        </div>
                     )}

                     {recipientType === 'SPECIFIC_CLASS' && (
                        <div className="space-y-1.5 animate-in fade-in duration-200">
                           <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Selecione a Turma</label>
                           <select className="w-full bg-harven-bg border-none rounded-lg px-4 py-3 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark">
                              <option>Selecione uma turma...</option>
                              <option>Engenharia de Software 2023.1</option>
                              <option>Cálculo I - Turma A</option>
                              <option>Direito Constitucional - Noturno</option>
                              <option>Medicina - Anatomia II</option>
                           </select>
                        </div>
                     )}

                     <div className="space-y-1.5">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Título do Comunicado</label>
                        <input className="w-full bg-harven-bg border-none rounded-lg px-4 py-3 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark" placeholder="Ex: Atualização da Plataforma" />
                     </div>
                     <div className="space-y-1.5">
                        <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Mensagem</label>
                        <textarea className="w-full bg-harven-bg border-none rounded-lg px-4 py-3 text-sm font-medium focus:ring-1 focus:ring-primary min-h-[100px] resize-none text-harven-dark" placeholder="Digite sua mensagem aqui..." />
                     </div>
                     <div className="flex items-center gap-2 p-3 bg-blue-50 text-blue-800 rounded-lg text-xs">
                        <span className="material-symbols-outlined text-[18px]">info</span>
                        Isso enviará uma notificação push e um e-mail.
                     </div>
                  </div>
                )}

                {actionType === 'MAINTENANCE' && (
                  <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                     <div className="bg-red-50 border border-red-100 rounded-xl p-4 flex gap-3">
                        <span className="material-symbols-outlined text-red-500">warning</span>
                        <div>
                           <h4 className="text-sm font-bold text-red-800">Zona de Perigo</h4>
                           <p className="text-xs text-red-700 mt-1">Ativar o modo manutenção impedirá o login de todos os usuários exceto administradores.</p>
                        </div>
                     </div>
                     <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-1.5">
                           <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Início Programado</label>
                           <input type="datetime-local" className="w-full bg-harven-bg border-none rounded-lg px-4 py-3 text-sm font-medium focus:ring-1 focus:ring-red-500 text-harven-dark" />
                        </div>
                        <div className="space-y-1.5">
                           <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Duração Estimada</label>
                           <select className="w-full bg-harven-bg border-none rounded-lg px-4 py-3 text-sm font-medium focus:ring-1 focus:ring-red-500 text-harven-dark">
                              <option>30 minutos</option>
                              <option>1 hora</option>
                              <option>4 horas</option>
                              <option>Indeterminado</option>
                           </select>
                        </div>
                     </div>
                  </div>
                )}
                
                <div className="pt-2 flex gap-3 border-t border-harven-border mt-2">
                   <button 
                     type="button" 
                     onClick={() => setShowModal(false)}
                     className="flex-1 py-3 border border-harven-border rounded-xl text-xs font-bold text-harven-dark hover:bg-gray-50 transition-colors uppercase tracking-widest"
                   >
                     Cancelar
                   </button>
                   <button 
                     type="submit"
                     disabled={isSubmitting}
                     className={`flex-1 py-3 rounded-xl text-xs font-bold transition-all uppercase tracking-widest shadow-lg flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed ${
                        actionType === 'MAINTENANCE' 
                        ? 'bg-red-600 hover:bg-red-700 text-white shadow-red-500/20' 
                        : 'bg-primary hover:bg-primary-dark text-harven-dark shadow-primary/20'
                     }`}
                   >
                     {isSubmitting ? (
                       <>
                         <span className="material-symbols-outlined animate-spin text-[18px]">progress_activity</span>
                         Processando...
                       </>
                     ) : (
                       actionType === 'MAINTENANCE' ? 'Agendar Manutenção' : 'Enviar Comunicado'
                     )}
                   </button>
                </div>
             </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default AdminConsole;
