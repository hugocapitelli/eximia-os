
import React, { useState } from 'react';
import { ViewType } from '../types';

interface CourseDetailsProps {
  onNavigate: (view: ViewType) => void;
}

const CourseDetails: React.FC<CourseDetailsProps> = ({ onNavigate }) => {
  const isInstructor = true; 

  const [expandedModuleId, setExpandedModuleId] = useState<number | null>(2);
  const [activeTab, setActiveTab] = useState<'content' | 'about' | 'resources' | 'discussion'>('content');
  
  // Estados para edição
  const [editingModuleId, setEditingModuleId] = useState<number | null>(null);
  const [editModuleData, setEditModuleData] = useState({ title: '', duration: '' });
  const [isEditingAbout, setIsEditingAbout] = useState(false);
  const [aboutText, setAboutText] = useState("Este curso intensivo de Growth Hacking foi projetado para profissionais de marketing e empreendedores que desejam dominar a arte da experimentação rápida.");

  // Estados para criação de capítulo/aula
  const [showChapterModal, setShowChapterModal] = useState(false);
  const [newChapterTitle, setNewChapterTitle] = useState('');

  const [commentInput, setCommentInput] = useState('');
  const [comments, setComments] = useState([
    { id: 1, user: 'Carlos Mendes', role: 'Aluno', time: 'Há 2 horas', text: 'Alguém conseguiu aplicar o framework AAARRR no setor de serviços?', likes: 5, replies: 2, avatar: '11' },
  ]);

  // Dados mockados
  const [modules, setModules] = useState([
    {
      id: 1,
      title: 'Módulo 1: Fundamentos de Growth',
      duration: '45 min',
      progress: 100,
      completed: true,
      chapters: [
        { id: '1.1', title: 'O Mindset de Crescimento', status: 'completed', duration: '10 min' },
        { id: '1.2', title: 'Funil Pirata (AAARRR)', status: 'completed', duration: '15 min' },
        { id: '1.3', title: 'Product-Market Fit', status: 'completed', duration: '12 min' },
        { id: '1.4', title: 'Quiz: Fundamentos', status: 'completed', duration: '8 min' }
      ]
    },
    {
      id: 2,
      title: 'Módulo 2: Experimentação Rápida',
      duration: '55 min',
      progress: 45,
      completed: false,
      chapters: [
        { id: '2.1', title: 'Definição de KPIs', status: 'completed', duration: '15 min' },
        { id: '2.2', title: 'Configuração de Testes A/B', status: 'in_progress', duration: '20 min', remaining: '10 min restantes' },
        { id: '2.3', title: 'Análise de Dados e Iteração', status: 'locked', duration: '20 min' }
      ]
    },
  ]);

  const toggleModule = (id: number) => {
    setExpandedModuleId(expandedModuleId === id ? null : id);
  };

  const handleAddModule = () => {
      const newId = modules.length + 1;
      setModules([
          ...modules,
          {
              id: newId,
              title: `Módulo ${newId}: Novo Módulo`,
              duration: '0 min',
              progress: 0,
              completed: false,
              chapters: []
          }
      ]);
      setExpandedModuleId(newId);
      setEditingModuleId(newId);
      setEditModuleData({ title: `Módulo ${newId}: Novo Módulo`, duration: '0 min' });
  };

  const startEditingModule = (e: React.MouseEvent, module: any) => {
      e.stopPropagation();
      setEditingModuleId(module.id);
      setEditModuleData({ title: module.title, duration: module.duration });
  };

  const saveModule = (id: number) => {
      setModules(modules.map(m => m.id === id ? { ...m, ...editModuleData } : m));
      setEditingModuleId(null);
  };

  const openChapterModal = (moduleId: number) => {
      setNewChapterTitle('');
      setShowChapterModal(true);
  };

  const handleCreateChapter = (e: React.FormEvent) => {
      e.preventDefault();
      setShowChapterModal(false);
      // Redireciona para criação de conteúdo onde fará o upload e escolherá o método
      onNavigate('CONTENT_CREATION');
  };

  const tabs = [
    { id: 'content', label: 'Conteúdo', icon: 'list_alt' },
    { id: 'about', label: 'Sobre', icon: 'info' },
    { id: 'resources', label: 'Recursos', icon: 'folder_open', count: 4 },
    { id: 'discussion', label: 'Discussão', icon: 'forum', count: comments.length }
  ];

  return (
    <div className="flex flex-col flex-1 h-full bg-[#f8f9fa]">
      <div className="relative h-64 bg-harven-dark overflow-hidden flex-shrink-0 group">
        <img src="https://picsum.photos/seed/growth/1200/600" className="w-full h-full object-cover opacity-30 group-hover:scale-105 transition-transform duration-700" alt="Banner" />
        <div className="absolute inset-0 bg-gradient-to-t from-harven-dark via-harven-dark/60 to-transparent p-8 flex flex-col justify-end">
          <div className="max-w-6xl mx-auto w-full flex flex-col md:flex-row justify-between items-end gap-6">
            <div className="flex flex-col gap-3">
              <h1 className="text-3xl md:text-4xl font-display font-bold text-white leading-tight tracking-tight drop-shadow-md relative">
                Advanced Growth Hacking Strategies
                {isInstructor && (
                    <button 
                        onClick={() => onNavigate('COURSE_EDIT')}
                        className="absolute -right-10 top-1 text-gray-400 hover:text-primary transition-colors" 
                        title="Configurações do Curso"
                    >
                        <span className="material-symbols-outlined text-[20px]">edit</span>
                    </button>
                )}
              </h1>
              <p className="text-white/80 flex items-center gap-2 text-sm font-medium">
                Dr. Elena Vance • Engenharia 2024.1
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto w-full px-4 md:px-8 py-8 flex flex-col gap-8">
        
        {/* Navegação de Abas */}
        <div className="sticky top-0 z-20 bg-[#f8f9fa]/95 backdrop-blur-sm pt-2 flex justify-between items-center">
          <div className="bg-white rounded-xl border border-harven-border p-1.5 shadow-sm flex overflow-x-auto no-scrollbar">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex-1 flex items-center justify-center gap-2 px-6 py-3 rounded-lg text-sm font-bold transition-all whitespace-nowrap min-w-fit
                  ${activeTab === tab.id 
                    ? 'bg-harven-dark text-white shadow-md' 
                    : 'text-gray-500 hover:bg-gray-50 hover:text-harven-dark'
                  }`}
              >
                <span className={`material-symbols-outlined text-[18px] ${activeTab === tab.id ? 'text-primary' : 'text-gray-400'}`}>{tab.icon}</span>
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="min-h-[400px]">
          {activeTab === 'content' && (
            <div className="flex flex-col gap-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
              
              {isInstructor && (
                  <button 
                    onClick={handleAddModule}
                    className="w-full border-2 border-dashed border-gray-300 rounded-xl p-4 flex items-center justify-center gap-2 text-gray-400 font-bold hover:bg-white hover:border-primary hover:text-primary-dark transition-all"
                  >
                      <span className="material-symbols-outlined">add_circle</span>
                      Adicionar Novo Módulo
                  </button>
              )}

              {modules.map((module) => {
                const isExpanded = expandedModuleId === module.id;
                const isEditing = editingModuleId === module.id;
                const lessonCount = module.chapters.length;
                
                return (
                  <div 
                    key={module.id} 
                    className={`bg-white rounded-xl border transition-all shadow-sm overflow-hidden ${isExpanded ? 'border-primary/50 ring-1 ring-primary/20 shadow-md' : 'border-harven-border hover:border-gray-300'}`}
                  >
                    <div 
                      className="p-6 flex justify-between items-center bg-white cursor-pointer hover:bg-gray-50 transition-colors select-none group"
                      onClick={() => !isEditing && toggleModule(module.id)}
                    >
                      <div className="flex items-center gap-5 w-full">
                        <div className={`size-10 rounded-full flex items-center justify-center text-harven-dark transition-all duration-300 ${isExpanded ? 'bg-primary text-harven-dark rotate-180' : 'bg-harven-bg group-hover:bg-gray-200'}`}>
                          <span className="material-symbols-outlined text-[24px]">expand_more</span>
                        </div>
                        <div className="flex-1">
                          {isEditing ? (
                              <div className="flex flex-col gap-2" onClick={e => e.stopPropagation()}>
                                  <input 
                                    className="w-full bg-harven-bg border border-primary/50 rounded px-2 py-1 text-lg font-bold text-harven-dark focus:ring-primary"
                                    value={editModuleData.title}
                                    onChange={(e) => setEditModuleData({...editModuleData, title: e.target.value})}
                                    autoFocus
                                  />
                                  <input 
                                    className="w-full bg-harven-bg border border-harven-border rounded px-2 py-1 text-xs font-medium text-gray-500 focus:ring-primary"
                                    value={editModuleData.duration}
                                    onChange={(e) => setEditModuleData({...editModuleData, duration: e.target.value})}
                                    placeholder="Detalhes (ex: duração)"
                                  />
                                  <div className="flex gap-2 mt-1">
                                      <button onClick={() => saveModule(module.id)} className="bg-primary px-3 py-1 rounded text-xs font-bold text-harven-dark">Salvar</button>
                                      <button onClick={() => setEditingModuleId(null)} className="bg-gray-200 px-3 py-1 rounded text-xs font-bold text-gray-600">Cancelar</button>
                                  </div>
                              </div>
                          ) : (
                              <>
                                <h4 className="font-bold text-harven-dark text-lg flex items-center gap-2">
                                    {module.title}
                                    {isInstructor && <button onClick={(e) => startEditingModule(e, module)} className="p-1 rounded hover:bg-harven-bg text-gray-300 hover:text-primary-dark transition-colors"><span className="material-symbols-outlined text-[16px]">edit</span></button>}
                                </h4>
                                <p className="text-xs text-gray-500 mt-1 font-medium uppercase tracking-wide">
                                    {lessonCount} {lessonCount === 1 ? 'Aula' : 'Aulas'} • {module.duration}
                                </p>
                              </>
                          )}
                        </div>
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="divide-y divide-harven-border border-t border-harven-border bg-harven-bg/30">
                        {module.chapters.map((chapter) => (
                          <div 
                            key={chapter.id} 
                            onClick={() => {
                                if (isInstructor) onNavigate('CONTENT_REVISION');
                                else onNavigate('CHAPTER_READER');
                            }} 
                            className={`p-5 flex justify-between items-center transition-all cursor-pointer relative group/chapter hover:bg-white border-l-4 border-l-transparent hover:border-l-primary`}
                          >
                            <div className="flex items-center gap-4">
                              <span className="material-symbols-outlined text-gray-400 text-[22px]">play_circle</span>
                              <div>
                                 <p className="text-sm font-bold text-harven-dark">{chapter.title}</p>
                                 <p className="text-[10px] text-gray-400 font-bold uppercase mt-0.5">{chapter.duration}</p>
                              </div>
                            </div>
                            {isInstructor && (
                                <button onClick={(e) => e.stopPropagation()} className="p-1.5 bg-white border border-harven-border rounded-lg text-gray-400 hover:text-red-500 hover:border-red-200 transition-all">
                                    <span className="material-symbols-outlined text-[16px]">delete</span>
                                </button>
                            )}
                          </div>
                        ))}
                        {isInstructor && (
                            <button 
                                onClick={() => openChapterModal(module.id)}
                                className="w-full py-3 text-xs font-bold text-gray-400 uppercase hover:bg-white hover:text-primary-dark transition-all flex items-center justify-center gap-2"
                            >
                                <span className="material-symbols-outlined text-[16px]">add</span>
                                Adicionar Aula
                            </button>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {activeTab === 'about' && (
            <div className="bg-white p-8 rounded-xl border border-harven-border animate-in fade-in slide-in-from-bottom-2 duration-300 shadow-sm space-y-8 relative group">
               {isInstructor && (
                   <button 
                    onClick={() => setIsEditingAbout(!isEditingAbout)}
                    className={`absolute top-4 right-4 p-2 rounded-lg transition-all ${isEditingAbout ? 'bg-primary text-harven-dark' : 'bg-harven-bg text-gray-400 hover:text-primary-dark'}`}
                   >
                       <span className="material-symbols-outlined">{isEditingAbout ? 'check' : 'edit'}</span>
                   </button>
               )}
               <div className="prose prose-sm max-w-none text-gray-600">
                 <h3 className="text-xl font-display font-bold text-harven-dark mb-4 flex items-center gap-2">
                    <span className="material-symbols-outlined text-primary">verified</span>
                    Sobre o Curso
                 </h3>
                 {isEditingAbout ? (
                     <textarea 
                        className="w-full bg-harven-bg border-primary/50 rounded-lg p-4 text-base leading-relaxed h-40 focus:ring-primary"
                        value={aboutText}
                        onChange={(e) => setAboutText(e.target.value)}
                     />
                 ) : (
                     <p className="leading-relaxed text-base">{aboutText}</p>
                 )}
               </div>
            </div>
          )}

          {activeTab === 'resources' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
               {isInstructor && (
                   <button className="border-2 border-dashed border-gray-300 rounded-xl p-6 flex flex-col items-center justify-center gap-2 text-gray-400 hover:border-primary hover:text-primary-dark hover:bg-white transition-all col-span-1 md:col-span-2">
                       <span className="material-symbols-outlined text-3xl">cloud_upload</span>
                       <span className="text-xs font-bold uppercase">Upload de Novo Recurso</span>
                   </button>
               )}
               {[
                 { name: 'Planilha de Priorização ICE.xlsx', size: '1.2 MB', type: 'EXCEL', icon: 'table_view', color: 'green' },
                 { name: 'Checklist de Experimentação.pdf', size: '450 KB', type: 'PDF', icon: 'picture_as_pdf', color: 'red' },
               ].map((res, i) => (
                 <div key={i} className="bg-white p-5 rounded-xl border border-harven-border flex justify-between items-center hover:border-primary transition-all group shadow-sm hover:shadow-md">
                    <div className="flex items-center gap-4">
                       <div className={`size-12 bg-${res.color}-50 rounded-xl flex items-center justify-center text-${res.color}-600 group-hover:scale-110 transition-transform`}>
                         <span className="material-symbols-outlined text-[24px]">{res.icon}</span>
                       </div>
                       <div>
                          <p className="text-sm font-bold text-harven-dark group-hover:text-primary-dark transition-colors">{res.name}</p>
                          <div className="flex items-center gap-2 mt-1">
                             <span className="text-[10px] font-bold bg-gray-100 text-gray-500 px-1.5 py-0.5 rounded uppercase">{res.type}</span>
                             <span className="size-1 bg-gray-300 rounded-full"></span>
                             <span className="text-xs text-gray-400">{res.size}</span>
                          </div>
                       </div>
                    </div>
                    {isInstructor && (
                        <button className="size-10 rounded-full border border-harven-border flex items-center justify-center text-gray-400 hover:text-red-500 hover:border-red-200 transition-all">
                            <span className="material-symbols-outlined">delete</span>
                        </button>
                    )}
                 </div>
               ))}
            </div>
          )}

          {activeTab === 'discussion' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-300 max-w-4xl mx-auto">
               <div className="bg-white p-6 rounded-xl border border-harven-border shadow-sm relative">
                  <div className="flex gap-4">
                      <div className="size-10 rounded-full bg-harven-dark text-primary flex items-center justify-center font-bold text-xs flex-shrink-0 border-2 border-primary">VC</div>
                      <div className="flex-1">
                          <textarea 
                            value={commentInput}
                            onChange={(e) => setCommentInput(e.target.value)}
                            className="w-full bg-harven-bg border-none rounded-xl p-4 focus:ring-1 focus:ring-primary placeholder-gray-400 text-sm resize-none min-h-[80px] text-harven-dark" 
                            placeholder="Compartilhe com a turma..." 
                          />
                          <div className="flex justify-end items-center mt-3 gap-2">
                              {isInstructor && <button className="text-gray-400 hover:text-red-500 p-2"><span className="material-symbols-outlined">delete_sweep</span></button>}
                              <button className="bg-primary hover:bg-primary-dark text-harven-dark px-6 py-2 rounded-lg transition-all shadow-sm font-bold text-xs uppercase tracking-wide flex items-center gap-2">
                                 Publicar
                              </button>
                          </div>
                      </div>
                  </div>
               </div>
            </div>
          )}
        </div>
      </div>

      {/* MODAL DE CRIAÇÃO DE AULA SIMPLES */}
      {showChapterModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-harven-dark/80 backdrop-blur-sm animate-in fade-in duration-200">
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
                  <div className="p-6 border-b border-harven-border bg-harven-bg flex justify-between items-center">
                      <h3 className="text-lg font-display font-bold text-harven-dark">Adicionar Nova Aula</h3>
                      <button onClick={() => setShowChapterModal(false)} className="text-gray-400 hover:text-harven-dark">
                          <span className="material-symbols-outlined">close</span>
                      </button>
                  </div>
                  <form onSubmit={handleCreateChapter} className="p-6 flex flex-col gap-6">
                      <div className="space-y-1.5">
                          <label className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Título da Aula</label>
                          <input 
                            required
                            value={newChapterTitle}
                            onChange={e => setNewChapterTitle(e.target.value)}
                            className="w-full bg-harven-bg border-none rounded-lg px-4 py-3 text-sm font-medium focus:ring-1 focus:ring-primary text-harven-dark"
                            placeholder="Ex: Introdução ao Conceito"
                          />
                          <p className="text-[10px] text-gray-400">Você adicionará o conteúdo no próximo passo.</p>
                      </div>

                      <div className="pt-2 flex gap-3">
                          <button type="button" onClick={() => setShowChapterModal(false)} className="flex-1 py-3 border border-harven-border rounded-xl text-xs font-bold text-harven-dark hover:bg-gray-50 transition-colors uppercase tracking-widest">Cancelar</button>
                          <button type="submit" className="flex-1 py-3 bg-primary hover:bg-primary-dark rounded-xl text-xs font-bold text-harven-dark transition-all uppercase tracking-widest shadow-lg shadow-primary/20">
                              Continuar
                          </button>
                      </div>
                  </form>
              </div>
          </div>
      )}
    </div>
  );
};

export default CourseDetails;
